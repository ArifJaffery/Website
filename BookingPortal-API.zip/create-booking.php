<?php
header("Content-Type: application/json");

// Check POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("HTTP/1.1 405 Method Not Allowed");
    echo json_encode(array('error' => 'Only POST allowed'));
    exit;
}

// Read input
$input = file_get_contents("php://input");
$data = json_decode($input, true);

if (!$data) {
    header("HTTP/1.1 400 Bad Request");
    echo json_encode(array('error' => 'Invalid JSON'));
    exit;
}

// Get and sanitize userId
$userId = isset($data['userId']) ? $data['userId'] : 'unknown';
$userId = preg_replace('/[^a-zA-Z0-9_-]/', '', $userId);

// Ensure bookings directory exists
$dir = "bookings";
if (!is_dir($dir)) {
    mkdir($dir, 0755, true);
}


$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
$result = '';
$maxIndex = strlen($characters) - 1;

for ($i = 0; $i < 8; $i++) {
    $index = mt_rand(0, $maxIndex);
    $result .= $characters[$index];
}

// Use existing bookingId from payload or generate new
if (isset($data['bookingId']) && $data['bookingId'] != '') {
    $bookingId = $data['bookingId'];
} else {
    //$bookingId = uniqid('booking_', true);
    $bookingId = 'TPI-' . $result;
    $data['bookingId'] = $bookingId; // add it to payload
}

// Filename = userId + bookingId
$file = $dir . "/" . $userId . "_" . $bookingId . ".json";

// If file exists, merge/update payload; else create new
if (file_exists($file)) {
    $existingData = json_decode(file_get_contents($file), true);
    // Merge old data with new (new keys overwrite old)
    $data = array_merge($existingData, $data);
}

// Save file
file_put_contents($file, json_encode($data));

// Return response
echo json_encode(array(
    'success' => true,
    'bookingId' => $bookingId,
    'file' => $file,
    'data' => $data
));
?>