<?php
header("Content-Type: application/json");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(array("error" => "Method not allowed"));
    exit;
}

// Read input JSON
$data = json_decode(file_get_contents("php://input"), true);
$email = isset($data['email']) ? $data['email'] : null;
$password = isset($data['password']) ? $data['password'] : null;

// Validate email
if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(array("error" => "Invalid email"));
    exit;
}

// Validate password presence
if (!$password) {
    http_response_code(400);
    echo json_encode(array("error" => "Password is required"));
    exit;
}

// Path to users.json
$file = "users.json";

// Ensure the file exists
if (!file_exists($file)) {
    file_put_contents($file, json_encode(array()));
}

// Load users
$users = json_decode(file_get_contents($file), true);
if (!is_array($users)) {
    $users = array();
}

// Flag to track if user exists
$userFound = false;

// Loop through users to find email
foreach ($users as $user) {
    if (isset($user['email']) && $user['email'] === $email) {
        $userFound = true;

        // Check if password exists and matches
        //if (!empty($user['profile']['password']) && password_verify($password, $user['profile']['password'])) {
        if (!empty($user['profile']['password']) && $password === $user['profile']['password']) {
            http_response_code(200);
            echo json_encode([
                "email"   => $email,
                "message" => "Login successful",
                "user"    => $user   // 🔥 FULL User object
            ]);            
            
        } else {
            http_response_code(401);
            echo json_encode(array(
                "email" => $email,
                "message" => "You are not an authorized user"
            ));
        }
        exit;
    }
}

// User not found
if (!$userFound) {
    http_response_code(401);
    echo json_encode(array(
        "email" => $email,
        "message" => "Account does not exist"
    ));
}
