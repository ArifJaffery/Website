<?php
header("Content-Type: application/json");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Read input JSON
$data = json_decode(file_get_contents("php://input"), true);
$email = isset($data['email']) ? $data['email'] : null;

if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(array("error" => "Invalid email"));
    exit;
}

// Path to users.json
$file = "users.json";

// Ensure the file exists
if (!file_exists($file)) {
    file_put_contents($file, json_encode(array()));
}

// Load users
$users = json_decode(file_get_contents($file), true);
if (!is_array($users)) $users = array();

$userIndex = null;
foreach ($users as $index => $u) {
    if (isset($u['email']) && $u['email'] === $email) {
        $userIndex = $index;
        break;
    }
}

// Existing user
if ($userIndex !== null) {
    $user = $users[$userIndex];

    // User has password set
    if (!empty($user['profile']['password'])) {
        echo json_encode(array(
            "email" => $email,
            "action" => "enter_password",
            "message" => "Please enter your password to login."
        ));
        exit;
    }

    // No password, generate code
    $code = rand(100000, 999999);
    $expiry = time() + (15 * 60);

    $users[$userIndex]['code'] = $code;
    $users[$userIndex]['expires'] = $expiry;

    file_put_contents($file, json_encode($users, JSON_PRETTY_PRINT));

    // TODO: send email
    // mail($email, "Verification Code", "Your code is $code");

    echo json_encode(array(
        "email" => $email,
        "action" => "send_code",
        "message" => "Verification code sent to your email.",
        "code" => $code // remove in production
    ));
    exit;
}

// New user — create entry
$code = rand(100000, 999999);
$expiry = time() + (15 * 60);

$users[] = array(
    "email" => $email,
    "verified" => false,
    "code" => $code,
    "expires" => $expiry,
    "createdAt" => date(DATE_ATOM),
    "role" => "user",
    "profile" => array()
);

file_put_contents($file, json_encode($users, JSON_PRETTY_PRINT));

// TODO: send email
// mail($email, "Verification Code", "Your code is $code");

echo json_encode(array(
    "email" => $email,
    "action" => "send_code",
    "message" => "Verification code sent to your email.",
    "code" => $code // remove in production
));
