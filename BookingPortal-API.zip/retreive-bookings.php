<?php
header("Content-Type: application/json");

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Only POST allowed']);
    exit;
}

// Read POST body
$input = file_get_contents("php://input");
$data = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON: ' . json_last_error_msg()]);
    exit;
}

// Check that userid is provided
if (empty($data['userid'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing userid']);
    exit;
}

//$userid = $data['userid'];
$userid = preg_replace('/[^a-zA-Z0-9_-]/', '', $data['userid']); // sanitize

$bookingFolder = "bookings";
$results = [];

// Check if folder exists
if (!is_dir($bookingFolder)) {
    http_response_code(500);
    echo json_encode(['error' => 'Bookings folder not found']);
    exit;
}

// Scan all files in bookings folder
//$files = glob($bookingFolder . '/booking_*' . $userid . '*.json');
$files = glob($bookingFolder . '/' . $userid . '*.json');

foreach ($files as $file) {
    $jsonContent = file_get_contents($file);
    $decoded = json_decode($jsonContent, true);
    if ($decoded) {
        $results[] = $decoded;
    }
}

// Return results
echo json_encode($results);
