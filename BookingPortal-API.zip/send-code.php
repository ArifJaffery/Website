<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Content-Type: application/json");

// Preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Read input JSON
$data = json_decode(file_get_contents("php://input"), true);

// Validate email from payload
$email = isset($data['primaryEmail']) ? filter_var($data['primaryEmail'], FILTER_VALIDATE_EMAIL) : false;
if (!$email) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid email"]);
    exit;
}

$file = "users.json";

// Ensure file exists
if (!file_exists($file)) {
    file_put_contents($file, json_encode([]));
}

// Load existing users safely
$users = json_decode(file_get_contents($file), true);
if (!is_array($users)) {
    $users = [];
}

// Check if user exists
foreach ($users as $user) {
    if (isset($user['email']) && $user['email'] === $email) {
        // User exists — return message
        http_response_code(409); // Conflict
        echo json_encode(["message" => "User already exists"]);
        exit;
    }
}

// Generate verification code & expiry
$code = rand(100000, 999999);
$expires = time() + 300; // 5 min

$userId = uniqid('user_', true); // Example: user_641f9d2b4a6b8.12345678

// Add new user
$users[] = [
    "userId"    => $userId,
    "email"     => $email,
    "verified"  => false,
    "code"      => $code,
    "expires"   => $expires,
    "createdAt" => date(DATE_ATOM),
    "role"      => "user",
    "profile"   => $data
];

// Save users safely
file_put_contents($file, json_encode($users, JSON_PRETTY_PRINT));

// Return success
echo json_encode([
    "success" => true,
    "code" => $code
]);
