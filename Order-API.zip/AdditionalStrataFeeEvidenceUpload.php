<?php

$uploadDir = __DIR__ . "/uploads/";

if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}


$filename = isset($_GET['filename']) ? basename($_GET['filename']) : '';

if (!$filename) {
    echo "Filename missing";
    exit;
}

$data = file_get_contents("php://input");

if (!$data) {
    echo "No body data received";
    exit;
}

$filePath = $uploadDir . $filename;

if (file_put_contents($filePath, $data)) {
    echo "File saved: " . $filename;
} else {
    echo "Failed to save file";
}

?>