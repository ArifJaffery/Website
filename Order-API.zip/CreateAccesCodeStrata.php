<?php
// index.php or api.php

// Simple router
$requestUri = $_SERVER['REQUEST_URI'];
$requestMethod = $_SERVER['REQUEST_METHOD'];
$securedCardData = $_POST['SecuredCardData'];

if ($requestUri === '/CreateAccesCodeStrata.php' && $requestMethod === 'POST') {
    header('Content-Type: application/json');

    // Replace with your eWAY API key and password
    $apiKey = 'A1001ANv6x5sjmjup26xBzQ6LOivv0EAz4BXEvZE3N9X+czP3tt4xldpPjpAM7BO6p6UAO';
    $apiPass = 'D4fDZZD29245';
    
    
    $apiEndpoint = 'https://api.ewaypayments.com/AccessCodes';
    // Use https://api.ewaypayments.com for production

    // Example transaction data
    $transactionData = [
        'Customer' => [
            "Reference" => "A12345",
            "Title" => "Mr",
            "FirstName" => "Xyz",
            "LastName" => "ABC",
            "Email" => "admin@tpi.com.au",
            "Street1" => "45 Evans",
            "City" => "Balmain",
            "State" => "NSW",
            "PostalCode" => "2000",
            "Country" => "AU",
            "Phone" => "0298765432",
            "Mobile" => "610410155344",   
            "Comments" => "Invoice#123"
        ],
        'Payment' => [
            'TotalAmount' => 100, // Amount in cents (e.g. $10.00)
            'InvoiceNumber' => 'INV-12345',
            'InvoiceDescription' => 'Test Transaction',
            'CurrencyCode' => 'AUD'
        ],
        'RedirectUrl' => 'https://thepropertyinspectors.com.au/eway-response-strata-handler.php',
        'CancelUrl'   => 'https://thepropertyinspectors.com.au/eway-response--strata-handler.php',        
        'TransactionType' => 'Purchase'
    ];

    // Initialize cURL
    $ch = curl_init($apiEndpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($ch, CURLOPT_USERPWD, $apiKey . ':' . $apiPass);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($transactionData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    $logFile = __DIR__ . "/api_log.txt"; // store logs in a safe location
    //$logEntry = sprintf(
      //  "[%s] Request: %s\nResponse: %s\nHTTP Code: %s\nError: %s\n\n",
        //date("Y-m-d H:i:s"),
        //json_encode($transactionData, JSON_PRETTY_PRINT),
        //$response,
        //$httpCode,
        //$curlError ?: "None"
    //);

    $logEntry = sprintf("Request: %s\n",$securedCardData);


    // Append to log file
    file_put_contents($logFile, $logEntry, FILE_APPEND);
    
    if ($response === false) {
      echo json_encode(['error' => 'cURL failed']);
      exit;
    }
    

    if ($httpCode === 200) {
        $result = json_decode($response, true);
        echo json_encode([
            'success' => true,
            'accessCode' => $result['AccessCode'] ,
            'formActionURL' => $result['FormActionURL'] 
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => $response
        ]);
    }
    exit;
}

// Fallback
http_response_code(404);
echo json_encode(['error' => 'Endpoint not found']);

?>