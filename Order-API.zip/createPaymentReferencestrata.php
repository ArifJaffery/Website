<?php
    if (
        isset($_POST['TotalAmountIncludingGST']) &&
        floatval($_POST['TotalAmountIncludingGST']) == 0
    ) {
        
        $invoiceRef = isset($_POST['InvoiceReference']) ? $_POST['InvoiceReference'] : '';

        $transactionID = isset($_POST['Transaction']) && is_numeric($_POST['Transaction'])
            ? (int)$_POST['Transaction']
            : 0;
        
        
        $amount = 0;
        $status = 'Approved';

        SavePaymentRefererenceToDataverse(
            $invoiceRef,
            $amount,
            $status,
            $transactionID
        );

        header('HTTP/1.1 200 OK');
        echo 'Zero amount transaction processed successfully';
        exit;
}


    function getToken() {
        $tenantId = "765bb9c7-c916-4c22-8206-591682876419";
        $clientId = "7b5db71f-f402-45f4-b693-838a5f19b32b";
        $clientSecret = ".KM8Q~H4W5UgLClq6nO4cMNYzerKK~FKp7yorcSF";
        $scope = "https://tpi.api.crm6.dynamics.com/.default";
    
        $url = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token";
    
        $postFields = http_build_query([
            'client_id' => $clientId,
            'client_secret' => $clientSecret,
            'scope' => $scope,
            'grant_type' => 'client_credentials'
        ]);
    
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded'
        ]);
    
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
    
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            if (isset($data['access_token'])) {
                $logFile = __DIR__ . '/api_log.txt';
                $logEntry = "----- " . date('Y-m-d H:i:s') . " -----\n";
                $logEntry .= "Access Token: " . substr($data['access_token'], 0, 50) . "... (truncated)\n\n";
                file_put_contents($logFile, $logEntry, FILE_APPEND);                
                
                return $data['access_token'];
            } else {
                error_log("Token response missing access_token: $response");
                return null;
            }
        } else {
            error_log("Failed to get token (HTTP $httpCode): $response");
            return null;
        }
    }

    function SavePaymentRefererenceToDataverse($paymentReference,$totalAmountIncludingGST,$status,$transaction){
        $payLoad = [
            'PaymentReference' => $paymentReference,
            'TotalAmountIncludingGST' => floatval($totalAmountIncludingGST),
            'Status' => $status,
            'Transaction' => $transaction
        ];
    
    
//        $url = "https://ea2bfe60ba8748708cb9e126087c45.46.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/52ee7fb9863a4155969202f8dfd4d34f/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=bzz4z7pBl3ycSju9S0hh2x4G3jC1kQk9hpYSNLNHIZk";
  
        $url ="https://ea2bfe60ba8748708cb9e126087c45.46.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/2c01045749614ba580d200f6c568d0f4/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=GVZOGGxrS-ajidDjS8048jY4ynl5yWM9gqXsIdpQp5k";  
    
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payLoad));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);
    
        $response = curl_exec($ch);
        
        if ($response === false) {
            $error = curl_error($ch);
            error_log("Power Automate call failed: $error");
        } else {
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($httpCode < 200 || $httpCode >= 300) {
                error_log("Power Automate call returned HTTP $httpCode: $response");
            }
        }        
        
        curl_close($ch);

    }


    $logFile = __DIR__ . '/api_log.txt';
    $logEntry = "----- " . date('Y-m-d H:i:s') . " -----\n";
    $logEntry .= "POST Data:\n" . print_r($_POST, true) . "\n";
    $logEntry .= "GET Data:\n" . print_r($_GET, true) . "\n\n";
    
    
    $apiKey = 'C3AB9ATDmEkBXOCFsXK81q+RG1X35oXI2z87aTJbaSWgJ5A9+OpX69eOLAquri7Gmqzwts';
    $apiPassword = 'D4fDZZD2';
    
    
    $accessCode = null;
    if (isset($_POST['AccessCode'])) {
        $accessCode = $_POST['AccessCode'];
    } elseif (isset($_GET['AccessCode'])) {
        $accessCode = $_GET['AccessCode'];
    }
    
    if (!$accessCode) {
        $logEntry .= "No AccessCode provided.\n\n";
        file_put_contents($logFile, $logEntry, FILE_APPEND);
        die("No AccessCode provided.");
    }
    
    // Use sandbox or live endpoint depending on environment
    
    $endpoint = "https://api.ewaypayments.com/GetAccessCodeResult.json";
    
    
    
    $ch = curl_init($endpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //curl_setopt($ch, CURLOPT_USERPWD, $apiKey . ":" . $apiPass);
    curl_setopt($ch, CURLOPT_USERPWD, "$apiKey:$apiPassword");
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(["AccessCode" => $accessCode]));
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $data = json_decode($response, true);
    
    if (isset($data['Errors']) && $data['Errors']) {
        $logEntry .= "Payment failed: " . $data['Errors'] . "\n";
    } else {
        $logEntry .= "Payment successful!\n";
        $logEntry .= "Transaction ID: " . $data['TransactionID'] . "\n";
        $logEntry .= "Status: " . ($data['TransactionStatus'] ? "Approved" : "Declined") . "\n";
        $logEntry .= "Amount: " . ($data['TotalAmount']/100) . " AUD\n";
        $logEntry .= "Invoice Ref: " . $data['InvoiceReference'] . "\n";
    }
    
    $logEntry .= "\n";
    file_put_contents($logFile, $logEntry, FILE_APPEND);
    
    
    $transactionID = isset($data['TransactionID']) ? $data['TransactionID'] : '';
    $status = !empty($data['TransactionStatus']) ? "Approved" : "Declined";
    $amount = isset($data['TotalAmount']) ? ($data['TotalAmount']/100) : 0;
    $invoiceRef = isset($data['InvoiceReference']) ? $data['InvoiceReference'] : '';

    try {
        SavePaymentRefererenceToDataverse($invoiceRef, $amount,$status,$transactionID);
    } catch (Exception $e) {
        error_log("Exception saving payment reference: " . $e->getMessage());
        // Continue rendering page
    }



?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Payment Confirmation</title>
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f4f6f9;
           display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
    .card { background: #fff; padding: 2rem 2.5rem; border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1); max-width: 420px; width: 100%; text-align: center; }
    h2 { color: <?= $status === "Approved" ? "#28a745" : "#dc3545" ?>; margin-bottom: 1rem; }
    .details { text-align: left; margin-top: 1.5rem; }
    .details p { margin: 0.5rem 0; font-size: 0.95rem; color: #333; }
    .footer { margin-top: 1.5rem; font-size: 0.85rem; color: #777; }
  </style>
</head>
<body>
  <div class="card">
    <h2><?= $status === "Approved" ? "Payment Successful!" : "Payment Declined" ?></h2>
    
    
    <div class="details">
      <p><strong>Transaction ID:</strong> <?= htmlspecialchars($transactionID) ?></p>
      <p><strong>Status:</strong> <?= htmlspecialchars($status) ?></p>
      <p><strong>Amount:</strong> <?= number_format($amount, 2) ?> AUD</p>
      <p><strong>Invoice Ref:</strong> <?= htmlspecialchars($invoiceRef) ?></p>
    </div>
    <div class="footer">
      <?= $status === "Approved" ? "Thank you for your payment." : "
      Please attempt payment again to allow our office to commence work as per the approved work order. Without payment, we cannot inspect or produce the report for your property" ?>
    </div>
  </div>
</body>
</html>