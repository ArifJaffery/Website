<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Get raw POST data
$rawData = file_get_contents('php://input');
if (!$rawData) {
    http_response_code(400);
    echo '{"status":"error","message":"No file content received"}';
    exit;
}

// Get filename from query string (or default)
$filename = isset($_GET['filename']) ? basename($_GET['filename']) : 'uploaded_file.bin';

// Make sure upload folder exists
$uploadDir = dirname(__FILE__).'/uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Save file
$destination = $uploadDir . $filename;
$fp = fopen($destination, 'wb');
if ($fp === false) {
    http_response_code(500);
    echo '{"status":"error","message":"Cannot open file for writing"}';
    exit;
}
fwrite($fp, $rawData);
fclose($fp);

echo '{"status":"success","message":"File uploaded successfully","file":"'.$destination.'"}';
?>