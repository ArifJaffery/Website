<?php
// API credentials

$apiKey = 'A1001ANv6x5sjmjup26xBzQ6LOivv0EAz4BXEvZE3N9X+czP3tt4xldpPjpAM7BO6p6UAO';
$apiPassword = 'D4fDZZD29245';
//$apiEndpoint = "https://api.sandbox.ewaypayments.com/Transaction";
$apiEndpoint = "https://api.ewaypayments.com/Transaction";


// Request payload
$requestData = [
    "Customer" => [
        "CardDetails" => [
            "Name"        => "John Smith",
            "Number"      => "4444333322221111",
            "ExpiryMonth" => "12",
            "ExpiryYear"  => "25",
            "CVN"         => "123"
        ]
    ],
    "Payment" => [
        "TotalAmount" => 1000
    ],
    "Method"          => "ProcessPayment",
    "TransactionType" => "Purchase"
];

// Initialize cURL
$ch = curl_init($apiEndpoint);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
curl_setopt($ch, CURLOPT_USERPWD, "$apiKey:$apiPassword");
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

// Execute request
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);
$data = json_decode($response, true);
echo json_encode($data, JSON_PRETTY_PRINT);

?>
