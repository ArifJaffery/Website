<?php
// Your eWAY API credentials

$apiKey = 'A1001ANv6x5sjmjup26xBzQ6LOivv0EAz4BXEvZE3N9X+czP3tt4xldpPjpAM7BO6p6UAO';
$apiPassword = 'D4fDZZD29245';


// Get AccessCode from query string
if (!isset($_GET['AccessCode'])) {
    echo "AccessCode not provided.";
    exit;
}

$accessCode = $_GET['AccessCode'];

// Endpoint to retrieve transaction result
$apiEndpoint = "https://api.ewaypayments.com/AccessCode/$accessCode";

$ch = curl_init($apiEndpoint);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERPWD, "$apiKey:$apiPassword");
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
curl_close($ch);

if ($response === false) {
    echo "cURL failed.";
    exit;
}

$data = json_decode($response, true);

// Check transaction status
if (isset($data['TransactionStatus']) && $data['TransactionStatus'] === true) {
    echo "<h2>Payment Successful</h2>";
    echo "<p>Transaction ID: " . htmlspecialchars($data['TransactionID']) . "</p>";
    echo "<p>Amount: $" . number_format($data['TotalAmount'] / 100, 2) . " " . htmlspecialchars($data['CurrencyCode']) . "</p>";
    echo "<p>Response Message: " . htmlspecialchars($data['ResponseMessage']) . "</p>";
} else {
    echo "<h2>Payment Failed</h2>";

    $responseCode = isset($data['ResponseCode']) ? $data['ResponseCode'] : 'N/A';
    $responseMessage = isset($data['ResponseMessage']) ? $data['ResponseMessage'] : 'Unknown error';

    echo "<p>Response Code: " . htmlspecialchars($responseCode) . "</p>";
    echo "<p>Response Message: " . htmlspecialchars($responseMessage) . "</p>";
    
    echo "<pre>" . print_r($data, true) . "</pre>"; // Debugging info
}
?>
