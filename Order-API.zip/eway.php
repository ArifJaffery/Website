<?php
$apiKey = 'A1001ANv6x5sjmjup26xBzQ6LOivv0EAz4BXEvZE3N9X+czP3tt4xldpPjpAM7BO6p6UAO';
$apiPassword = 'D4fDZZD29245';

$apiEndpoint = 'https://api.ewaypayments.com/AccessCodes';

// Build request payload (example)
$requestData = [
  "Customer" => [
    "Reference" => "A12345",
    "Title" => "Mr",
    "FirstName" => trim("Xyz"),
    "LastName" => trim("ABC"),
    "Email" => "admin@tpi.com.au",
    "Street1" => "45 Evans",
    "City" => "Balmain",
    "State" => "NSW",
    "PostalCode" => "2000",
    "Country" => "AU",
    "Phone" => preg_replace('/\D/', '', "0298765432"),
    "Mobile" => preg_replace('/\D/', '', "0470158344"),   
    "Comments" => "Invoice#123"
  ],
  "Payment" => [
    "TotalAmount" => 10000, // $100.00 AUD (amount is in cents!)
    "CurrencyCode" => "AUD"
  ],
  "RedirectUrl" => "https://thepropertyinspectors.com.au/eway-response-handler.php",
  "Method" => "ProcessPayment",
  "TransactionType" => "Purchase"
];

$ch = curl_init($apiEndpoint);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
curl_setopt($ch, CURLOPT_USERPWD, "$apiKey:$apiPassword");
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
curl_close($ch);

$logFile = __DIR__ . "/api_log.txt"; // store logs in a safe location
$logEntry = sprintf(
    "[%s] Request: %s\nResponse: %s\nHTTP Code: %s\nError: %s\n\n",
    date("Y-m-d H:i:s"),
    json_encode($requestData, JSON_PRETTY_PRINT),
    $response,
    $httpCode,
    $curlError ?: "None"
);

// Append to log file
file_put_contents($logFile, $logEntry, FILE_APPEND);

if ($response === false) {
  echo json_encode(['error' => 'cURL failed']);
  exit;
}

$data = json_decode($response, true);

// Return only what frontend needs
if (isset($data['AccessCode']) && isset($data['FormActionURL'])) {
  echo json_encode([
    'AccessCode' => $data['AccessCode'],
    'FormActionURL' => $data['FormActionURL']
  ]);
  
} else {
  echo json_encode(['error' => 'AccessCode or FormActionURL missing', 'details' => $data]);
}
?>
