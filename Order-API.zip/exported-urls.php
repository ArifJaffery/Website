<?php

/*
 * To manually get a list of all the URLs in your WordPress site, create a new file with the name export.php and open it.
 * Now login to your site�s FTP account using FileZilla or any other equivalent FTP software. Once logged in, upload the newly created file into your site�s root directory.
 * Once the file is uploaded, fire up your browser and enter the URL � http://yourdomain.com/exported-urls.php in the address bar.
 * Now the uploaded file will be executed and you will get a list of all the post URLs in your WordPress site.
 */

include "wp-load.php";

$posts = new WP_Query('post_type=any&posts_per_page=-1&post_status=publish');
$posts = $posts->posts;

header('Content-type:text/plain');
foreach ($posts as $post) {
    switch ($post->post_type) {
        case 'revision':
        case 'nav_menu_item':
            break;
        case 'page':
            $permalink = get_page_link($post->ID);
            break;
        case 'post':
            $permalink = get_permalink($post->ID);
            break;
        case 'attachment':
            $permalink = get_attachment_link($post->ID);
            break;
        default:
            $permalink = get_post_permalink($post->ID);
            break;
    }
    echo "\n{$permalink}";
    //echo "\n{$post->post_type}\t{$permalink}\t{$post->post_title}";
}
?>