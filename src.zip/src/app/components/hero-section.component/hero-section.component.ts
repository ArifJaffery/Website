import { Component} from '@angular/core';
import { NgIf } from '@angular/common'; // <-- add this
import { CtaSectionComponent } from '../cta-section.component/cta-section.component';
import { HeaderComponent } from '../header.component/header.component';

@Component({
  selector: 'app-hero-section',
  standalone: true,
  templateUrl: './hero-section.component.html',
  styleUrls: ['./hero-section.component.css'],
  imports: [NgIf, CtaSectionComponent, HeaderComponent]
})
export class HeroSectionComponent {  

  showRegistration = false;
  toggleReportType(type: string) {
    console.log('Selected report type:', type);
  }

  update() {
    console.log('Address input updated');
  }

  submit() {
    console.log('Submit clicked');
  }

  // Emit event to parent
  onRegisterClick() {
    console.log('Register button clicked');    
    this.showRegistration = true;
  } 

  onCodeSent(email: string) {
    console.log('Code sent from CTA section:', email);
    //this.showRegistration = false; // optional: hide form
  }

  onVerified() {
    console.log('Verification completed!');
    //this.showRegistration = false; // optional: hide registration after verification
  }


}
