import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],  // ✅ CommonModule provides *ngIf
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  @Output() codeSent = new EventEmitter<string>();

  email = '';
  code = '';
  step = 1;
  message = '';

  constructor(private auth: AuthService) {}

  sendCode() {
    this.message = '';
    this.auth.sendVerificationCode(this.email).subscribe({
      next: (response) => {
        console.log('PHP Response send:', response);
        this.step = 2;
        this.message = 'Verification code sent!';
        this.codeSent.emit(this.email);
      },
      error: (err) => {
        console.error(err);
        this.message = err?.error?.message || 'Failed to send verification code.';
      }
    });
  }

  verify() {
    this.message = '';
    this.auth.verifyCode(this.email, this.code).subscribe({
      next: (response) => {
        console.log('PHP Response verify:', response);
        this.message = 'Profile created successfully!';
      },
      error: (err) => {
        console.error(err);
        this.message = err?.error?.message || 'Invalid or expired verification code.';
      }
    });
  }
}
