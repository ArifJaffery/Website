
// import { Component, EventEmitter, Output } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { AuthService } from '../../core/services/auth.service';
// import { NgIf } from '@angular/common'; // <-- add this

// @Component({
//   selector: 'app-register',
//   standalone: true,
//   imports: [CommonModule, FormsModule, NgIf],  // ✅ CommonModule provides *ngIf
//   templateUrl: './register.component.html',
//   styleUrls: ['./register.component.css']
// })
// export class RegisterComponent {
//   @Output() codeSent = new EventEmitter<string>();


//   step = 1;
//   email = '';
//   code = '';
//   message = '';

//   // All registration fields
//   firstName = '';
//   lastName = '';
//   homePhone = '';
//   mobile = '';
//   unitNumber = '';
//   streetNumber = '';
//   streetName = '';
//   suburb = '';
//   city = '';
//   state = '';

//   constructor(private auth: AuthService) {}

//   focusField(field: HTMLInputElement) {
//     field.scrollIntoView({ behavior: 'smooth', block: 'center' });
//   }


//   // Send verification code with all fields at once
//   sendCode() {
//     this.message = '';

//     const registrationData = {
//       email: this.email,
//       firstName: this.firstName,
//       lastName: this.lastName,
//       homePhone: this.homePhone,
//       mobile: this.mobile,
//       unitNumber: this.unitNumber,
//       streetNumber: this.streetNumber,
//       streetName: this.streetName,
//       suburb: this.suburb,
//       city: this.city,
//       state: this.state
//     };

//     this.auth.sendVerificationCode(registrationData).subscribe({
//       next: (response) => {
//         console.log('PHP Response send:', response);
//         this.message = 'Verification code sent! Please check your email.';
//         this.codeSent.emit(this.email);
//       },
//       error: (err) => {
//         console.error(err);
//         this.message = err?.error?.message || 'Failed to send verification code.';
//       }
//     });
//   }

//   // Verify code
//   verify() {
//     this.message = '';
//     this.auth.verifyCode(this.email, this.code).subscribe({
//       next: (response) => {
//         console.log('PHP Response verify:', response);
//         this.message = 'Your account has been verified!';
//       },
//       error: (err) => {
//         console.error(err);
//         this.message = err?.error?.message || 'Invalid or expired verification code.';
//       }
//     });
//   }
// }

import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  AbstractControl,
  AsyncValidatorFn
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable, of, timer } from 'rxjs';
import { switchMap, map, catchError } from 'rxjs/operators';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  @Output() codeSent = new EventEmitter<string>();

  registerForm!: FormGroup;
  step = 1;
  message = '';

  constructor(
    private fb: FormBuilder,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.registerForm = this.fb.group(
      {
        email: ['', [Validators.required, Validators.email]],
        firstName: ['', [Validators.required, Validators.maxLength(30)]],
        lastName: ['', [Validators.required, Validators.maxLength(30)]],
        homePhone: ['', [Validators.required, Validators.pattern(/^[0-9]{6,15}$/)]],
        mobile: ['', [Validators.required, Validators.pattern(/^[0-9]{6,15}$/)]],
        unitNumber: ['', [Validators.required, Validators.maxLength(5), Validators.pattern(/^[a-zA-Z0-9]*$/)]],
        streetNumber: ['', [Validators.required, Validators.maxLength(6)]],
        streetName: ['', [Validators.required, Validators.maxLength(50)]],
        suburb: ['', [Validators.required, Validators.maxLength(50)]],
        city: ['', [Validators.required, Validators.maxLength(50)]],
        state: ['', [Validators.required, Validators.maxLength(30)]],
      },
      {
        asyncValidators: [this.addressAsyncValidator()]
      }
    );
  }

  sendCode(): void {
    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      return;
    }

    // 🔁 Replace with your real API call
    this.http.post('/api/send-code', this.registerForm.value).subscribe({
      next: () => {
        this.message = 'Verification code sent!';
        this.step = 2;

        // ✅ Notify parent
        this.codeSent.emit(this.registerForm.value.email);
      },
      error: () => {
        this.message = 'Failed to send verification code.';
      }
    });
  }

  // 🔄 Async address validator
  private addressAsyncValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Observable<{ [key: string]: any } | null> => {
      const value = control.value;

      if (!value || !value.streetName || !value.suburb || !value.state) {
        return of(null);
      }

      return timer(600).pipe(
        switchMap(() =>
          this.http.post<any>('https://your-address-validation-api.com/validate', {
            unitNumber: value.unitNumber,
            streetNumber: value.streetNumber,
            streetName: value.streetName,
            suburb: value.suburb,
            state: value.state
          }).pipe(
            map(res => (res.valid ? null : { invalidAddress: true })),
            catchError(() => of({ invalidAddress: true }))
          )
        )
      );
    };
  }

  // Helper for template
  get f() {
    return this.registerForm.controls;
  }
}
