import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = '/api';


  constructor(private http: HttpClient) {}

  sendVerificationCode(email: string) {
    return this.http.post(`${this.api}/send-code`, { email });
  }

  verifyCode(email: string, code: string) {
    return this.http.post(`${this.api}/verify-code`, { email, code });
  }
}
