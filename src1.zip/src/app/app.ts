import { Component, signal } from '@angular/core';
import { HeroSectionComponent } from './components/hero-section.component/hero-section.component';
import { FeaturesGridComponent } from './components/features-grid.component/features-grid.component';
import { CtaSectionComponent } from './components/cta-section.component/cta-section.component';
import { NgIf } from '@angular/common';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [HeroSectionComponent, FeaturesGridComponent, CtaSectionComponent, NgIf, RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  showRegister = false;

  protected readonly title = signal('vendor-booking-portal');


}
