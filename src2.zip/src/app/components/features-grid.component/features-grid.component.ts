import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeatureCardComponent } from '../feature-card.component/feature-card.component';

@Component({
  selector: 'app-features-grid',
  standalone: true,
  imports: [CommonModule,  FeatureCardComponent],
  templateUrl: './features-grid.component.html',
  styleUrls: ['./features-grid.component.css']
})
export class FeaturesGridComponent {

  cards = [
    {
      image: 'https://cdn.hubblecontent.osi.office.net/m365content/publish/11b97469-2733-4dcd-b1a6-3be27ae498b6/thumbnails/xxlarge.jpg',
      title: 'Order Reports',
      description: 'Quickly order and pay for your building inspection reports online with ease.'
    },
    {
      image: 'https://cdn.hubblecontent.osi.office.net/m365content/publish/d22d83c8-3fb2-4168-8902-a29dc31e95b1/thumbnails/xxlarge.jpg',
      title: 'Buy Existing Reports',
      description: 'Access and purchase previously completed reports at your convenience.'
    },
    {
      image: 'https://cdn.hubblecontent.osi.office.net/m365content/publish/a85ad439-8c85-4ad0-b1cd-ca07eb4cf760/thumbnails/xxlarge.jpg',
      title: 'Book Appointments',
      description: 'Schedule your building inspection appointments easily through our portal.'
    },
    {
      image: 'https://cdn.hubblecontent.osi.office.net/m365content/publish/d4d28980-dfbe-4716-b6e0-3642de0acd6c/thumbnails/xxlarge.jpg',
      title: 'Our Team',
      description: 'Our experienced inspectors are dedicated to providing thorough and reliable inspection services.',
      buttonText: 'Meet Our Team',
      buttonLink: '/'
    }
  ];

}
