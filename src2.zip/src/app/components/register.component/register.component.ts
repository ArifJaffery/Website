
// import { Component, EventEmitter, Output } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { AuthService } from '../../core/services/auth.service';
// import { NgIf } from '@angular/common'; // <-- add this

// @Component({
//   selector: 'app-register',
//   standalone: true,
//   imports: [CommonModule, FormsModule, NgIf],  // ✅ CommonModule provides *ngIf
//   templateUrl: './register.component.html',
//   styleUrls: ['./register.component.css']
// })
// export class RegisterComponent {
//   @Output() codeSent = new EventEmitter<string>();


//   step = 1;
//   email = '';
//   code = '';
//   message = '';

//   // All registration fields
//   firstName = '';
//   lastName = '';
//   homePhone = '';
//   mobile = '';
//   unitNumber = '';
//   streetNumber = '';
//   streetName = '';
//   suburb = '';
//   city = '';
//   state = '';

//   constructor(private auth: AuthService) {}

//   focusField(field: HTMLInputElement) {
//     field.scrollIntoView({ behavior: 'smooth', block: 'center' });
//   }


//   // Send verification code with all fields at once
//   sendCode() {
//     this.message = '';

//     const registrationData = {
//       email: this.email,
//       firstName: this.firstName,
//       lastName: this.lastName,
//       homePhone: this.homePhone,
//       mobile: this.mobile,
//       unitNumber: this.unitNumber,
//       streetNumber: this.streetNumber,
//       streetName: this.streetName,
//       suburb: this.suburb,
//       city: this.city,
//       state: this.state
//     };

//     this.auth.sendVerificationCode(registrationData).subscribe({
//       next: (response) => {
//         console.log('PHP Response send:', response);
//         this.message = 'Verification code sent! Please check your email.';
//         this.codeSent.emit(this.email);
//       },
//       error: (err) => {
//         console.error(err);
//         this.message = err?.error?.message || 'Failed to send verification code.';
//       }
//     });
//   }

//   // Verify code
//   verify() {
//     this.message = '';
//     this.auth.verifyCode(this.email, this.code).subscribe({
//       next: (response) => {
//         console.log('PHP Response verify:', response);
//         this.message = 'Your account has been verified!';
//       },
//       error: (err) => {
//         console.error(err);
//         this.message = err?.error?.message || 'Invalid or expired verification code.';
//       }
//     });
//   }
// }

// import { Component, EventEmitter, Output, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import {
//   FormBuilder,
//   FormGroup,
//   Validators,
//   ReactiveFormsModule
// } from '@angular/forms';
// import { AuthService } from '../../core/services/auth.service';

// @Component({
//   selector: 'app-register',
//   standalone: true,
//   imports: [CommonModule, ReactiveFormsModule],
//   templateUrl: './register.component.html',
//   styleUrls: ['./register.component.css']
// })
// export class RegisterComponent implements OnInit {

//   @Output() codeSent = new EventEmitter<string>();

//   registerForm!: FormGroup;

//   step = 1;
//   message = '';

//   constructor(
//     private fb: FormBuilder,
//     private auth: AuthService
//   ) {}

//   ngOnInit(): void {
//     this.registerForm = this.fb.group({
//       email: ['', [Validators.required, Validators.email]],
//       code: [''],

//       firstName: ['', [Validators.required, Validators.maxLength(30)]],
//       lastName: ['', [Validators.required, Validators.maxLength(30)]],

//       homePhone: ['', [Validators.required, Validators.pattern(/^[0-9]{6,15}$/)]],
//       mobile: ['', [Validators.required, Validators.pattern(/^[0-9]{6,15}$/)]],

//       unitNumber: ['', [Validators.required, Validators.maxLength(5), Validators.pattern(/^[a-zA-Z0-9]*$/)]],
//       streetNumber: ['', [Validators.required, Validators.maxLength(6)]],
//       streetName: ['', [Validators.required, Validators.maxLength(50)]],
//       suburb: ['', [Validators.required, Validators.maxLength(50)]],
//       city: ['', [Validators.required, Validators.maxLength(50)]],
//       state: ['', [Validators.required, Validators.maxLength(30)]]
//     });
//   }

//   focusField(field: HTMLInputElement) {
//     field.scrollIntoView({ behavior: 'smooth', block: 'center' });
//   }

//   // ✅ Send verification code (TS4111-safe)
//   sendCode(): void {
//     this.message = '';

//     if (this.registerForm.invalid) {
//       this.registerForm.markAllAsTouched();
//       return;
//     }
//     const registrationData = {
//       email: this.registerForm.get('email')?.value,
//       code: this.registerForm.get('code')?.value,
//         firstName: this.registerForm.get('firstName')?.value,
//         lastName: this.registerForm.get('lastName')?.value,
//         homePhone: this.registerForm.get('homePhone')?.value,
//         mobile: this.registerForm.get('mobile')?.value,
//         unitNumber: this.registerForm.get('unitNumber')?.value,
//         streetNumber: this.registerForm.get('streetNumber')?.value,
//         streetName: this.registerForm.get('streetName')?.value,
//         suburb: this.registerForm.get('suburb')?.value,
//         city: this.registerForm.get('city')?.value,
//         state: this.registerForm.get('state')?.value      
//     };

//     console.log(`registrationData => ${JSON.stringify(registrationData, null, 2)}`);

//     const email = this.registerForm.get('email')?.value; // TS4111-safe access

//     this.auth.sendVerificationCode(registrationData).subscribe({
//       next: (response) => {
//         console.log('PHP Response send:', response);
//         this.message = 'Verification code sent! Please check your email.';
//         this.step = 2;
//         this.codeSent.emit(email); // ✅ no TS4111 error
//       },
//       error: (err) => {
//         console.error(err);
//         this.message = err?.error?.message || 'Failed to send verification code.';
//       }
//     });
//   }

//   // ✅ Verify code (TS4111-safe)
//   verify(): void {
//     this.message = '';

//     const email = this.registerForm.get('email')?.value;
//     const code = this.registerForm.get('code')?.value;

//     this.auth.verifyCode(email, code).subscribe({
//       next: (response) => {
//         console.log('PHP Response verify:', response);
//         this.message = 'Your account has been verified!';
//       },
//       error: (err) => {
//         console.error(err);
//         this.message = err?.error?.message || 'Invalid or expired verification code.';
//       }
//     });
//   }

//   // Helper for template access
//   get f() {
//     return this.registerForm.controls;
//   }
// }
import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormArray } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  @Output() codeSent = new EventEmitter<string>();

  registerForm!: FormGroup;
  step = 1;
  message : string | undefined ;
  existingUserData: any;

  // Business type options
  businessTypes = [
    'Real Estate Agent', 'Buyer’s Agent', 'Solicitor / Conveyancer', 'Architect',
    'Project Manager', 'Builder', 'Strata Manager', 'Developer', 'Other'
  ];

  jobTypes = [
    'Pre-purchase inspection- Building & Pest Inspections',
    'Pre Purchase Inspection – Strata Inspections',
    'Dilapidation report',
    'Structural assessment',
    'General Building Defect inspections',
    'Waterproofing / water ingress assessment',
    'Expert witness / litigation support',
    'Commercial inspections',
    'Other'
  ];

  constructor(private fb: FormBuilder, private auth: AuthService) {}

  ngOnInit(): void {
    
    this.registerForm = this.fb.group({
      // Step 1: Business Details
      businessName: ['', Validators.required],
      companyName: [''],
      abnAcn: ['', Validators.required],
      businessType: ['', Validators.required],
      businessTypeOther: [''],
      officeAddress: ['', Validators.required],
      website: [''],

      // Step 2: Primary Contact
      primaryFullName: ['', Validators.required],
      primaryPosition: ['', Validators.required],
      primaryMobile: ['', [Validators.required, Validators.pattern(/^[0-9]{10,15}$/)]],
      primaryEmail: ['', [Validators.required, Validators.email]],
      contactTextMessage: [true],
      contactEmail: [true],
      contactPhoneMobile: [true],
      contactPhoneOffice: [true],


      // Step 3: Accounts / Billing Contact
      listingAgentName: ['',Validators.required],
      listingAgentEmail: ['',[Validators.required, Validators.email]],
      listingAgentPhoneLandline: ['',[Validators.required,Validators.pattern(/^(\(0[2378]\)|0[2378])\s?\d{4}\s?\d{4}$/)]],
      listingAgentPhoneMobile: ['',[Validators.required, Validators.pattern(/^[0-9]{10,15}$/)]],      

      coListingAgentName: ['',Validators.required],
      coListingAgentPhoneLandline: ['',Validators.required],
      coListingAgentPhoneMobile: ['',[Validators.required, Validators.pattern(/^[0-9]{10,15}$/)]],
      coListingAgentEmail: ['',[Validators.required, Validators.email]],
      
      salesAdminName: ['',Validators.required],
      salesAdminPhoneLandline: ['',Validators.required],
      salesAdminPhoneMobile: ['',[Validators.required, Validators.pattern(/^[0-9]{10,15}$/)]],
      salesAdminEmail: ['',[Validators.required, Validators.email]],

      accountsName: ['',Validators.required],
      accountsPhoneLandline: ['',Validators.required],
      accountsPhoneMobile: ['',[Validators.required, Validators.pattern(/^[0-9]{10,15}$/)]],
      accountsEmail: ['',[Validators.required, Validators.email]],


      // Step 4: Booking & Job Details
      jobTypes: this.fb.array([], Validators.required),
      areasOperated: [''],
      jobsPerMonth: ['', Validators.required],

      // Step 5: Payment & Terms
      invoiceAddress: ['', Validators.required],
      paymentMethod: ['', Validators.required],

    // Individual checkboxes for payment terms
      term7DaysAgent: [false],
      termAtOrderAgent: [false],
      termAtOrderClient: [false],


      // Step 6: Online Account Setup
      username: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      // additionalUsers: ['No'],

      // Step 8: Compliance / Agreement
      authorised: [false, Validators.requiredTrue],
      agreeTc: [false, Validators.requiredTrue],
      agreePrivacy: [false, Validators.requiredTrue],
      consent: [false],

      // Step 9: Optional
      howHeard: [''],
      notes: [''],
      priorityBooking: ['No'],

      // Step 9 verification code
      email: [''],

      // Step 10 verification code
      code: ['']
    });
  }

  get jobTypesArray() {
    return this.registerForm.get('jobTypes') as FormArray;
  }

  toggleJobType(job: string, event: any) {
    if (event.target.checked) {
      this.jobTypesArray.push(this.fb.control(job));
    } else {
      const index = this.jobTypesArray.controls.findIndex(x => x.value === job);
      this.jobTypesArray.removeAt(index);
    }
  }

  focusField(field: HTMLInputElement) {
    field.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }


  nextStep() {
    if (this.step === 2 && !this.shouldShowStep3) {
      this.step = 4; // skip Step 3
      return;
    }
    this.step++;
  }

  previousStep() {
    if (this.step === 4 && !this.shouldShowStep3) {
      this.step = 2; // skip Step 3 backwards
      return;
    }
    this.step--;
  }


  setMessage =  (msg: string) =>{
    this.message = msg;
  }

  getMessage = () => {
    return this.message;
  }


  sendCode() {    

    // Prepare flat registration data for backend
    const registrationData = { ...this.registerForm.value };
    console.log(`registrationData => ${JSON.stringify(registrationData)}`);   

    delete registrationData.code; // code is separate

    const email = this.registerForm.get('email')?.value;

    console.log(`email => ${email}`);

    this.auth.sendVerificationCode(registrationData,).subscribe({
      next: (res) => {
        this.message = 'Verification code sent! Please check your email.';
        this.step = 10;
        this.codeSent.emit(email);
      },
      error: (err: HttpErrorResponse) => {       
        console.error('Send code error:', err);          
        if (err.status === 409) {
          // Set a manual error on the email FormControl
          this.f['email'].setErrors({ duplicate: err.error?.message || 'Email already exists' });
        } else if (err.error && typeof err.error === 'string') {
          this.message = err.error;
        } else if (err.error?.message) {
          this.message = err.error.message;
        } else {
          this.message = err.message || 'Failed to send verification code.';
        }
      }
    });
  }

  verify() {
    const email = this.registerForm.get('primaryEmail')?.value;
    const code = this.registerForm.get('code')?.value;

    this.auth.verifyCode(email, code).subscribe({
      next: (res) => {
        this.message = 'Your account has been verified!';
      },
      error: (err) => {
        this.message = err?.error?.message || 'Invalid or expired verification code.';
      }
    });
  }

  // Helper for template access
  get f() {
    return this.registerForm.controls;
  }

  getStepTitle(step: number): string {
    switch (step) {
      case 1:
        return 'Business Details';
      case 2:
        return 'Director / CEO / Principal';
      case 3:
        return 'Accounts / Admin / Co-Agent';
      case 4:
        return 'Booking & Job Details';
      // case 5:
      //   return 'Inspection Preferences';
      case 5:
        return 'Payment & Terms';
      case 6:
        return 'Online Account Setup';
      case 7:
        return 'Compliance & Agreement';
      case 8:
        return 'Additional Information';
      case 9:
        return 'Create your account';
      case 10:
        return 'Verify your email';
        
      default:
        return '';
    }
  }
  
anyTermChecked(): boolean {
  const { term7DaysAgent, termAtOrderAgent, termAtOrderClient } = this.registerForm.value;
  return term7DaysAgent || termAtOrderAgent || termAtOrderClient;
}

// Inside your component class
activeSection:   'Listing Agent' | 'Co Listing Agent' | 'Sales Admin' | 'Accounts' = 'Listing Agent';

selectSection(section: 'Listing Agent' | 'Co Listing Agent' | 'Sales Admin' | 'Accounts') {
  this.activeSection = section;
}

get shouldShowStep3(): boolean {
  const type = this.registerForm.get('businessType')?.value;
  return type === 'Real Estate Agent' || type === 'Buyer’s Agent';
}

}
