import { Component , Input} from '@angular/core';
import { TimeBoxComponent } from '../time-box.component/time-box.component';
import { TimeBoxHeaderComponent} from '../time-box-header.component/time-box-header.component';

import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-time-grid',
  templateUrl: './time-grid.component.html',
  styleUrls: ['./time-grid.component.scss'],
  imports: [ TimeBoxComponent, CommonModule,TimeBoxHeaderComponent ]
})
export class TimeGridComponent {
 @Input() dates: string[] = [];

  rows = Array.from({ length: 5 });
  cols = Array.from({ length: 5 });
}
