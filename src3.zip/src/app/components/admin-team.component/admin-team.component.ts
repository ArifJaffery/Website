// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-admin-team',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './admin-team.component.html',
//   styleUrls: ['./admin-team.component.css']
// })
// export class AdminTeamComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {}

//   ngOnInit(): void {
//     // Add form controls for admin team member
//     this.formGroup.addControl('givenName', this.fb.control(''));
//     this.formGroup.addControl('surname', this.fb.control(''));
//     this.formGroup.addControl('email', this.fb.control(''));
//     this.formGroup.addControl('mobilePhone', this.fb.control(''));
//   }
// }


import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-admin-team',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './admin-team.component.html',
  styleUrls: ['./admin-team.component.css']
})
export class AdminTeamComponent implements OnInit {
  @Input() parentForm!: FormGroup; // <-- changed from formGroup

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('AdminTeamComponent: parentForm is not provided!');
      return;
    }

    // Add form controls if they don't already exist
    if (!this.parentForm.get('givenName')) {
      this.parentForm.addControl('givenName', this.fb.control(''));
    }
    if (!this.parentForm.get('surname')) {
      this.parentForm.addControl('surname', this.fb.control(''));
    }
    if (!this.parentForm.get('email')) {
      this.parentForm.addControl('email', this.fb.control(''));
    }
    if (!this.parentForm.get('mobilePhone')) {
      this.parentForm.addControl('mobilePhone', this.fb.control(''));
    }
  }
}
