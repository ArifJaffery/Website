import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators , FormsModule, FormControl} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BookingInspectionRequest } from '../../core/models/bookingrequest.model';

// Child Components
import { ListingAgentComponent } from '../listing-agent.component/listing-agent.component';
import { CoListingAgentComponent } from '../co-listing-agent.component/co-listing-agent.component';
import { AdminTeamComponent } from '../admin-team.component/admin-team.component';
import { NotificationPartyComponent } from '../notification-party.component/notification-party.component';
import { VendorComponent } from '../vendor.component/vendor.component';
import { PropertyAddressComponent } from '../property-address.component/property-address.component';
import { InspectionScheduleComponent } from '../inspection-schedule.component/inspection-schedule.component';
import { PropertyAccessComponent } from '../property-access.component/property-access.component';
import { CostModelComponent } from '../cost-model.component/cost-model.component';
import { PaymentMethodComponent } from '../payment-method.component/payment-method.component';
import { PoolDetailsComponent } from '../pool-details.component/pool-details.component';
import { SecondDwellingComponent } from '../second-dwelling.component/second-dwelling.component';
import { SaleTypeComponent } from '../sale-type.component/sale-type.component';
import { OpenHouseAuctionComponent } from '../open-house-auction.component/open-house-auction.component';
import { SpecialInstructionsComponent } from '../special-instructions.component/special-instructions.component';
import { TermsAndConditionsComponent } from '../terms-and-conditions.component/terms-and-conditions.component';
import { PreInspectionAgreementComponent } from '../pre-inspection-agreement.component/pre-inspection-agreement.component';
import { ContractAcknowledgementComponent } from '../contract-acknowledgement.component/contract-acknowledgement.component';
import { ContactComponent } from '../contact-component/contact-component';
import { ContactType } from '../../core/models/contact.model';

@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    ContactComponent,
    ListingAgentComponent,
    CoListingAgentComponent,
    AdminTeamComponent,
    NotificationPartyComponent,
    VendorComponent,
    PropertyAddressComponent,
    InspectionScheduleComponent,
    PropertyAccessComponent,
    CostModelComponent,
    PaymentMethodComponent,
    PoolDetailsComponent,
    SecondDwellingComponent,
    SaleTypeComponent,
    OpenHouseAuctionComponent,
    SpecialInstructionsComponent,
    TermsAndConditionsComponent,
    PreInspectionAgreementComponent,
    ContractAcknowledgementComponent,    
  ],
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  bookingForm!: FormGroup;
  currentStep = 1;
  step: number = 1;
  totalSteps = 17;
  ContactType = ContactType;
  selectedContactType: ContactType = ContactType.ListingAgent; 
  selectedContactTypeControl!: FormControl;

  stepTitles: string[] = [
    '', // index 0 unused
    'Business Contacts',
    'Primary Contact',
    'Accounts / Admin / Co-Agent',
    'Booking & Job Details',
    'Payment & Terms',
    'Online Account Setup',
    'Compliance / Agreement',
    'Optional Info',
    'Verification Code'
  ];

   getStepTitle(step: number): string {
    return this.stepTitles[step] || '';
   }  

  constructor(private fb: FormBuilder) {}


    createContactGroup(contactType: ContactType): FormGroup {
    return this.fb.group({
      contactType: [contactType],
      givenName: ['', Validators.required],
      surname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobilePhone: ['', Validators.required],
    });
  }


  ngOnInit(): void {
    this.bookingForm = this.fb.group({
      listingAgent: this.fb.group({}),
      coListingAgent: this.fb.group({}),
      adminTeam: this.fb.group({}),
      notificationParty: this.fb.group({}),

      contacts:  this.fb.array([
        this.fb.group({ givenName: '', surname: '', email: '', mobilePhone: '', contactType: ContactType.ListingAgent }),
        this.fb.group({ givenName: '', surname: '', email: '', mobilePhone: '', contactType: ContactType.CoListingAgent }),
        this.fb.group({ givenName: '', surname: '', email: '', mobilePhone: '', contactType: ContactType.AdministrationTeam }),
        ]),

      vendorHusband: this.fb.group({}),
      vendorWife: this.fb.group({}),
      propertyAddress: this.fb.group({}),
      inspectionSchedule: this.fb.group({}),
      propertyAccess: this.fb.group({}),
      costModel: this.fb.group({}),
      paymentMethod: this.fb.group({}),
      poolDetails: this.fb.group({}),
      secondDwelling: this.fb.group({}),
      saleType: this.fb.group({}),
      openHouseAuction: this.fb.group({}),
      specialInstructions: this.fb.group({}),
      termsAndConditions: this.fb.group({}),
      preInspectionAgreement: this.fb.group({}),
      contractAcknowledgement: this.fb.group({}),
      orderCompleted: [false],
      paymentProcessingInstructions: ['']
    });

    this.selectedContactTypeControl = this.fb.control(ContactType.ListingAgent);

  }


    get contacts(): FormArray {
    return this.bookingForm.get('contacts') as FormArray;
    }

    get contactsFormGroups(): FormGroup[] {
    return this.contacts.controls.map(c => c as FormGroup);
    }




  nextStep() {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
    }
  }

  prevStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  submitBooking() {
    if (this.bookingForm.valid) {
      const payload: BookingInspectionRequest = this.bookingForm.value;
      console.log('Booking Payload:', payload);
      // TODO: send payload to API
    } else {
      console.warn('Form is invalid');
    }
  }

    get listingAgentForm(): FormGroup {
    return this.bookingForm.get('listingAgent') as FormGroup;
    }

    get vendorHusbandForm(): FormGroup {
    return this.bookingForm.get('vendorHusband') as FormGroup;
    }

    get coListingAgentForm(): FormGroup {
    return this.bookingForm.get('coListingAgent') as FormGroup;
    }

    get adminTeamForm(): FormGroup {
    return this.bookingForm.get('adminTeam') as FormGroup;
    }

    get NotificationPartyForm(): FormGroup {
    return this.bookingForm.get('notificationParty') as FormGroup;
    }

    // addContact(type: ContactType = ContactType.ListingAgent) {
    //     this.contacts.push(this.createContactGroup(type));
    // }

    addContact(type: ContactType = ContactType.ListingAgent) {
    this.contacts.push(this.createContactGroup(type));
    }



    // Remove contact by index
    removeContact(index: number) {
        this.contacts.removeAt(index);
    }

}
