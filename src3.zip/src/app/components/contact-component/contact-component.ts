import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Contact, ContactType } from '../../core/models/contact.model';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './contact-component.html',
  styleUrls: ['./contact-component.css']
})
export class ContactComponent implements OnInit {
  @Input() parentForm!: FormGroup; // <-- changed from formGroup
  @Input() contactType!: ContactType;

  
  ngOnInit() {
    if (!this.parentForm) {
      console.warn('ContactComponent: parentForm is not provided!');
      return;
    }
    const fb = new FormBuilder();
    // Only add controls if they don't already exist
    if (!this.parentForm.get('givenName')) {
      this.parentForm.addControl('givenName', fb.control(''));
    }
    if (!this.parentForm.get('surname')) {
      this.parentForm.addControl('surname', fb.control(''));
    }
    if (!this.parentForm.get('email')) {
      this.parentForm.addControl('email', fb.control(''));
    }
    if (!this.parentForm.get('mobilePhone')) {
      this.parentForm.addControl('mobilePhone', fb.control(''));
    }
  }
}
