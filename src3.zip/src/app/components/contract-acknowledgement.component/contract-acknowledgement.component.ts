// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';     

//     @Component({
//   selector: 'app-contract-acknowledgement',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './contract-acknowledgement.component.html',
//   styleUrls: ['./contract-acknowledgement.component.css']
// })
// export class ContractAcknowledgementComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {} // ✅ Inject FormBuilder

//   ngOnInit(): void {
//     this.formGroup.addControl('acknowledged', this.fb.control(false));
//     this.formGroup.addControl('acknowledgementDateTime', this.fb.control(''));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contract-acknowledgement',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './contract-acknowledgement.component.html',
  styleUrls: ['./contract-acknowledgement.component.css']
})
export class ContractAcknowledgementComponent implements OnInit {
  @Input() parentForm!: FormGroup; // ✅ updated

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('ContractAcknowledgementComponent: parentForm is not provided!');
      return;
    }

    if (!this.parentForm.get('acknowledged')) {
      this.parentForm.addControl('acknowledged', this.fb.control(false));
    }
    if (!this.parentForm.get('acknowledgementDateTime')) {
      this.parentForm.addControl('acknowledgementDateTime', this.fb.control(''));
    }
  }
}
