// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-cost-model',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './cost-model.component.html',
//   styleUrls: ['./cost-model.component.css']
// })
// export class CostModelComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {} // ✅ Inject FormBuilder

//   ngOnInit(): void {
//     // Add reactive form controls
//     [
//       'type',
//       'vendorOrAgentWantCopy',
//       'freeReportAgentVendor',
//       'vendorPaysOneOff',
//       'buyerVendorSmallUpfront',
//       'vendorBuyerFreeFinalBuyerPays',
//       'vendorPaysReducedBuyerPaysReduced'
//     ].forEach(field => this.formGroup.addControl(field, this.fb.control(false)));
//   }
// }

import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-cost-model',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './cost-model.component.html',
  styleUrls: ['./cost-model.component.css']
})
export class CostModelComponent implements OnInit {
  @Input() parentForm!: FormGroup; // ✅ updated to parentForm

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('CostModelComponent: parentForm is not provided!');
      return;
    }

    const fields = [
      'type',
      'vendorOrAgentWantCopy',
      'freeReportAgentVendor',
      'vendorPaysOneOff',
      'buyerVendorSmallUpfront',
      'vendorBuyerFreeFinalBuyerPays',
      'vendorPaysReducedBuyerPaysReduced'
    ];

    fields.forEach(field => {
      if (!this.parentForm.get(field)) {
        this.parentForm.addControl(field, this.fb.control(field === 'type' ? '' : false));
      }
    });
  }
}
