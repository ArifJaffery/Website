import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-feature-card',
  standalone: true,
  templateUrl: './feature-card.component.html',
  styleUrls: ['./feature-card.component.css'],
  imports: [CommonModule]
})
export class FeatureCardComponent {
  @Input() image = '';
  @Input() title = '';
  @Input() description = '';
  @Input() buttonText?: string;
  @Input() buttonLink?: string;

goToLink() {
  if (this.buttonLink) {
    window.location.href = this.buttonLink;
  }
}
}
