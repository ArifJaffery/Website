import { Component, EventEmitter, Output } from '@angular/core';
import { UserService } from '../../core/services/user.service';
import { Observable } from 'rxjs';
import { User } from '../../core/models/user.model';
import { CommonModule } from '@angular/common'; // <-- required for async pipe

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  @Output() registerClicked = new EventEmitter<void>();
  @Output() loginClicked = new EventEmitter<void>();  

  
 user$: Observable<User | null>;

 constructor(private userService: UserService) {
   this.user$ = this.userService.user$;
 }


  onRegisterClick() {
    this.registerClicked.emit();
  }

  onLoginClick (){
    this.loginClicked.emit();
  }

}
