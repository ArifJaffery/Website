import { Component} from '@angular/core';
import { NgIf } from '@angular/common'; 
import { CtaSectionComponent } from '../cta-section.component/cta-section.component';
import { HeaderComponent } from '../header.component/header.component';
import { LoginComponent} from '../login.component/login.component';
import { PropertyReportSelectorComponent } from '../../components/property-report-selector.component/property-report-selector.component';
import { BookingComponent } from '../../components/booking.component/booking.component';

@Component({
  selector: 'app-hero-section',
  standalone: true,
  templateUrl: './hero-section.component.html',
  styleUrls: ['./hero-section.component.css'],
  imports: [NgIf, CtaSectionComponent, HeaderComponent, LoginComponent, PropertyReportSelectorComponent, BookingComponent]
})
export class HeroSectionComponent {  

  showRegistration = false;
  showLogin = false;
  showBookingRequest = false;

  toggleReportType(type: string) {
    console.log('Selected report type:', type);
  }

  update() {
    console.log('Address input updated');
  }

  createBooking() {
    this.showBookingRequest   = ! this.showBookingRequest;
  }
  
  onRegisterClick() {
    console.log('Register button clicked');    
    this.showRegistration = !this.showRegistration;
  } 
  onLoginClick() 
  {
    console.log('Login button clicked');
    this.showLogin = !this.showLogin;
  }

  onCodeSent(email: string) {
    console.log('Code sent from CTA section:', email);    
  }

  onVerified() {
    console.log('Verification completed!');    
  }

  loginSuccess(emailL:any) {
    console.log('Login successful from Login Component!');
    this.showLogin = !this.showLogin ;    
  }

  onPropertyReportSelected(event: { propertyType: string; reportType: string }) {
    console.log('Selected:', event.propertyType, event.reportType);
  }

}
