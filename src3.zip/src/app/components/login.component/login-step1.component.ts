import { Component, EventEmitter,  Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login-step1',  
  imports: [ FormsModule, CommonModule ],
  templateUrl: './login-step1.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponentStep1 {  
  @Output() step1Emitter = new EventEmitter<string>();  
  
  email = '';
  

  requestLogin(){
    this.step1Emitter.emit(this.email);
  }

}
