// import { Component, EventEmitter, Output } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { AuthService } from '../../core/services/auth.service';

// @Component({
//   selector: 'app-login-step1',
//   standalone: true,
//   imports: [CommonModule, FormsModule],
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponentStep1 {
//   @Output() loginSuccess = new EventEmitter<string>();

//   loginMode: 'password' | 'code' | null = null;
//   password = '';  
//   email = '';
//   code = '';
//   message = '';
//   loading = false;
//   constructor(private auth: AuthService) {}

//  verifyLogin(){
    
//   }
// }
