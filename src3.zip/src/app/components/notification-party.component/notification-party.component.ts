// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';


// @Component({
//   selector: 'app-notification-party',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './notification-party.component.html',
//   styleUrls: ['./notification-party.component.css']
// })
// export class NotificationPartyComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {}

//   ngOnInit(): void {
//     this.formGroup.addControl('givenName', this.fb.control(''));
//     this.formGroup.addControl('surname', this.fb.control(''));
//     this.formGroup.addControl('email', this.fb.control(''));
//     this.formGroup.addControl('mobilePhone', this.fb.control(''));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-notification-party',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './notification-party.component.html',
  styleUrls: ['./notification-party.component.css']
})
export class NotificationPartyComponent implements OnInit {
  /** Parent form passed from BookingComponent */
  @Input() parentForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('NotificationPartyComponent: parentForm is not provided!');
      return;
    }

    // Add form controls for notification party
    this.parentForm.addControl('givenName', this.fb.control(''));
    this.parentForm.addControl('surname', this.fb.control(''));
    this.parentForm.addControl('email', this.fb.control(''));
    this.parentForm.addControl('mobilePhone', this.fb.control(''));
  }
}
