// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';


// @Component({
//   selector: 'app-open-house-auction',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './open-house-auction.component.html',
//   styleUrls: ['./open-house-auction.component.css']
// })
// export class OpenHouseAuctionComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {} // ✅ inject FormBuilder

//   ngOnInit(): void {
//     // Add reactive form controls
//     this.formGroup.addControl('firstOpenHouseDateTime', this.fb.control(''));
//     this.formGroup.addControl('auctionDateTime', this.fb.control(''));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-open-house-auction',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './open-house-auction.component.html',
  styleUrls: ['./open-house-auction.component.css']
})
export class OpenHouseAuctionComponent implements OnInit {
  /** Parent form passed from BookingComponent */
  @Input() parentForm!: FormGroup;

  constructor(private fb: FormBuilder) {} 

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('OpenHouseAuctionComponent: parentForm is not provided!');
      return;
    }

    // Add reactive form controls
    this.parentForm.addControl('firstOpenHouseDateTime', this.fb.control(''));
    this.parentForm.addControl('auctionDateTime', this.fb.control(''));
  }
}
