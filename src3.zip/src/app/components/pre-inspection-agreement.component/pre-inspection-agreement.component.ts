// import { Component, Input, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-pre-inspection-agreement',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './pre-inspection-agreement.component.html',
//   styleUrls: ['./pre-inspection-agreement.component.css']
// })
// export class PreInspectionAgreementComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {} // ✅ inject FormBuilder

//   ngOnInit(): void {
//     // Add reactive form controls
//     this.formGroup.addControl('accepted', this.fb.control(false));
//     this.formGroup.addControl('acceptanceDateTime', this.fb.control(''));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-pre-inspection-agreement',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './pre-inspection-agreement.component.html',
  styleUrls: ['./pre-inspection-agreement.component.css']
})
export class PreInspectionAgreementComponent implements OnInit {
  /** Parent form passed from BookingComponent */
  @Input() parentForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('PreInspectionAgreementComponent: parentForm is not provided!');
      return;
    }

    // Add reactive form controls
    this.parentForm.addControl('accepted', this.fb.control(false));
    this.parentForm.addControl('acceptanceDateTime', this.fb.control(''));
  }
}
