// import { Component, Input, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-sale-type',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './sale-type.component.html',
//   styleUrls: ['./sale-type.component.css']
// })
// export class SaleTypeComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {} // ✅ inject FormBuilder

//   ngOnInit(): void {
//     // Add reactive form controls
//     const controls = ['type', 'auctionDate', 'agencyAgreementExpiry', 'eoiExpiry'];
//     controls.forEach(f => this.formGroup.addControl(f, this.fb.control('')));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sale-type',
  standalone: true, // Angular 14+ standalone component
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './sale-type.component.html',
  styleUrls: ['./sale-type.component.css']
})
export class SaleTypeComponent implements OnInit {
  @Input() formGroup!: FormGroup;

  saleTypes = ['Auction', 'For Sale', 'Expression Of Interest', 'Off Market'];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    // Add form controls with optional validators
    this.formGroup.addControl('type', this.fb.control('', Validators.required));
    this.formGroup.addControl('auctionDate', this.fb.control(''));
    this.formGroup.addControl('agencyAgreementExpiry', this.fb.control(''));
    this.formGroup.addControl('eoiExpiry', this.fb.control(''));
  }
}
