// import { Component, Input, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-special-instructions',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './special-instructions.component.html',
//   styleUrls: ['./special-instructions.component.css']
// })
// export class SpecialInstructionsComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {} // ✅ inject FormBuilder

//   ngOnInit(): void {
//     this.formGroup.addControl(
//       'instructions',
//       this.fb.control('')
//     );
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-special-instructions',
  standalone: true, // Angular 14+ feature
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './special-instructions.component.html',
  styleUrls: ['./special-instructions.component.css']
})
export class SpecialInstructionsComponent implements OnInit {
  @Input() formGroup!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    // Add reactive form control with optional max length
    if (!this.formGroup.contains('instructions')) {
      this.formGroup.addControl(
        'instructions',
        this.fb.control('', [Validators.maxLength(500)])
      );
    }
  }
}
