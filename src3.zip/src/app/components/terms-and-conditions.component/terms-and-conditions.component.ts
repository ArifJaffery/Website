// import { Component, Input, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-terms-and-conditions',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './terms-and-conditions.component.html',
//   styleUrls: ['./terms-and-conditions.component.css']
// })
// export class TermsAndConditionsComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {} // ✅ inject here

//   ngOnInit(): void {
//     this.formGroup.addControl('approvedByListingAgent', this.fb.control(false));
//     this.formGroup.addControl('approvalDateTime', this.fb.control(''));
//     this.formGroup.addControl('referenceDocs', this.fb.control([]));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-terms-and-conditions',
  standalone: true, // Angular 14+ standalone component
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './terms-and-conditions.component.html',
  styleUrls: ['./terms-and-conditions.component.css']
})
export class TermsAndConditionsComponent implements OnInit {
  @Input() formGroup!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    // Add reactive form controls with validation
    if (!this.formGroup.contains('approvedByListingAgent')) {
      this.formGroup.addControl('approvedByListingAgent', this.fb.control(false, Validators.requiredTrue));
    }

    if (!this.formGroup.contains('approvalDateTime')) {
      this.formGroup.addControl('approvalDateTime', this.fb.control('', Validators.required));
    }

    if (!this.formGroup.contains('referenceDocs')) {
      this.formGroup.addControl('referenceDocs', this.fb.control(''));
    }
  }
}
