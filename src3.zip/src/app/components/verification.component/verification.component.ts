// import { Component } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { AuthService } from '../../core/services/auth.service';

// @Component({
//   selector: 'app-verification',
//   standalone: true,
//   imports: [CommonModule, FormsModule],
//   templateUrl: './verification.component.html',
//   styleUrls: ['./verification.component.css']
// })
// export class VerificationComponent {
//   email = ''; // pre-fill from registration or input
//   code = '';
//   step = 2; // start directly at verification step
//   message = '';

//   constructor(private auth: AuthService) {}

//   verify() {
//     if (!this.email || !this.code) {
//       this.message = 'Email and code are required';
//       return;
//     }

//     this.auth.verifyCode(this.email, this.code).subscribe({
//       next: () => {
//         this.message = 'Verification successful! Profile created.';
//         this.step = 3; // optional, to show success screen
//       },
//       error: (err) => {
//         console.error(err);
//         this.message = 'Verification failed. Please check the code and try again.';
//       }
//     });
//   }
// }

import { Component, Input } from '@angular/core'; // <-- add Input
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import {  Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-verification',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './verification.component.html',
  styleUrls: ['./verification.component.css']
})
export class VerificationComponent {
  @Input() email = ''; // <-- make email bindable from parent
  @Output() verified = new EventEmitter<void>();
  code = '';
  step = 2; // start directly at verification step
  message = '';

  constructor(private auth: AuthService) {}

verify() {
  this.message = '';
  this.auth.verifyCode(this.email, this.code).subscribe({
    next: (response) => {
      console.log('PHP Response verify:', response);
      this.step = 3; // show success section
      this.message = 'Your account has been verified!';
      this.verified.emit(); // tell parent
    },
    error: (err) => {
      console.error(err);
      if (err.status === 409) {
        this.message = 'Email already verified';
        this.step = 3; // optional: jump to success
      } else {
        this.message = err?.error?.error || 'Verification failed. Please check the code and try again.';
      }
    }
  });
}



}
