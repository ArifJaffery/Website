// administration-team.ts

// Interface representing an Administration Team member
export interface AdministrationTeamMember {
  givenName: string;
  surname: string;
  email: string;
  mobilePhone: string;
}

// Array to store administration team members
export const administrationTeam: AdministrationTeamMember[] = [];

// Function to add a team member
export function addAdminTeamMember(member: AdministrationTeamMember): void {
  // Validation to ensure all fields are provided
  if (!member.givenName || !member.surname || !member.email || !member.mobilePhone) {
    throw new Error("All fields are required for administration team member.");
  }

  administrationTeam.push(member);
  console.log(`Administration team member added: ${member.givenName} ${member.surname}`);
}

// Function to list all administration team members
export function listAdminTeam(): void {
  if (administrationTeam.length === 0) {
    console.log("No administration team members added yet.");
    return;
  }

  console.log("Administration Team Members:");
  administrationTeam.forEach((member, index) => {
    console.log(
      `${index + 1}. ${member.givenName} ${member.surname} | Email: ${member.email} | Mobile: ${member.mobilePhone}`
    );
  });
}

// Example usage
/*
addAdminTeamMember({
  givenName: "Alice",
  surname: "Brown",
  email: "alice.brown@example.com",
  mobilePhone: "+61411223344"
});

listAdminTeam();
*/
