// api-payload.ts

import { ListingAgent } from "./listingagent.model";
import { CoListingAgent} from "./colistingagent.model";
import { AdministrationTeamMember } from "./adminteammember.model";
import { NotificationParty } from "./notificationparty.model";
import { Vendor } from "./vendor.model";
import { PropertyAddress } from "./propertyaddress.model";
import { InspectionSchedule } from "./inspectionschedule.model";
import { PropertyAccessOption } from "./propertyaccess.model";
import { CostModelOption } from "./costmodal.model";
import { PaymentMethod } from "./paymentmethod.model";
import { PoolDetails } from "./pooldetails.model";
import { SecondDwellingOption } from "./seconddwelling.model";
import { SaleTypeOption } from "./saletype.model";
import { OpenHouseAuction } from "./openhouseauction.model";
import { SpecialInstructions } from "./specialinstruction.model";
import { TermsAndConditions } from "./termsandconditions.model";
import { PreInspectionAgreement } from "./preinspectionagreement.model";
import { ContractAcknowledgement } from "./contractacknowledgment.model";
import { Contact, ContactType } from "./contact.model";

/**
 * Full Booking Inspection Request Payload
 */
export interface BookingInspectionRequest {
  // Section 1: Agents & Notifications
//   listingAgent: ListingAgent;
  listingAgent: Contact;
  coListingAgent?: Contact;
  adminTeam?: Contact;
  notificationParty?: NotificationParty;

  // Section 2: Vendor Details
  vendorHusband: Vendor;
  vendorWife?: Vendor;

  // Section 3: Property Address
  propertyAddress: PropertyAddress;

  // Section 4: Inspection Schedule
  inspectionSchedule: InspectionSchedule;

  // Section 5: Property Access
  propertyAccess: PropertyAccessOption;

  // Section 6: Cost Model / Qualifying Questions
  costModel: CostModelOption;

  // Section 7: Payment Method
  paymentMethod: PaymentMethod;

  // Section 8: Pool Details
  poolDetails?: PoolDetails;

  // Section 9: Second Dwelling / Granny Flat
  secondDwelling?: SecondDwellingOption;

  // Section 10: Type of Sale
  saleType: SaleTypeOption;

  // Section 11: Open House / Auction Date & Time
  openHouseAuction?: OpenHouseAuction;

  // Section 12: Special Instructions
  specialInstructions?: SpecialInstructions;

  // Section 13: Terms and Conditions Acceptance
  termsAndConditions: TermsAndConditions;

  // Section 14: Pre-Inspection Agreement
  preInspectionAgreement: PreInspectionAgreement;

  // Section 15: Contract Acknowledgement
  contractAcknowledgement: ContractAcknowledgement;

  // Section 16: Order Completion
  orderCompleted: boolean;

  // Section 17: Payment Processing Instructions
  paymentProcessingInstructions?: string; // optional notes for API/email logic
}

// Example Booking Inspection Request Payload
export const exampleBookingRequest: BookingInspectionRequest = {
  // Section 1
  listingAgent: {
    givenName: "John",
    surname: "Doe",
    email: "john.doe@agency.com",
    mobilePhone: "0412345678",
    contactType : ContactType.ListingAgent
  },
  coListingAgent: {
    givenName: "Jane",
    surname: "Smith",
    email: "jane.smith@agency.com",
    mobilePhone: "0412345679",
    contactType : ContactType.CoListingAgent
  },
  adminTeam: {
    givenName: "Admin",
    surname: "Team",
    email: "admin@agency.com",
    mobilePhone: "0412345000",
    contactType : ContactType.AdministrationTeam
  },
  notificationParty: {
    givenName: "Notifier",
    surname: "Person",
    email: "notify@agency.com",
    mobilePhone: "0412345111",
  },

  // Section 2
  vendorHusband: {
    givenName: "Arif",
    surname: "Jaffery",
    email: "admin@tpi.com.au",
    mobilePhone: "0412000000",
    usedForDiscountVoucher: true
  },

  vendorWife: {
    givenName: "Sara",
    surname: "Jaffery",
    email: "",
    mobilePhone: "",
    usedForDiscountVoucher: false   
  },


  // Section 3
  propertyAddress: {
    houseNumber: "12",
    streetName: "Example Street",
    suburb: "Sydney",
    postCode: "2000",
    state: "NSW",
  },

  // Section 4
  inspectionSchedule: {    
    inspectionDate: "2026-02-15",
    inspectionTime: "10:00",
  },

  // Section 5
  propertyAccess: {
    type: "Vendor",
    name: "Arif Jaffery",
    phone: "0412000000",
    email: "admin@tpi.com.au"
  },

  // Section 6
  costModel: {
  type: "QualifyingQuestions",
  vendorOrAgentWantCopy: true,
  freeReportAgentVendor: false,
  vendorPaysOneOff: false,
  buyerVendorSmallUpfront: true,
  vendorBuyerFreeFinalBuyerPays: false,
  vendorPaysReducedBuyerPaysReduced: false
},

  // Section 7
  paymentMethod: {
    type: "PayNow",
  },

  // Section 8
  poolDetails: {
    hasPool: true,
    requestComplianceCertificate: true,
  },

  // Section 9
  secondDwelling: {
    type: "Inspect",
    extraCharge: 275,
  },

  // Section 10
  saleType: {
    type: "Auction",
    auctionDate: "2026-03-01",
  },

  // Section 11
  openHouseAuction: {
    firstOpenHouseDateTime: "2026-02-20T10:00",
    auctionDateTime: "2026-03-01T14:00",
  },

  // Section 12
  specialInstructions: {
    instructions: "Please inspect the garage and pool area thoroughly.",
  },

  // Section 13
  termsAndConditions: {
    approvedByListingAgent: true,
    approvalDateTime: "2026-01-29T09:00:00",
    referenceDocs: [
      "Work Order / Terms and Conditions / Contract",
      "Responsibilities of Vendor / Agent / Buyer / Inspector",
      "TPI Standard Company Terms and Conditions",
    ],
  },

  // Section 14
  preInspectionAgreement: {
    accepted: true,
    acceptanceDateTime: "2026-01-29T09:05:00",
  },

  // Section 15
  contractAcknowledgement: {
    acknowledged: true,
    acknowledgementDateTime: "2026-01-29T09:10:00",
  },

  // Section 16
  orderCompleted: true,

  // Section 17
  paymentProcessingInstructions:
    "Agent chose Pay Now: send payment email and link for immediate payment.",
};