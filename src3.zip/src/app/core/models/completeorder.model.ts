// complete-order.ts

import { vendor } from "./vendor.model";  
import { propertyAddress } from "./propertyaddress.model";
import { inspectionSchedule } from "./inspectionschedule.model";
import { propertyAccess } from "./propertyaccess.model";
import { selectedCostModel } from "./costmodal.model";
import { selectedPaymentMethod } from "./paymentmethod.model";
import { poolDetails } from "./pooldetails.model";
import { secondDwellingSelection } from "./seconddwelling.model";
import { saleTypeSelection } from "./saletype.model";
import { openHouseAuction } from "./openhouseauction.model";
import { specialInstructions } from "./specialinstruction.model";
import { termsAndConditions } from "./termsandconditions.model";
import { preInspectionAgreement } from "./preinspectionagreement.model";
import { contractAcknowledgement } from "./contractacknowledgment.model";

/**
 * Section 16 – Complete My Order Now
 * Validates all required sections and marks the order as complete
 */

export interface CompleteOrderStatus {
  completed: boolean;
  completionDateTime?: string;
  message?: string;
}

export let orderStatus: CompleteOrderStatus = { completed: false };

/**
 * Validates the order and marks it as complete
 */
export function completeOrder(): CompleteOrderStatus {
  try {
    // Basic required checks
    if (!vendor ) {
      throw new Error("Vendor details are required.");
    }
    if (!propertyAddress) throw new Error("Property address is required.");
    if (!inspectionSchedule) throw new Error("Inspection schedule is required.");
    if (!propertyAccess) throw new Error("Property access details are required.");
    if (!selectedCostModel) throw new Error("Cost model must be selected.");
    if (!selectedPaymentMethod) throw new Error("Payment method must be selected.");
    if (!saleTypeSelection) throw new Error("Sale type must be selected.");
    if (!preInspectionAgreement || !preInspectionAgreement.accepted)
      throw new Error("Pre-Inspection Agreement must be accepted.");
    if (!termsAndConditions || !termsAndConditions.approvedByListingAgent)
      throw new Error("Terms and Conditions must be approved.");
    if (!contractAcknowledgement || !contractAcknowledgement.acknowledged)
      throw new Error("Contract acknowledgement is required.");

    // Optional sections
    const optionalSections = [
      poolDetails,
      secondDwellingSelection,
      openHouseAuction,
      specialInstructions,
    ];

    orderStatus = {
      completed: true,
      completionDateTime: new Date().toISOString(),
      message: "Order completed successfully.",
    };

    console.log(orderStatus.message);
    return orderStatus;
  } catch (error: any) {
    console.error("Order could not be completed:", error.message);
    return {
      completed: false,
      message: `Order incomplete: ${error.message}`,
    };
  }
}

// Example usage
/*
const result = completeOrder();
console.log(result);
*/
