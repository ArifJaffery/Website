// cost-model.ts

/**
 * Section 6 – Select the Cost Model for this order
 */

// Option 1: Directly select a cost model by number (1–14)
export interface CostModelSelection {
  type: "DirectSelection";
  modelNumber: number; // 1–14
}

// Option 2: View entire price list (reference only)
export interface CostModelPriceList {
  type: "PriceListSelection";
  selectedModelNumber?: number; // optional if they pick one after viewing
}

// Option 3: Use qualifying questions to determine best cost model
export interface CostModelQualifyingQuestions {
  type: "QualifyingQuestions";
  vendorOrAgentWantCopy: boolean; // 6.3.1
  freeReportAgentVendor: boolean; // 6.3.2
  vendorPaysOneOff: boolean; // 6.3.3
  buyerVendorSmallUpfront: boolean; // 6.3.4
  vendorBuyerFreeFinalBuyerPays: boolean; // 6.3.5
  vendorPaysReducedBuyerPaysReduced: boolean; // 6.3.6
}

// Union type for all cost model options
export type CostModelOption =
  | CostModelSelection
  | CostModelPriceList
  | CostModelQualifyingQuestions;

// Holds the selected cost model for this order
export let selectedCostModel: CostModelOption | null = null;

// Function to set cost model
export function setCostModel(costModel: CostModelOption): void {
  if (!costModel) throw new Error("Cost model selection is required.");

  selectedCostModel = costModel;
  console.log(`Cost model set: ${costModel.type}`);
}

// Function to get current cost model
export function getCostModel(): CostModelOption | null {
  return selectedCostModel;
}

// Example usage
/*
setCostModel({
  type: "DirectSelection",
  modelNumber: 5
});

setCostModel({
  type: "QualifyingQuestions",
  vendorOrAgentWantCopy: true,
  freeReportAgentVendor: false,
  vendorPaysOneOff: false,
  buyerVendorSmallUpfront: true,
  vendorBuyerFreeFinalBuyerPays: false,
  vendorPaysReducedBuyerPaysReduced: false
});

console.log(getCostModel());
*/
