// handle-payment.ts

import { selectedPaymentMethod, PaymentMethod } from "./paymentmethod.model";

/**
 * Section 17 – Handle Payment and Notifications
 * - If agent chose PayNow → send payment email/redirect
 * - If agent chose End of Month → send standard confirmation email
 * - If VendorDirect → send approval/confirmation email
 */

/**
 * Simulated function to send an email
 * @param recipient Email address
 * @param subject Email subject
 * @param body Email body
 */
function sendEmail(recipient: string, subject: string, body: string) {
  console.log(`Sending email to ${recipient}:\nSubject: ${subject}\n${body}`);
}

/**
 * Process payment and send appropriate email based on selected payment method
 */
export function processPaymentAndNotify(agentEmail: string): void {
  if (!selectedPaymentMethod) {
    throw new Error("Payment method not selected. Cannot proceed.");
  }

  const payment: PaymentMethod = selectedPaymentMethod;

  switch (payment.type) {
    case "PayNow":
      // Redirect agent to payment page / send payment link
      sendEmail(
        agentEmail,
        "Action Required: Complete Payment for Property Inspection",
        "Dear Agent,\n\nPlease complete your payment for the property inspection using the secure payment link provided.\n\nThank you."
      );
      console.log("Agent instructed to pay online now.");
      break;

    case "AgencyEOM":
      // Send standard confirmation email for End of Month account
      sendEmail(
        agentEmail,
        "Property Inspection Order Confirmation – End of Month Account",
        "Dear Agent,\n\nYour property inspection order has been successfully placed under your Real Estate Agency End of Month account. No immediate payment is required.\n\nThank you."
      );
      console.log("Confirmation email sent for End of Month account.");
      break;

    case "VendorDirect":
      // Send confirmation email including vendor details
      const vendorInfo = payment.vendorDetails;
      let vendorMessage = "Vendor details:\n";
      if (vendorInfo.husband)
        vendorMessage += `Husband: ${vendorInfo.husband.givenName}, ${vendorInfo.husband.email}, ${vendorInfo.husband.mobilePhone}\n`;
      if (vendorInfo.wife)
        vendorMessage += `Wife: ${vendorInfo.wife.givenName}, ${vendorInfo.wife.email}, ${vendorInfo.wife.mobilePhone}\n`;

      sendEmail(
        agentEmail,
        "Property Inspection Order – Vendor Payment Required",
        `Dear Agent,\n\nThe order has been placed with payment liability to be made directly by the vendor.\n\n${vendorMessage}\nPlease ensure vendor is notified.\n\nThank you.`
      );
      console.log("Confirmation email sent for VendorDirect payment option.");
      break;

    default:
      throw new Error("Unknown payment method.");
  }
}

// Example usage
/*
processPaymentAndNotify("agent@example.com");
*/
