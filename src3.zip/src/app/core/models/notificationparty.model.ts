// notification-party.ts

// Interface representing a party to be notified
export interface NotificationParty {
  givenName: string;
  surname: string;
  email: string;
  mobilePhone: string;
}

// Array to store notification parties
export const notificationParties: NotificationParty[] = [];

// Function to add a notification party
export function addNotificationParty(party: NotificationParty): void {
  // Basic validation to ensure all fields are provided
  if (!party.givenName || !party.surname || !party.email || !party.mobilePhone) {
    throw new Error("All fields are required for a notification party.");
  }

  notificationParties.push(party);
  console.log(`Notification party added: ${party.givenName} ${party.surname}`);
}

// Function to list all notification parties
export function listNotificationParties(): void {
  if (notificationParties.length === 0) {
    console.log("No notification parties added yet.");
    return;
  }

  console.log("Notification Parties:");
  notificationParties.forEach((party, index) => {
    console.log(
      `${index + 1}. ${party.givenName} ${party.surname} | Email: ${party.email} | Mobile: ${party.mobilePhone}`
    );
  });
}

// Example usage
/*
addNotificationParty({
  givenName: "Robert",
  surname: "White",
  email: "robert.white@example.com",
  mobilePhone: "+61499887766"
});

listNotificationParties();
*/
