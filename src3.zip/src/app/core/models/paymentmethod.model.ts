// payment-method.ts

import { vendor } from "./vendor.model"; // import vendor details
// Ensure vendor-husband.ts and vendor-wife.ts are available

/**
 * Section 7 – How would you like this order to be paid / processed
 */

// Pay now by agent
export interface PayNow {
  type: "PayNow";
}

// Real estate agency End of Month account
export interface AgencyEOM {
  type: "AgencyEOM";
}

// Payment by vendor directly
export interface VendorDirect {
  type: "VendorDirect";
  vendorDetails: {
    husband?: typeof vendor;
    wife?: typeof vendor;
  };
}

// Union type
export type PaymentMethod = PayNow | AgencyEOM | VendorDirect;

// Holds the selected payment method
export let selectedPaymentMethod: PaymentMethod | null = null;

/**
 * Sets the payment method
 * @param payment Payment choice
 */
export function setPaymentMethod(payment: PaymentMethod): void {
  if (payment.type === "VendorDirect") {
    // VendorDirect requires vendor details
    if (!vendor) {
      throw new Error(
        "VendorDirect payment cannot be selected unless vendor details are provided."
      );
    }

    // Automatically duplicate existing vendor details
    payment.vendorDetails = {
      husband: vendor || undefined,
      wife: vendor || undefined,
    };
  }

  selectedPaymentMethod = payment;
  console.log(`Payment method selected: ${payment.type}`);
}

/**
 * Returns the current payment method
 */
export function getPaymentMethod(): PaymentMethod | null {
  return selectedPaymentMethod;
}

// Example usage
/*
setPaymentMethod({ type: "PayNow" });

setPaymentMethod({ type: "AgencyEOM" });

setPaymentMethod({ type: "VendorDirect", vendorDetails: {} });

console.log(getPaymentMethod());
*/
