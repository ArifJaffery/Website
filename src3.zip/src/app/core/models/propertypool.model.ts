// property-pool.ts

// Interface for pool details
export interface PropertyPool {
  hasPool: boolean; // Does the property have a pool?
  requestPoolComplianceCertificate?: boolean; // Optional: request certificate if pool exists
  certificateCost?: number; // Optional: cost of certificate if requested
}

// Array to store property pool information
export const propertyPools: PropertyPool[] = [];

// Function to add pool info
export function addPropertyPool(pool: PropertyPool): void {
  if (pool.hasPool && pool.requestPoolComplianceCertificate === undefined) {
    throw new Error(
      "If the property has a pool, please indicate whether a pool compliance certificate is requested."
    );
  }

  // Set default cost if certificate is requested
  if (pool.hasPool && pool.requestPoolComplianceCertificate) {
    pool.certificateCost = 495; // $495 plus GST
  }

  propertyPools.push(pool);
  console.log(
    `Property pool info added. Pool present: ${pool.hasPool}${
      pool.requestPoolComplianceCertificate ? ", Certificate requested" : ""
    }`
  );
}

// Function to list all pool info
export function listPropertyPools(): void {
  if (propertyPools.length === 0) {
    console.log("No pool information added yet.");
    return;
  }

  console.log("Property Pool Information:");
  propertyPools.forEach((pool, index) => {
    console.log(`${index + 1}. Has Pool: ${pool.hasPool ? "Yes" : "No"}`);
    if (pool.hasPool) {
      console.log(
        `   Pool Compliance Certificate: ${
          pool.requestPoolComplianceCertificate ? "Yes" : "No"
        }`
      );
      if (pool.requestPoolComplianceCertificate) {
        console.log(`   Cost: $${pool.certificateCost} + GST`);
      }
    }
  });
}

// Example usage
/*
addPropertyPool({ hasPool: true, requestPoolComplianceCertificate: true });
addPropertyPool({ hasPool: false });
listPropertyPools();
*/
