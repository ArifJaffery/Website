// sale-type.ts

/**
 * Section 10 – Type of Sale
 */

// Auction
export interface AuctionSale {
  type: "Auction";
  auctionDate: string; // ISO date string YYYY-MM-DD
}

// For Sale
export interface ForSale {
  type: "ForSale";
  agencyAgreementExpiryDate: string; // ISO date string
}

// Expression of Interest
export interface ExpressionOfInterest {
  type: "ExpressionOfInterest";
  eoiExpiryDate: string; // ISO date string
}

// Off Market
export interface OffMarket {
  type: "OffMarket";
}

// Union type for all sale types
export type SaleTypeOption =
  | AuctionSale
  | ForSale
  | ExpressionOfInterest
  | OffMarket;

// Holds the selected sale type for this order
export let saleTypeSelection: SaleTypeOption | null = null;

/**
 * Set the sale type
 * @param option Selected sale type
 */
export function setSaleType(option: SaleTypeOption): void {
  saleTypeSelection = option;

  switch (option.type) {
    case "Auction":
      console.log(`Sale type: Auction, Date: ${option.auctionDate}`);
      break;
    case "ForSale":
      console.log(
        `Sale type: For Sale, Agency agreement expiry date: ${option.agencyAgreementExpiryDate}`
      );
      break;
    case "ExpressionOfInterest":
      console.log(`Sale type: Expression of Interest, EOI expiry date: ${option.eoiExpiryDate}`);
      break;
    case "OffMarket":
      console.log("Sale type: Off Market");
      break;
  }
}

/**
 * Get current sale type selection
 */
export function getSaleType(): SaleTypeOption | null {
  return saleTypeSelection;
}

// Example usage
/*
setSaleType({ type: "Auction", auctionDate: "2026-03-15" });
setSaleType({ type: "ForSale", agencyAgreementExpiryDate: "2026-04-01" });
setSaleType({ type: "ExpressionOfInterest", eoiExpiryDate: "2026-04-15" });
setSaleType({ type: "OffMarket" });

console.log(getSaleType());
*/
