// special-instructions.ts

/**
 * Section 12 – Special Instructions
 */

export interface SpecialInstructions {
  instructions: string;
}

// Holds special instructions for this order
export let specialInstructions: SpecialInstructions | null = null;

/**
 * Set special instructions
 * @param instructions Free text instructions
 */
export function setSpecialInstructions(instructions: string): void {
  if (!instructions || instructions.trim().length === 0) {
    throw new Error("Special instructions cannot be empty.");
  }

  specialInstructions = { instructions: instructions.trim() };
  console.log("Special instructions recorded.");
}

/**
 * Get current special instructions
 */
export function getSpecialInstructions(): SpecialInstructions | null {
  return specialInstructions;
}

// Example usage
/*
setSpecialInstructions("Please ensure the kitchen and garage are inspected thoroughly.");
console.log(getSpecialInstructions());
*/
