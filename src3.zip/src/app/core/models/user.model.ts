import { UserProfile } from "./userprofile.model";

export interface User {
  email: string;
  verified: boolean;
  code: number | null;
  expires: number | null;
  createdAt: string;   // ISO date string
  role: 'user' | 'admin';
  profile: UserProfile;
  verifiedAt: string | null;
}
