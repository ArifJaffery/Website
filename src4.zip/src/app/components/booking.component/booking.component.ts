import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators , FormsModule, FormControl} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BookingInspectionRequest } from '../../core/models/bookingrequest.model';

// Child Components
import { ListingAgentComponent } from '../listing-agent.component/listing-agent.component';
import { CoListingAgentComponent } from '../co-listing-agent.component/co-listing-agent.component';
import { AdminTeamComponent } from '../admin-team.component/admin-team.component';
import { NotificationPartyComponent } from '../notification-party.component/notification-party.component';
import { VendorComponent } from '../vendor.component/vendor.component';
import { PropertyAddressComponent } from '../property-address.component/property-address.component';
import { InspectionScheduleComponent } from '../inspection-schedule.component/inspection-schedule.component';
import { PropertyAccessComponent } from '../property-access.component/property-access.component';
import { CostModelComponent } from '../cost-model.component/cost-model.component';
import { PaymentMethodComponent } from '../payment-method.component/payment-method.component';
import { PoolDetailsComponent } from '../pool-details.component/pool-details.component';
import { SecondDwellingComponent } from '../second-dwelling.component/second-dwelling.component';
import { SaleTypeComponent } from '../sale-type.component/sale-type.component';
import { OpenHouseAuctionComponent } from '../open-house-auction.component/open-house-auction.component';
import { SpecialInstructionsComponent } from '../special-instructions.component/special-instructions.component';
import { TermsAndConditionsComponent } from '../terms-and-conditions.component/terms-and-conditions.component';
import { PreInspectionAgreementComponent } from '../pre-inspection-agreement.component/pre-inspection-agreement.component';
import { ContractAcknowledgementComponent } from '../contract-acknowledgement.component/contract-acknowledgement.component';
import { ContactComponent } from '../contact-component/contact-component';
import { Contact, ContactType } from '../../core/models/contact.model';
import { PropertyAddress } from '../../core/models/propertyaddress.model';
import { InspectionSchedule } from '../../core/models/inspectionschedule.model';

import {
  PropertyAccessOption,
  VendorAccess,
  AgentAccess,
  TenantAccess,
  LockBoxAccess,
  KeyOnSiteAccess,
  PickupFromAgentOfficeAccess
} from '../../core/models/propertyaccess.model';
import { CostModel, CostModelSelectionTypes } from '../../core/models/costmodal.model';
import { InspectionType } from '../../core/models/inspectioncost.model';
import { PaymentMethod, PaymentTypes } from '../../core/models/paymentmethod.model';
// import { CostModelOption } from '../../core/models/costmodal.model';



@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    ContactComponent,
    ListingAgentComponent,
    CoListingAgentComponent,
    AdminTeamComponent,
    NotificationPartyComponent,
    VendorComponent,
    PropertyAddressComponent,
    InspectionScheduleComponent,
    PropertyAccessComponent,
    CostModelComponent,
    PaymentMethodComponent,
    PoolDetailsComponent,
    SecondDwellingComponent,
    SaleTypeComponent,
    OpenHouseAuctionComponent,
    SpecialInstructionsComponent,
    TermsAndConditionsComponent,
    PreInspectionAgreementComponent,
    ContractAcknowledgementComponent,    
  ],
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})

export class BookingComponent implements OnInit {
  bookingForm!: FormGroup;
  currentStep = 1;
  //step: number = 1;
  totalSteps = 17;
  ContactType = ContactType;
  selectedContactType: ContactType = ContactType.ListingAgent; 
  selectedContactTypeControl!: FormControl;

  stepTitles: string[] = [
    '', // index 0 unused
    'Business Contacts',
    'Vendor Details',
    'Property Address',
    'Inspection Schedule',
    'Property Access',
    'Cost Model',
    'Payment Method',
    'Optional Info',
    'Verification Code'
  ];

   getStepTitle(step: number): string {
    return this.stepTitles[step] || '';
   }  

  constructor(private fb: FormBuilder) {}


  createContactGroup(
    contactType: ContactType,
    showNotificationParty: boolean,
    showRemoveButton: boolean,
    showVoucher: boolean
  ): FormGroup<{
    givenName: FormControl<Contact['givenName']>;
    surname: FormControl<Contact['surname']>;
    email: FormControl<Contact['email']>;
    mobilePhone: FormControl<Contact['mobilePhone']>;
    contactType: FormControl<Contact['contactType']>;
    notifyParty: FormControl<Contact['notifyParty']>;
    showNotificationParty: FormControl<Contact['showNotificationParty']>;
    showRemoveButton: FormControl<Contact['showRemoveButton']>;
    showVoucher: FormControl<Contact['showVoucher']>;
    }> {
      return new FormGroup({
        givenName: new FormControl('', {
          nonNullable: true,
          validators: Validators.required,
        }),
        surname: new FormControl('', {
          nonNullable: true,
          validators: Validators.required,
        }),
        email: new FormControl('', {
          nonNullable: true,
          validators: [Validators.required, Validators.email],
        }),
        mobilePhone: new FormControl('', {
          nonNullable: true,
          validators: Validators.required,
        }),
        contactType: new FormControl(contactType, {
          nonNullable: true,
        }),
        notifyParty: new FormControl(true, {
          nonNullable: true,
        }),
        showNotificationParty: new FormControl(showNotificationParty, {
          nonNullable: true,
        }),
        showRemoveButton: new FormControl(showRemoveButton, {
          nonNullable: true,
        }),
        showVoucher: new FormControl(showVoucher, {
          nonNullable: true,
        })
      });
    }


  createPropertyAddressGroup(): FormGroup<{
    houseNumber: FormControl<PropertyAddress['houseNumber']>;
    streetName: FormControl<PropertyAddress['streetName']>;
    suburb: FormControl<PropertyAddress['suburb']>;
    postCode: FormControl<PropertyAddress['postCode']>;
    state: FormControl<PropertyAddress['state']>;
  }> {
    return new FormGroup({
      houseNumber: new FormControl('', {
        nonNullable: true,
        validators: Validators.required
      }),
      streetName: new FormControl('', {
        nonNullable: true,
        validators: Validators.required
      }),
      suburb: new FormControl('', {
        nonNullable: true,
        validators: Validators.required
      }),
      postCode: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required, Validators.pattern('^[0-9]{4}$')]
      }),
      state: new FormControl('', {
        nonNullable: true,
        validators: Validators.required
      })
    });
  }



  createInspectionScheduleGroup(): FormGroup<{
    inspectionDate: FormControl<InspectionSchedule['inspectionDate']>;
    inspectionTime: FormControl<InspectionSchedule['inspectionTime']>;
  }> {
    return new FormGroup({
      inspectionDate: new FormControl('', {
        nonNullable: true,
        validators: Validators.required
      }),
      inspectionTime: new FormControl('', {
        nonNullable: true,
        validators: [
          Validators.required,
          Validators.pattern('^([01]\\d|2[0-3]):([0-5]\\d)$') // HH:MM 24-hour format
        ]
      })
    });
  }


  createPropertyAccessGroup(
    accessType: PropertyAccessOption['type']
  ): FormGroup {

    switch (accessType) {
      case 'Vendor':
        return new FormGroup({
          type: new FormControl('Vendor' as const, { nonNullable: true }),
          name: new FormControl('', { nonNullable: true, validators: Validators.required }),
          phone: new FormControl('', { nonNullable: true, validators: Validators.required }),
          email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email] })
        });

      case 'Agent':
        return new FormGroup({
          type: new FormControl('Agent' as const, { nonNullable: true }),
          name: new FormControl('', { nonNullable: true, validators: Validators.required }),
          mobilePhone: new FormControl('', { nonNullable: true, validators: Validators.required }),
          email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email] })
        });

      case 'Tenant':
        return new FormGroup({
          type: new FormControl('Tenant' as const, { nonNullable: true }),
          name: new FormControl('', { nonNullable: true, validators: Validators.required }),
          phone: new FormControl('', { nonNullable: true, validators: Validators.required }),
          email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email] })
        });

      case 'LockBox':
        return new FormGroup({
          type: new FormControl('LockBox' as const, { nonNullable: true }),
          locationDescription: new FormControl('', { nonNullable: true, validators: Validators.required }),
          phone: new FormControl('', { nonNullable: true, validators: Validators.required })
        });

      case 'KeyOnSite':
        return new FormGroup({
          type: new FormControl('KeyOnSite' as const, { nonNullable: true }),
          locationDescription: new FormControl('', { nonNullable: true, validators: Validators.required })
        });

      case 'PickupFromAgentOffice':
        return new FormGroup({
          type: new FormControl('PickupFromAgentOffice' as const, { nonNullable: true }),
          pickupAddress: new FormControl('', { nonNullable: true, validators: Validators.required }),
          dropoffAddress: new FormControl('', { nonNullable: true, validators: Validators.required }),
          serviceCharge: new FormControl(35) // default $35 if not provided
        });

      default:
        throw new Error('Unknown access type');
    }
  }


  // createCostModelGroup(
  //   type: CostModelOption['type']
  // ): FormGroup {
  //   switch (type) {
  //     case 'DirectSelection':
  //       return new FormGroup({
  //         type: new FormControl('DirectSelection' as const, { nonNullable: true }),
  //         modelNumber: new FormControl<number | null>(null, {
  //           nonNullable: true,
  //           validators: [Validators.required, Validators.min(1), Validators.max(14)]
  //         }),
  //       });

  //     case 'PriceListSelection':
  //       return new FormGroup({
  //         type: new FormControl('PriceListSelection' as const, { nonNullable: true }),
  //         selectedModelNumber: new FormControl<number | null>(null), // optional
  //       });

  //     case 'QualifyingQuestions':
  //       return new FormGroup({
  //         type: new FormControl('QualifyingQuestions' as const, { nonNullable: true }),
  //         vendorOrAgentWantCopy: new FormControl(false, { nonNullable: true }),
  //         freeReportAgentVendor: new FormControl(false, { nonNullable: true }),
  //         vendorPaysOneOff: new FormControl(false, { nonNullable: true }),
  //         buyerVendorSmallUpfront: new FormControl(false, { nonNullable: true }),
  //         vendorBuyerFreeFinalBuyerPays: new FormControl(false, { nonNullable: true }),
  //         vendorPaysReducedBuyerPaysReduced: new FormControl(false, { nonNullable: true }),
  //       });

  //     default:
  //       throw new Error('Unknown cost model type');
  //   }
  // }


createCostModelForm(fb: FormBuilder, costModel?: CostModel): FormGroup {
  return fb.group({
    type: new FormControl(costModel?.type || CostModelSelectionTypes.DirectSelection),

    inspectionCost: fb.group({
      id: new FormControl(costModel?.inspectionCost?.id || ''),
      type: new FormControl(costModel?.inspectionCost?.type || null),
      vendor: new FormControl(costModel?.inspectionCost?.vendor || 0),
      buyer: new FormControl(costModel?.inspectionCost?.buyer || 0),
      finalBuyer: new FormControl(costModel?.inspectionCost?.finalBuyer || 0),
    }),

    // Optional Qualifying Questions
    CostModelQualifyingQuestions: fb.group({      
      vendorOrAgentWantCopy: new FormControl(costModel?.CostModelQualifyingQuestions?.vendorOrAgentWantCopy || false),
      freeReportAgentVendor: new FormControl(costModel?.CostModelQualifyingQuestions?.freeReportAgentVendor || false),
      vendorPaysOneOff: new FormControl(costModel?.CostModelQualifyingQuestions?.vendorPaysOneOff || false),
      buyerVendorSmallUpfront: new FormControl(costModel?.CostModelQualifyingQuestions?.buyerVendorSmallUpfront || false),
      vendorBuyerFreeFinalBuyerPays: new FormControl(costModel?.CostModelQualifyingQuestions?.vendorBuyerFreeFinalBuyerPays || false),
      vendorPaysReducedBuyerPaysReduced: new FormControl(costModel?.CostModelQualifyingQuestions?.vendorPaysReducedBuyerPaysReduced || false),
    })
  });
}


  createPaymentMethodForm(fb: FormBuilder,payment?: PaymentMethod): FormGroup {
    const type = payment?.type ?? null;

    // Vendor form group (only relevant for VendorDirect)
    const vendorGroup = fb.group({
      givenName: [payment?.vendor?.givenName ?? ''],
      surname: [payment?.vendor?.surname ?? ''],
      email: [payment?.vendor?.email ?? ''],
      mobilePhone: [payment?.vendor?.mobilePhone ?? ''],
      usedForDiscountVoucher: [payment?.vendor?.usedForDiscountVoucher ?? false]
    });

    return fb.group({
      type: [type],
      vendor:  vendorGroup 
    });
  }


  ngOnInit(): void {
    this.bookingForm = this.fb.group({

      contacts:  this.fb.array([
        this.createContactGroup(ContactType.ListingAgent,true,true,false),
        this.createContactGroup(ContactType.CoListingAgent,true,true,false),
        this.createContactGroup(ContactType.AdministrationTeam,true,true,false)        
        ]),
      vendor : this.fb.array([
        this.createContactGroup(ContactType.Husband,false,false,false),
        this.createContactGroup(ContactType.Wife,false,false,false)
        ]),
      propertyAddress: this.createPropertyAddressGroup(),
      inspectionSchedule: this.createInspectionScheduleGroup(),
      propertyAccess: this.createPropertyAccessGroup('Vendor'),      
      costModel: this.createCostModelForm(this.fb, 
        {
          type: CostModelSelectionTypes.DirectSelection,  // Enum value
          inspectionCost: {
            id: '',
            type: undefined,
            vendor: 0,
            buyer: 0,
            finalBuyer: 0
          },
          CostModelQualifyingQuestions: {          
            vendorOrAgentWantCopy: true,        
            freeReportAgentVendor: true,       
            vendorPaysOneOff: true,             
            buyerVendorSmallUpfront: true,     
            vendorBuyerFreeFinalBuyerPays: true,
            vendorPaysReducedBuyerPaysReduced: true 
          }
      }),
      paymentMethod: this.createPaymentMethodForm(this.fb, 
        {
          type: PaymentTypes.PayNow,
          vendor: {
            givenName: '',
            surname: '',
            email: '',
            mobilePhone: '',
            usedForDiscountVoucher: false
          }
        }
      ),
      poolDetails: this.fb.group({}),
      secondDwelling: this.fb.group({}),
      saleType: this.fb.group({}),
      openHouseAuction: this.fb.group({}),
      specialInstructions: this.fb.group({}),
      termsAndConditions: this.fb.group({}),
      preInspectionAgreement: this.fb.group({}),
      contractAcknowledgement: this.fb.group({}),
      orderCompleted: [false],
      paymentProcessingInstructions: ['']
    });
    this.selectedContactTypeControl = this.fb.control(ContactType.ListingAgent);
  }

  get paymentMethod(): FormGroup {
    return this.bookingForm.get('paymentMethod') as FormGroup;
  }

  get contacts(): FormArray {
    return this.bookingForm.get('contacts') as FormArray;
  }

  get contactsFormGroups(): FormGroup[] {
    return this.contacts.controls.map(c => c as FormGroup);
  }

  get vendor(): FormArray {
    return this.bookingForm.get('vendor') as FormArray;
  }

  get vendorFormGroups(): FormGroup[] {
    return this.vendor.controls.map(c => c as FormGroup);
  }

  get propertyAddress(): FormGroup {
    return this.bookingForm.get('propertyAddress') as FormGroup;
  }

  get inspectionSchedule(): FormGroup {
    return this.bookingForm.get('inspectionSchedule') as FormGroup;
  }

  get propertyAccess(): FormGroup {
    return this.bookingForm.get('propertyAccess') as FormGroup;
  } 

  get costModel(): FormGroup {
    return this.bookingForm.get('costModel') as FormGroup;
  } 

  nextStep() {
    console.log(`Step =>${this.currentStep}`)
    console.log(`Total Steps =>${this.totalSteps}`)

    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
    }
  }

  prevStep() {
    console.log(`Step =>${this.currentStep}`)
    
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  submitBooking() {
    if (this.bookingForm.valid) {
      const payload: BookingInspectionRequest = this.bookingForm.value;            
    } else {
      console.warn('Form is invalid');
    }
  }

    get listingAgentForm(): FormGroup {
    return this.bookingForm.get('listingAgent') as FormGroup;
    }

    get vendorHusbandForm(): FormGroup {
    return this.bookingForm.get('vendorHusband') as FormGroup;
    }

    get coListingAgentForm(): FormGroup {
    return this.bookingForm.get('coListingAgent') as FormGroup;
    }

    get adminTeamForm(): FormGroup {
    return this.bookingForm.get('adminTeam') as FormGroup;
    }

    get NotificationPartyForm(): FormGroup {
    return this.bookingForm.get('notificationParty') as FormGroup;
    }

    addContact(contactType:any ) {      
      this.contacts.push(this.createContactGroup(contactType,true,true,false));
    }

    // Remove contact by index
    removeContact(index: number) {
        this.contacts.removeAt(index);
    }

}
