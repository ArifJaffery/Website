import { Component, Input } from '@angular/core';
import { InspectionType } from '../../core/models/inspectioncost.model';
import { BusinessCostModel } from '../../core/models/business-cost-model.model';
import { CommonModule } from '@angular/common';
import { InspectionCostComponent } from '../inspection-cost.component/inspection-cost.component';

@Component({
  selector: 'app-business-cost-model',
  imports: [CommonModule, InspectionCostComponent],
  templateUrl: './business-cost-model.component.html',
  styleUrls: ['./business-cost-model.component.css']
})
export class BusinessCostModelComponent {
  @Input() model!: BusinessCostModel; // Non-null assertion
  inspectionTypes = InspectionType;   // Optional: for template use
}
