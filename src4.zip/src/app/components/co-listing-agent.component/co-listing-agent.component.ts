// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-co-listing-agent',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './co-listing-agent.component.html',
//   styleUrls: ['./co-listing-agent.component.css']
// })
// export class CoListingAgentComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {}

//   ngOnInit(): void {
//     // Add form controls for co-listing agent
//     this.formGroup.addControl('givenName', this.fb.control(''));
//     this.formGroup.addControl('surname', this.fb.control(''));
//     this.formGroup.addControl('email', this.fb.control(''));
//     this.formGroup.addControl('mobilePhone', this.fb.control(''));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-co-listing-agent',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './co-listing-agent.component.html',
  styleUrls: ['./co-listing-agent.component.css']
})
export class CoListingAgentComponent implements OnInit {
  @Input() parentForm!: FormGroup; // <-- updated

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('CoListingAgentComponent: parentForm is not provided!');
      return;
    }

    if (!this.parentForm.get('givenName')) {
      this.parentForm.addControl('givenName', this.fb.control(''));
    }
    if (!this.parentForm.get('surname')) {
      this.parentForm.addControl('surname', this.fb.control(''));
    }
    if (!this.parentForm.get('email')) {
      this.parentForm.addControl('email', this.fb.control(''));
    }
    if (!this.parentForm.get('mobilePhone')) {
      this.parentForm.addControl('mobilePhone', this.fb.control(''));
    }
  }
}
