// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-cost-model',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './cost-model.component.html',
//   styleUrls: ['./cost-model.component.css']
// })
// export class CostModelComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {} // ✅ Inject FormBuilder

//   ngOnInit(): void {
//     // Add reactive form controls
//     [
//       'type',
//       'vendorOrAgentWantCopy',
//       'freeReportAgentVendor',
//       'vendorPaysOneOff',
//       'buyerVendorSmallUpfront',
//       'vendorBuyerFreeFinalBuyerPays',
//       'vendorPaysReducedBuyerPaysReduced'
//     ].forEach(field => this.formGroup.addControl(field, this.fb.control(false)));
//   }
// }

import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { PriceListComponent } from '../../components/price-list.component/price-list.component';



@Component({
  selector: 'app-cost-model',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule,PriceListComponent],
  templateUrl: './cost-model.component.html',
  styleUrls: ['./cost-model.component.css']
})
export class CostModelComponent implements OnInit {
  @Input() parentForm!: FormGroup; // ✅ updated to parentForm   
   
  checkedQuestions: string[] = [];

  constructor(private fb: FormBuilder) {}

  get qualifyingQuestionsForm(): FormGroup {
    const group = this.parentForm.get('CostModelQualifyingQuestions');
    if (!group) {
      // Optional: throw error if group is missing, for debugging
      throw new Error('CostModelQualifyingQuestions FormGroup is missing!');
    }
    return group as FormGroup;
  }


  get getFormGroup(): FormGroup {
    const group = this.parentForm.get('inspectionCost');
    if (!group) {
      // Optional: throw error if group is missing, for debugging
      throw new Error('inspectionCost FormGroup is missing!');
    }
    return group as FormGroup;
  }




// In your component class
  modelNumberOptions = [
    { value: 1, label: '1 - Vendor & Buyers Pays (One-off Payment)' },
    { value: 2, label: '2 - Vendor & Buyers Pays (Vendor Full Freight)' },
    { value: 3, label: '3 - Vendor & Buyers Pays ($50)' },
    { value: 4, label: '4 - Vendor & Buyers Pays ($30)' },
    { value: 5, label: '5 - Vendor & Buyers Pays ($100)' },
    { value: 6, label: '6 - Vendor & Buyers Pays ($150 / $80)' },
    { value: 7, label: '7 - Vendor Only (Option For Buyers To Purchase)' },
    { value: 8, label: '8 - Vendor Only (Vendor & Buyer Reliant)' },
    { value: 9, label: '9 - Vendor Only Pays (Large Estate or Outer Sydney orders)' },
    { value: 10, label: '10 - Buyers Only Pay ($49)' },
    { value: 11, label: '11 - Buyers Only Pay ($99)' },
    { value: 12, label: '12 - Buyers Only Pay ($149)' },
    { value: 13, label: '13 - Buyers Only Pay ($299 / $199)' },
    { value: 14, label: '14 - TPI Special' },
  ];

// createCostModelGroup(type: CostModelOption['type']): FormGroup {
//     switch (type) {
//       case 'DirectSelection':
//         return new FormGroup({
//           type: new FormControl('DirectSelection' as const, { nonNullable: true }),
//           modelNumber: new FormControl<number | null>(null, {
//             nonNullable: true,
//             validators: [Validators.required, Validators.min(1), Validators.max(14)]
//           }),
//         });

//       case 'PriceListSelection':
//         return new FormGroup({
//           type: new FormControl('PriceListSelection' as const, { nonNullable: true }),
//           selectedModelNumber: new FormControl<number | null>(null),
//         });

//       case 'QualifyingQuestions':
//         return new FormGroup({
//           type: new FormControl('QualifyingQuestions' as const, { nonNullable: true }),
//           vendorOrAgentWantCopy: new FormControl(false, { nonNullable: true }),
//           freeReportAgentVendor: new FormControl(false, { nonNullable: true }),
//           vendorPaysOneOff: new FormControl(false, { nonNullable: true }),
//           buyerVendorSmallUpfront: new FormControl(false, { nonNullable: true }),
//           vendorBuyerFreeFinalBuyerPays: new FormControl(false, { nonNullable: true }),
//           vendorPaysReducedBuyerPaysReduced: new FormControl(false, { nonNullable: true }),
//         });

//       default:
//         throw new Error('Unknown cost model type');
//     }
// }
  

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('CostModelComponent: parentForm is not provided!');
      //  this.parentForm = this.createCostModelGroup('DirectSelection');
      return;
    }

    // this.typeChangeSub = this.parentForm.get('type')?.valueChanges.subscribe(
    //   (newType: CostModelOption['type']) => {
    //     const newGroup = this.createCostModelGroup(newType);
    //     // Preserve the "type" control itself
    //     this.parentForm.reset();
    //     Object.keys(newGroup.controls).forEach(key => {
    //       this.parentForm.addControl(key, newGroup.get(key)!);
    //     });
    //   }
    // );

      // this.parentForm.get('type')?.valueChanges.subscribe(type => {
        // const newGroup = this.createCostModelGroup(type);

        // Replace the FormGroup **silently** to avoid triggering valueChanges again
        // this.parentForm.reset(newGroup.value, { emitEvent: false });
      // });



    // const fields = [
    //   'type',
    //   'vendorOrAgentWantCopy',
    //   'freeReportAgentVendor',
    //   'vendorPaysOneOff',
    //   'buyerVendorSmallUpfront',
    //   'vendorBuyerFreeFinalBuyerPays',
    //   'vendorPaysReducedBuyerPaysReduced'
    // ];

    // fields.forEach(field => {
    //   if (!this.parentForm.get(field)) {
    //     this.parentForm.addControl(field, this.fb.control(field === 'type' ? '' : false));
    //   }
    // });

  //  this.parentForm.get('type')?.valueChanges.subscribe(type => {      
  //     this.updateCheckedQuestions();
  //   });
  //  this.parentForm.valueChanges.subscribe(() => {
  //     this.updateCheckedQuestions();
  //   });

  } 

//  updateCheckedQuestions() {
//     const controls = this.parentForm.controls;
//     this.checkedQuestions = Object.keys(controls)
//       .filter(key => key !== 'type' && key !== 'modelNumber')
//       .filter(key => controls[key].value === true);
//     console.log('Checked Questions:', this.checkedQuestions);
//   }


}
