import { Component, Input } from '@angular/core';
import { RegisterComponent } from '../../components/register.component/register.component';
import { VerificationComponent } from '../../components/verification.component/verification.component';
import { NgIf } from '@angular/common'; // <-- add this
import {  EventEmitter, Output } from '@angular/core';


@Component({
  selector: 'app-cta-section',
  standalone: true,
  imports: [RegisterComponent, VerificationComponent, NgIf],
  templateUrl: './cta-section.component.html',
  styleUrls: ['./cta-section.component.css']
})  
export class CtaSectionComponent {
  @Input() title = 'Get Started Today';
  @Input() message = 'Join our satisfied customers and experience the best in building inspection services.';
  @Output() codeSent = new EventEmitter<string>();  // 👈 must be string
  @Output() verified = new EventEmitter<void>();


  step: 'register' | 'verify' | 'success' = 'register';  
  email = '';

  onCodeSent(email: string) {
    console.log('Code Sent Event', email);
    this.email = email;
    this.step = 'verify';
  }

  sendCode(email: string) {
    this.codeSent.emit(email); // send the email string
  }

  onVerified() {
    this.verified.emit();
  }

}
