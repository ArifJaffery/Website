import { Component, Input } from '@angular/core';
import { InspectionCost, InspectionType } from '../../core/models/inspectioncost.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-inspection-cost',
  imports: [CommonModule],
  templateUrl: './inspection-cost.component.html',
  styleUrls: ['./inspection-cost.component.css']
})
export class InspectionCostComponent {  
  @Input() row!: InspectionCost ;
  
  
  
}

