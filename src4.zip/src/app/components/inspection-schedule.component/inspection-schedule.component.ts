// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-inspection-schedule',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './inspection-schedule.component.html',
//   styleUrls: ['./inspection-schedule.component.css']
// })
// export class InspectionScheduleComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {}

//   ngOnInit(): void {
//     // Add form controls for inspection date and time
//     this.formGroup.addControl('inspectionDate', this.fb.control(''));
//     this.formGroup.addControl('inspectionTime', this.fb.control(''));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-inspection-schedule',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './inspection-schedule.component.html',
  styleUrls: ['./inspection-schedule.component.css']
})
export class InspectionScheduleComponent implements OnInit {
  /** Parent form passed from BookingComponent */
  @Input() parentForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('InspectionScheduleComponent: parentForm is not provided!');
      return;
    }

    // Add form controls for date and time
    this.parentForm.addControl('inspectionDate', this.fb.control(''));
    this.parentForm.addControl('inspectionTime', this.fb.control(''));
  }
}
