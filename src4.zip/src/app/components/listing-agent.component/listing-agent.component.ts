// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-listing-agent',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './listing-agent.component.html',
//   styleUrls: ['./listing-agent.component.css']
// })
// export class ListingAgentComponent implements OnInit {
//   @Input() formGroup!: FormGroup;
//   ngOnInit() {
//     const fb = new FormBuilder();
//     this.formGroup.addControl('givenName', fb.control(''));
//     this.formGroup.addControl('surname', fb.control(''));
//     this.formGroup.addControl('email', fb.control(''));
//     this.formGroup.addControl('mobilePhone', fb.control(''));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-listing-agent',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './listing-agent.component.html',
  styleUrls: ['./listing-agent.component.css']
})
export class ListingAgentComponent implements OnInit {
  @Input() parentForm!: FormGroup; // <-- changed from formGroup

  ngOnInit() {
    if (!this.parentForm) {
      console.warn('ListingAgentComponent: parentForm is not provided!');
      return;
    }

    const fb = new FormBuilder();

    // Only add controls if they don't already exist
    if (!this.parentForm.get('givenName')) {
      this.parentForm.addControl('givenName', fb.control(''));
    }
    if (!this.parentForm.get('surname')) {
      this.parentForm.addControl('surname', fb.control(''));
    }
    if (!this.parentForm.get('email')) {
      this.parentForm.addControl('email', fb.control(''));
    }
    if (!this.parentForm.get('mobilePhone')) {
      this.parentForm.addControl('mobilePhone', fb.control(''));
    }
  }
}
