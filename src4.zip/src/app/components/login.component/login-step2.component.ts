import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-login-step2',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login-step2.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponentStep2 {  
  @Input() message: string = '';
  @Output() step2Emitter = new EventEmitter<string>();  
  
  password = '';  
  
  
  verifyPassword(){
    this.step2Emitter.emit(this.password);
  }
}
