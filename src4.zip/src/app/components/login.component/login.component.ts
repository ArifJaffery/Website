import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { LoginComponentStep1 } from './login-step1.component';
import { LoginComponentStep2} from './login-step2.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserService } from '../../core/services/user.service';
import { User } from '../../core/models/user.model';



@Component({
  selector: 'app-login',
  standalone: true,
  imports: [LoginComponentStep1, LoginComponentStep2, CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  @Output() loginSuccess = new EventEmitter<string>();

  loginMode: 'password' | 'code' | null = null;
  password = '';


  step: 1 | 2 | 3 = 1; // Step 1: enter email, Step 2: enter password/code
  email = '';
  code = '';
  message = '';
  loading = false;


  verifyPassword() {
    this.message = '';

    if (!this.password) {
        this.message = 'Please enter your password.';
        return;
    }

    this.loading = true;

    this.auth.loginWithPassword(this.email, this.password).subscribe({
        next: (res) => {
        this.loading = false;
        this.message = 'Login successful!';
        this.loginSuccess.emit(this.email);
        },
        error: (err) => {
        this.loading = false;
        this.message =
            err?.error?.message || 'Invalid password. Please try again.';
        }
    });
    }


  constructor(private auth: AuthService,private snackBar: MatSnackBar,  private userService: UserService) {}

  // Step 1: Request login code/passcode
  requestLogin() {
    this.message = '';
    if (!this.email) {
      this.message = 'Please enter your email.';
      return;
    }

    this.loading = true;
    this.auth.loginRequest(this.email).subscribe({
        next: (res: any) => {
            console.log('PHP Response login request:', res);
            this.loading = false;
            if (res.action === 'enter_password') {
                this.loginMode = 'password';
                this.step = 2;
                this.message = res.message;
                console.log('Please enter your password.');
                return;
            }

            if (res.action === 'send_code') {
            this.loginMode = 'code';
            this.step = 2;
            this.message = 'A passcode has been sent to your email.';
            return;
            }
        },
        error: (err) => {
            this.loading = false;
            this.message = err?.error?.message || 'Failed to request login.';
        }
        });


  }

  // Step 2: Verify login code/password
  verifyLogin() {
    this.message = '';
    if (!this.code) {
      this.message = 'Please enter the passcode.';
      return;
    }

    this.loading = true;
    this.auth.verifyLoginCode(this.email, this.code).subscribe({
      next: (res) => {
        this.loading = false;
        this.message = 'Login successful!';
        this.loginSuccess.emit();
      },
      error: (err) => {
        this.loading = false;
        console.error(err);
        this.message = err?.error?.message || 'Invalid passcode. Please try again.';
      }
    });
  }



  step1EventSuccess(email: any) {
      
    this.email = email;  
    this.loading = true;
      this.step = 2;
      this.auth.loginRequest(email).subscribe({
          next: (res: any) => {
              console.log('PHP Response login request:', res);
              this.loading = false;
              if (res.action === 'enter_password') {                
                  return;
              }

              if (res.action === 'send_code') {
              return;
              }
          },
          error: (err) => {
              this.loading = false;
              this.message = err?.error?.message || 'Failed to request login.';
          }
          });
    }  


showToast(message: string, type: 'success' | 'error') {
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      panelClass: type === 'success' ? ['toast-success'] : ['toast-error'],
      horizontalPosition: 'right',
      verticalPosition: 'top',
    });
}    

step2EventSuccess(password: string) {
  this.password = password;
  this.loading = true;
  this.message = '';  
  
  this.auth.loginWithPassword(this.email, this.password).subscribe({
    next: (res: any) => {
      console.log('Login with password response:', res);
      this.userService.setUser(res.user as User);      
      this.message = res?.message || 'Login successful!';      
      this.showToast(this.message, 'success');
      this.loginSuccess.emit(this.email);        
    },
    error: (err) => {
        console.error('Login with password error:', err);
        const msg = err.message || 'Invalid password';
        this.message = err.error?.message || 'Login successful!';      
        this.showToast(msg, 'error');      
    }
  });
}



}
