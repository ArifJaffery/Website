// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder, ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-payment-method',
//   standalone: true,
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './payment-method.component.html',
//   styleUrls: ['./payment-method.component.css']
// })
// export class PaymentMethodComponent implements OnInit {
//   /** Parent form passed from BookingComponent */
//   @Input() parentForm!: FormGroup;

//   constructor(private fb: FormBuilder) {} 

//   ngOnInit(): void {
//     if (!this.parentForm) {
//       console.warn('PaymentMethodComponent: parentForm is not provided!');
//       return;
//     }

//     // Add reactive form control
//     this.parentForm.addControl('type', this.fb.control(''));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-payment-method',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './payment-method.component.html',
  styleUrls: ['./payment-method.component.css']
})
export class PaymentMethodComponent implements OnInit {
  /** Parent form passed from BookingComponent */
  @Input() parentForm!: FormGroup;

  constructor(private fb: FormBuilder) {} 

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('PaymentMethodComponent: parentForm is not provided!');
      return;
    }

    // Add reactive form control
    this.parentForm.addControl('type', this.fb.control(''));
  }

  get vendorForm(): FormGroup {
    return this.parentForm.get('vendor') as FormGroup;
  }

}
