// import { Component, Input, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-pool-details',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './pool-details.component.html',
//   styleUrls: ['./pool-details.component.css']
// })
// export class PoolDetailsComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {} // ✅ inject FormBuilder

//   ngOnInit(): void {
//     // Add reactive form controls
//     this.formGroup.addControl('hasPool', this.fb.control(false));
//     this.formGroup.addControl('requestComplianceCertificate', this.fb.control(false));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-pool-details',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './pool-details.component.html',
  styleUrls: ['./pool-details.component.css']
})
export class PoolDetailsComponent implements OnInit {
  /** Parent form passed from BookingComponent */
  @Input() parentForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('PoolDetailsComponent: parentForm is not provided!');
      return;
    }

    // Add reactive form controls
    this.parentForm.addControl('hasPool', this.fb.control(false));
    this.parentForm.addControl('requestComplianceCertificate', this.fb.control(false));
  }
}
