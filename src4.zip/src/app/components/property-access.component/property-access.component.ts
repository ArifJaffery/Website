// // property-access.component.ts
// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-property-access',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './property-access.component.html',
//   styleUrls: ['./property-access.component.css']
// })
// export class PropertyAccessComponent implements OnInit {
//   @Input() formGroup!: FormGroup;
//   ngOnInit() {
//     const fb = new FormBuilder();
//     ['type','name','phone','email','location','address'].forEach(field => this.formGroup.addControl(field, fb.control('')));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-property-access',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './property-access.component.html',
  styleUrls: ['./property-access.component.css']
})
export class PropertyAccessComponent implements OnInit {
  /** Parent form passed from BookingComponent */
  @Input() parentForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    if (!this.parentForm) {
      console.warn('PropertyAccessComponent: parentForm is not provided!');
      return;
    }

    // ['type', 'name', 'phone', 'email', 'location', 'address'].forEach(field =>
    //   this.parentForm.addControl(field, this.fb.control(''))
    // );
  }
}
