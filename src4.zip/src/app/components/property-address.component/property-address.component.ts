// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-property-address',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './property-address.component.html',
//   styleUrls: ['./property-address.component.css']
// })
// export class PropertyAddressComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {}

//   ngOnInit(): void {
//     this.formGroup.addControl('houseNumber', this.fb.control(''));
//     this.formGroup.addControl('streetName', this.fb.control(''));
//     this.formGroup.addControl('suburb', this.fb.control(''));
//     this.formGroup.addControl('postCode', this.fb.control(''));
//     this.formGroup.addControl('state', this.fb.control(''));
//   }
// }
// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// import { CommonModule } from '@angular/common';
// import { ReactiveFormsModule } from '@angular/forms';

// @Component({
//   selector: 'app-property-address',
//   standalone: true, // if using Angular 14+ standalone components
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './property-address.component.html',
//   styleUrls: ['./property-address.component.css']
// })
// export class PropertyAddressComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {}

//   ngOnInit(): void {
//     // Add form controls only if they don’t already exist
//     if (!this.formGroup.contains('houseNumber')) {
//       this.formGroup.addControl('houseNumber', this.fb.control('', Validators.required));
//     }
//     if (!this.formGroup.contains('streetName')) {
//       this.formGroup.addControl('streetName', this.fb.control('', Validators.required));
//     }
//     if (!this.formGroup.contains('suburb')) {
//       this.formGroup.addControl('suburb', this.fb.control('', Validators.required));
//     }
//     if (!this.formGroup.contains('postCode')) {
//       this.formGroup.addControl('postCode', this.fb.control('', [Validators.required, Validators.pattern('^[0-9]{4}$')]));
//     }
//     if (!this.formGroup.contains('state')) {
//       this.formGroup.addControl('state', this.fb.control('', Validators.required));
//     }
//   }
// }


import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControlOptions } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-property-address',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './property-address.component.html',
  styleUrls: ['./property-address.component.css']
})
export class PropertyAddressComponent implements OnInit {
  @Input() formGroup!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    if (!this.formGroup) {
      console.warn('PropertyAddressComponent: formGroup is not provided!');
      return;
    }

  }
}
