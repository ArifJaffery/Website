// import { Component, EventEmitter, Output } from '@angular/core';

// @Component({
//   selector: 'app-property-report-selector',
//   templateUrl: './property-report-selector.component.html',
//   styleUrls: ['./property-report-selector.component.css']
// })
// export class PropertyReportSelectorComponent {

//   selectedType: 'House' | 'Unit' | null = null;

//   @Output() selectionChanged = new EventEmitter<{ propertyType: string; reportType: string }>();

//   selectHouse() {
//     this.selectedType = 'House';
//     this.emitSelection('House', 'Vendor/Agent Commissioned Pre-Purchase Building & Pest Report');
//   }

//   selectUnit() {
//     this.selectedType = 'Unit';
//     this.emitSelection('Unit', 'Vendor/Agent Commissioned Pre-Purchase Strata Report');
//   }

//   private emitSelection(propertyType: string, reportType: string) {
//     this.selectionChanged.emit({ propertyType, reportType });
//   }
// }
import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-property-report-selector',
  templateUrl: './property-report-selector.component.html',
  styleUrls: ['./property-report-selector.component.css']
})
export class PropertyReportSelectorComponent {

  selectedType: 'House' | 'Unit' | null = null;

  // Emit selected property and report to parent component
  @Output() selectionChanged = new EventEmitter<{ propertyType: string; reportType: string }>();

  // Map property type to report type for cleaner code
  private reportMap = {
    House: 'Vendor/Agent Commissioned Pre-Purchase Building & Pest Report',
    Unit: 'Vendor/Agent Commissioned Pre-Purchase Strata Report'
  };

  selectProperty(type: 'House' | 'Unit') {
    this.selectedType = type;
    this.selectionChanged.emit({ propertyType: type, reportType: this.reportMap[type] });
  }
}
