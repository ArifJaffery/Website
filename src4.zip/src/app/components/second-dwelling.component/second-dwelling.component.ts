// // import { Component, Input, OnInit } from '@angular/core';
// // import { FormBuilder, FormGroup } from '@angular/forms';
// // import { ReactiveFormsModule } from '@angular/forms';
// // import { CommonModule } from '@angular/common';


// // @Component({
// //   selector: 'app-second-dwelling',
// //   imports: [ReactiveFormsModule, CommonModule],
// //   templateUrl: './second-dwelling.component.html',
// //   styleUrls: ['./second-dwelling.component.css']
// // })
// // export class SecondDwellingComponent implements OnInit {
// //   @Input() formGroup!: FormGroup;

// //   constructor(private fb: FormBuilder) {} // ✅ inject FormBuilder

// //   ngOnInit(): void {
// //     // Add reactive form controls
// //     this.formGroup.addControl('type', this.fb.control(''));
// //     this.formGroup.addControl('extraCharge', this.fb.control(''));
// //   }
// // }
// import { Component, Input, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-second-dwelling',
//   standalone: true, // Angular 14+ feature
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './second-dwelling.component.html',
//   styleUrls: ['./second-dwelling.component.css']
// })
// export class SecondDwellingComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   // Options for the second dwelling
//   dwellingOptions = [
//     { value: 'inspect', label: 'Inspect and accept extra charge ($275)' },
//     { value: 'skip', label: 'Skip inspection for second dwelling' },
//     { value: 'none', label: 'No second dwelling on site' }
//   ];

//   constructor(private fb: FormBuilder) {}

//   ngOnInit(): void {
//     // Add reactive form controls with default values
//     if (!this.formGroup.contains('type')) {
//       this.formGroup.addControl('type', this.fb.control('', Validators.required));
//     }
//     if (!this.formGroup.contains('extraCharge')) {
//       this.formGroup.addControl('extraCharge', this.fb.control({ value: 0, disabled: true }));
//     }

//     // Enable/disable extraCharge based on selection
//     this.formGroup.get('type')?.valueChanges.subscribe(value => {
//       const chargeControl = this.formGroup.get('extraCharge');
//       if (value === 'inspect') {
//         chargeControl?.enable();
//         chargeControl?.setValue(275);
//       } else {
//         chargeControl?.disable();
//         chargeControl?.setValue(0);
//       }
//     });
//   }
// }


import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-second-dwelling',
  standalone: true, // Angular 14+ feature
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './second-dwelling.component.html',
  styleUrls: ['./second-dwelling.component.css']
})
export class SecondDwellingComponent implements OnInit {
  @Input() formGroup!: FormGroup;

  // Options for the second dwelling
  dwellingOptions = [
    { value: 'inspect', label: 'Inspect and accept extra charge ($275)' },
    { value: 'skip', label: 'Skip inspection for second dwelling' },
    { value: 'none', label: 'No second dwelling on site' }
  ];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    // Add reactive form controls with default values
    if (!this.formGroup.contains('type')) {
      this.formGroup.addControl('type', this.fb.control('', Validators.required));
    }
    if (!this.formGroup.contains('extraCharge')) {
      this.formGroup.addControl('extraCharge', this.fb.control({ value: 0, disabled: true }));
    }

    // Enable/disable extraCharge based on selection
    this.formGroup.get('type')?.valueChanges.subscribe(value => {
      const chargeControl = this.formGroup.get('extraCharge');
      if (value === 'inspect') {
        chargeControl?.enable();
        chargeControl?.setValue(275);
      } else {
        chargeControl?.disable();
        chargeControl?.setValue(0);
      }
    });
  }
}
