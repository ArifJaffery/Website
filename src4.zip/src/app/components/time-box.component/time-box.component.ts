import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-time-box',
  templateUrl: './time-box.component.html',
  styleUrls: ['./time-box.component.scss']
})
export class TimeBoxComponent implements OnInit, OnDestroy {
  time: string = '';
  private timerId!: number;

  ngOnInit(): void {
    this.updateTime();
    this.timerId = window.setInterval(() => {
      this.updateTime();
    }, 1000);
  }

  ngOnDestroy(): void {
    clearInterval(this.timerId);
  }

  private updateTime(): void {
    const now = new Date();
    this.time = now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  }
}
