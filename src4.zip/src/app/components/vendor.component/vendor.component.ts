// // import { Component, Input, OnInit } from '@angular/core';
// // import { FormGroup, FormBuilder } from '@angular/forms';
// // import { ReactiveFormsModule } from '@angular/forms';
// // import { CommonModule } from '@angular/common';

// // @Component({
// //   selector: 'app-vendor',
// //   imports: [ReactiveFormsModule, CommonModule],
// //   templateUrl: './vendor.component.html',
// //   styleUrls: ['./vendor.component.css']
// // })
// // export class VendorComponent implements OnInit {
// //   @Input() formGroup!: FormGroup;
// //   @Input() label: string = 'Vendor';

// //   constructor(private fb: FormBuilder) {}

// //   ngOnInit(): void {
// //     this.formGroup.addControl('givenName', this.fb.control(''));
// //     this.formGroup.addControl('surname', this.fb.control(''));
// //     this.formGroup.addControl('email', this.fb.control(''));
// //     this.formGroup.addControl('mobilePhone', this.fb.control(''));
// //     this.formGroup.addControl('usedForDiscountVoucher', this.fb.control(false));
// //   }
// // }
// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-vendor',
//   standalone: true, // Angular 14+ feature
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './vendor.component.html',
//   styleUrls: ['./vendor.component.css']
// })
// export class VendorComponent implements OnInit {
//   @Input() formGroup!: FormGroup;
//   @Input() label: string = 'Vendor';

//   constructor(private fb: FormBuilder) {}

//   ngOnInit(): void {
//     // Add form controls with validators
//     if (!this.formGroup.contains('givenName')) {
//       this.formGroup.addControl('givenName', this.fb.control('', Validators.required));
//     }
//     if (!this.formGroup.contains('surname')) {
//       this.formGroup.addControl('surname', this.fb.control('', Validators.required));
//     }
//     if (!this.formGroup.contains('email')) {
//       this.formGroup.addControl('email', this.fb.control('', [Validators.required, Validators.email]));
//     }
//     if (!this.formGroup.contains('mobilePhone')) {
//       this.formGroup.addControl('mobilePhone', this.fb.control('', Validators.required));
//     }
//     if (!this.formGroup.contains('usedForDiscountVoucher')) {
//       this.formGroup.addControl('usedForDiscountVoucher', this.fb.control(false));
//     }
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-vendor',
  standalone: true, // Angular 14+ feature
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './vendor.component.html',
  styleUrls: ['./vendor.component.css']
})
export class VendorComponent implements OnInit {
  @Input() formGroup!: FormGroup;
  @Input() label: string = 'Vendor';

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    // Add form controls with validators
    if (!this.formGroup.contains('givenName')) {
      this.formGroup.addControl('givenName', this.fb.control('', Validators.required));
    }
    if (!this.formGroup.contains('surname')) {
      this.formGroup.addControl('surname', this.fb.control('', Validators.required));
    }
    if (!this.formGroup.contains('email')) {
      this.formGroup.addControl('email', this.fb.control('', [Validators.required, Validators.email]));
    }
    if (!this.formGroup.contains('mobilePhone')) {
      this.formGroup.addControl('mobilePhone', this.fb.control('', Validators.required));
    }
    if (!this.formGroup.contains('usedForDiscountVoucher')) {
      this.formGroup.addControl('usedForDiscountVoucher', this.fb.control(false));
    }
  }
}
