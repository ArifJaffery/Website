// api-payload.ts

import { ListingAgent } from "./listingagent.model";
import { CoListingAgent} from "./colistingagent.model";
import { AdministrationTeamMember } from "./adminteammember.model";
import { NotificationParty } from "./notificationparty.model";
import { Vendor } from "./vendor.model";
import { PropertyAddress } from "./propertyaddress.model";
import { InspectionSchedule } from "./inspectionschedule.model";
import { PropertyAccessOption } from "./propertyaccess.model";

import { PaymentMethod } from "./paymentmethod.model";
import { PoolDetails } from "./pooldetails.model";
import { SecondDwellingOption } from "./seconddwelling.model";
import { SaleTypeOption } from "./saletype.model";
import { OpenHouseAuction } from "./openhouseauction.model";
import { SpecialInstructions } from "./specialinstruction.model";
import { TermsAndConditions } from "./termsandconditions.model";
import { PreInspectionAgreement } from "./preinspectionagreement.model";
import { ContractAcknowledgement } from "./contractacknowledgment.model";
import { Contact, ContactType } from "./contact.model";
import { CostModel } from "./costmodal.model";

/**
 * Full Booking Inspection Request Payload
 */
export interface BookingInspectionRequest {
  // Section 1: Agents & Notifications
//   listingAgent: ListingAgent;
  listingAgent: Contact;
  coListingAgent?: Contact;
  adminTeam?: Contact;
  notificationParty?: NotificationParty;

  // Section 2: Vendor Details
  vendorHusband: Vendor;
  vendorWife?: Vendor;

  // Section 3: Property Address
  propertyAddress: PropertyAddress;

  // Section 4: Inspection Schedule
  inspectionSchedule: InspectionSchedule;

  // Section 5: Property Access
  propertyAccess: PropertyAccessOption;

  // Section 6: Cost Model / Qualifying Questions
  costModel: CostModel;

  // Section 7: Payment Method
  paymentMethod: PaymentMethod;

  // Section 8: Pool Details
  poolDetails?: PoolDetails;

  // Section 9: Second Dwelling / Granny Flat
  secondDwelling?: SecondDwellingOption;

  // Section 10: Type of Sale
  saleType: SaleTypeOption;

  // Section 11: Open House / Auction Date & Time
  openHouseAuction?: OpenHouseAuction;

  // Section 12: Special Instructions
  specialInstructions?: SpecialInstructions;

  // Section 13: Terms and Conditions Acceptance
  termsAndConditions: TermsAndConditions;

  // Section 14: Pre-Inspection Agreement
  preInspectionAgreement: PreInspectionAgreement;

  // Section 15: Contract Acknowledgement
  contractAcknowledgement: ContractAcknowledgement;

  // Section 16: Order Completion
  orderCompleted: boolean;

  // Section 17: Payment Processing Instructions
  paymentProcessingInstructions?: string; // optional notes for API/email logic
}

