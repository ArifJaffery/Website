// coListingAgent.ts

// Interface representing a Co-Listing Agent
export interface CoListingAgent {
  givenName: string;
  surname: string;
  email: string;
  mobilePhone: string;
}

// Array to store co-listing agents (supporting multiple entries if needed)
export const coListingAgents: CoListingAgent[] = [];

// Function to add a new co-listing agent
export function addCoListingAgent(agent: CoListingAgent): void {
  // Basic validation to ensure all fields are filled
  if (!agent.givenName || !agent.surname || !agent.email || !agent.mobilePhone) {
    throw new Error("All fields are required for a co-listing agent.");
  }

  coListingAgents.push(agent);
  console.log(`Co-Listing Agent added: ${agent.givenName} ${agent.surname}`);
}

// Function to list all co-listing agents
export function listCoListingAgents(): void {
  if (coListingAgents.length === 0) {
    console.log("No co-listing agents added yet.");
    return;
  }

  console.log("Co-Listing Agents:");
  coListingAgents.forEach((agent, index) => {
    console.log(
      `${index + 1}. ${agent.givenName} ${agent.surname} | Email: ${agent.email} | Mobile: ${agent.mobilePhone}`
    );
  });
}

// Example usage
/*
addCoListingAgent({
  givenName: "Emily",
  surname: "Clark",
  email: "emily.clark@example.com",
  mobilePhone: "+61412345678"
});

listCoListingAgents();
*/
