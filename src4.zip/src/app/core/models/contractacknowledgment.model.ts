// contract-acknowledgement.ts

/**
 * Section 15 – Contract Acknowledgement
 * Confirms that proceeding constitutes a binding contract between all parties
 */

export interface ContractAcknowledgement {
  acknowledged: boolean;
  acknowledgementDateTime?: string; // Timestamp of acknowledgement
}

// Holds the contract acknowledgement for this order
export let contractAcknowledgement: ContractAcknowledgement | null = null;

/**
 * Set contract acknowledgement
 * @param acknowledged True if user agrees that proceeding constitutes a contract
 */
export function setContractAcknowledgement(acknowledged: boolean): void {
  if (!acknowledged) {
    throw new Error(
      "You must acknowledge the contract to proceed with the order."
    );
  }

  contractAcknowledgement = {
    acknowledged,
    acknowledgementDateTime: new Date().toISOString(),
  };

  console.log(
    `Contract acknowledged on ${contractAcknowledgement.acknowledgementDateTime}`
  );
}

/**
 * Get current contract acknowledgement
 */
export function getContractAcknowledgement(): ContractAcknowledgement | null {
  return contractAcknowledgement;
}

// Example usage
/*
setContractAcknowledgement(true);
console.log(getContractAcknowledgement());
*/
