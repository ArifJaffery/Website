// cost-model.ts

import { InspectionCost } from "./inspectioncost.model";

/**
 * Section 6 – Select the Cost Model for this order
 */

// Option 1: Directly select a cost model by number (1–14)

// Option 2: View entire price list (reference only)

// Option 3: Use qualifying questions to determine best cost model
export interface CostModelQualifyingQuestions {  
  vendorOrAgentWantCopy: boolean; // 6.3.1
  freeReportAgentVendor: boolean; // 6.3.2
  vendorPaysOneOff: boolean; // 6.3.3
  buyerVendorSmallUpfront: boolean; // 6.3.4
  vendorBuyerFreeFinalBuyerPays: boolean; // 6.3.5
  vendorPaysReducedBuyerPaysReduced: boolean; // 6.3.6
}

export enum CostModelSelectionTypes {
  DirectSelection = 'DirectSelection',
  PriceListSelection  = 'PriceListSelection',
  QualifyingQuestions = 'QualifyingQuestions'
}

// Cost Model
export interface CostModel {
  type: CostModelSelectionTypes;
  inspectionCost : InspectionCost;
  CostModelQualifyingQuestions?: CostModelQualifyingQuestions;
}


// Example usage
/*
setCostModel({
  type: "DirectSelection",
  modelNumber: 5
});

setCostModel({
  type: "QualifyingQuestions",
  vendorOrAgentWantCopy: true,
  freeReportAgentVendor: false,
  vendorPaysOneOff: false,
  buyerVendorSmallUpfront: true,
  vendorBuyerFreeFinalBuyerPays: false,
  vendorPaysReducedBuyerPaysReduced: false
});

console.log(getCostModel());
*/
