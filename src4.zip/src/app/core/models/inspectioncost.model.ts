export enum InspectionType {
  BuildingPest = 'Building & Pest',
  Strata = 'Strata'
}

export interface InspectionCost {
  id : string;
  type?: InspectionType;   // enum value
  vendor: number;         // vendor cost
  buyer: number;          // buyer cost
  finalBuyer: number;     // final buyer cost
}
