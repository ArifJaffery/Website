// inspection-schedule.ts

/**
 * Section 4.1 – Select the Inspection Date and Time
 */

export interface InspectionSchedule {
  inspectionDate: string; // ISO date string (YYYY-MM-DD)
  inspectionTime: string; // Time string (HH:MM 24-hour format)
}

// Holds the inspection schedule for this order
export let inspectionSchedule: InspectionSchedule | null = null;

// Save inspection schedule
export function setInspectionSchedule(schedule: InspectionSchedule): void {
  if (!schedule.inspectionDate || !schedule.inspectionTime) {
    throw new Error("Both inspection date and time are required.");
  }

  inspectionSchedule = schedule;

  console.log(
    `Inspection scheduled for: ${schedule.inspectionDate} at ${schedule.inspectionTime}`
  );
}

// Retrieve inspection schedule
export function getInspectionSchedule(): InspectionSchedule | null {
  return inspectionSchedule;
}

// Example usage
/*
setInspectionSchedule({
  inspectionDate: "2026-02-0
  */