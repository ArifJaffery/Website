// open-house-auction.ts

/**
 * Section 11 – Date of First Open House / Auction Date & Time
 */

export interface OpenHouseAuction {
  firstOpenHouseDateTime?: string; // ISO date-time string (YYYY-MM-DDTHH:MM)
  auctionDateTime?: string; // ISO date-time string (YYYY-MM-DDTHH:MM)
}

// Holds the open house / auction details for this order
export let openHouseAuction: OpenHouseAuction | null = null;

/**
 * Set open house and/or auction date & time
 * @param details Open house / auction details
 */
export function setOpenHouseAuction(details: OpenHouseAuction): void {
  if (!details.firstOpenHouseDateTime && !details.auctionDateTime) {
    throw new Error(
      "At least one of First Open House or Auction Date & Time must be provided."
    );
  }

  openHouseAuction = details;

  if (details.firstOpenHouseDateTime) {
    console.log(`First Open House scheduled: ${details.firstOpenHouseDateTime}`);
  }

  if (details.auctionDateTime) {
    console.log(`Auction scheduled: ${details.auctionDateTime}`);
  }
}

/**
 * Get current open house / auction details
 */
export function getOpenHouseAuction(): OpenHouseAuction | null {
  return openHouseAuction;
}

// Example usage
/*
setOpenHouseAuction({
  firstOpenHouseDateTime: "2026-02-15T10:00",
});

setOpenHouseAuction({
  auctionDateTime: "2026-03-01T14:30",
});

setOpenHouseAuction({
  firstOpenHouseDateTime: "2026-02-15T10:00",
  auctionDateTime: "2026-03-01T14:30",
});

console.log(getOpenHouseAuction());
*/
