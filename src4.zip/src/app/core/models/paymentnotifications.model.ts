// payment-notifications.ts

import { PaymentMethod } from "./paymentmethod.model";

// Enum for email types to send
export enum EmailType {
  ImmediatePayment = "ImmediatePayment",
  StandardConfirmation = "StandardConfirmation",
}

// Interface for payment notification action
export interface PaymentNotification {
  paymentMethod: PaymentMethod;
  emailType: EmailType;
  sentDateTime?: string;
  notes?: string;
}

// Array to store all notifications sent
export const paymentNotifications: PaymentNotification[] = [];

// Function to process payment notification based on selected payment method
export function processPaymentNotification(payment: PaymentMethod): void {
  let emailType: EmailType;

  switch (payment.type) {
    case "PayNow":
      emailType = EmailType.ImmediatePayment;
      break;
    case "AgencyEOM":
    case "VendorDirect":
      emailType = EmailType.StandardConfirmation;
      break;
    default:
      emailType = EmailType.StandardConfirmation;
  }

  const notification: PaymentNotification = {
    paymentMethod: payment,
    emailType,
    sentDateTime: new Date().toISOString(),
    notes:
      emailType === EmailType.ImmediatePayment
        ? "Send agent to email to take payment now."
        : "Send standard confirmation email with order approval.",
  };

  paymentNotifications.push(notification);

  console.log(
    `Payment notification created: ${emailType} for method ${payment.type}`
  );
}

// Function to list all payment notifications
export function listPaymentNotifications(): void {
  if (paymentNotifications.length === 0) {
    console.log("No payment notifications sent yet.");
    return;
  }

  console.log("Payment Notifications:");
  paymentNotifications.forEach((notification, index) => {
    console.log(`${index + 1}. Payment Method: ${notification.paymentMethod.type}`);
    console.log(`   Email Type: ${notification.emailType}`);
    console.log(`   Sent Date/Time: ${notification.sentDateTime}`);
    if (notification.notes) console.log(`   Notes: ${notification.notes}`);
  });
}

// Example usage
/*
import { paymentMethods } from "./payment-method";

// Process notifications for all added payment methods
paymentMethods.forEach((pm) => processPaymentNotification(pm));

listPaymentNotifications();
*/
