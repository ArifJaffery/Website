// pool-details.ts

/**
 * Section 8 – Pool Details
 */

export interface PoolDetails {
  hasPool: boolean;
  requestComplianceCertificate?: boolean; // Only applicable if hasPool is true
}

// Holds the pool details for this order
export let poolDetails: PoolDetails | null = null;

/**
 * Sets the pool details
 * @param details Pool information
 */
export function setPoolDetails(details: PoolDetails): void {
  if (details.hasPool && details.requestComplianceCertificate === undefined) {
    // Default to false if not explicitly selected
    details.requestComplianceCertificate = false;
  }

  poolDetails = details;

  console.log(
    details.hasPool
      ? `Property has a pool. Pool compliance certificate requested: ${details.requestComplianceCertificate}`
      : "Property does not have a pool."
  );
}

/**
 * Gets the current pool details
 */
export function getPoolDetails(): PoolDetails | null {
  return poolDetails;
}

// Example usage
/*
setPoolDetails({
  hasPool: true,
  requestComplianceCertificate: true
});

setPoolDetails({
  hasPool: false
});

console.log(getPoolDetails());
*/
