// pre-inspection-consent.ts

// Interface for pre-inspection agreement consent
export interface PreInspectionConsent {
  consentGiven: boolean; // Did the user agree and wish to proceed?
  consentDateTime?: string; // Optional date/time when consent was given
  notes?: string; // Optional free text notes
}

// Array to store multiple consents (for multiple orders)
export const preInspectionConsents: PreInspectionConsent[] = [];

// Function to add consent
export function addPreInspectionConsent(consent: PreInspectionConsent): void {
  if (!consent.consentGiven) {
    throw new Error("Consent must be given to proceed with the order.");
  }

  // Set current date/time if not provided
  if (!consent.consentDateTime) {
    consent.consentDateTime = new Date().toISOString();
  }

  preInspectionConsents.push(consent);
  console.log("Pre-inspection agreement consent recorded.");
}

// Function to list all consents
export function listPreInspectionConsents(): void {
  if (preInspectionConsents.length === 0) {
    console.log("No pre-inspection consents recorded yet.");
    return;
  }

  console.log("Pre-Inspection Consents:");
  preInspectionConsents.forEach((consent, index) => {
    console.log(`${index + 1}. Consent Given: ${consent.consentGiven ? "Yes" : "No"}`);
    console.log(`   Date/Time: ${consent.consentDateTime}`);
    if (consent.notes) console.log(`   Notes: ${consent.notes}`);
  });
}

// Example usage
/*
addPreInspectionConsent({ consentGiven: true, notes: "User agreed via online portal." });
listPreInspectionConsents();
*/
