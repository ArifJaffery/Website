// pre-inspection-agreement.ts

/**
 * Section 14 – Pre-Inspection Agreement Acceptance
 * Agent confirms they have read, understood, and agree to proceed with the order
 */

export interface PreInspectionAgreement {
  accepted: boolean;
  acceptanceDateTime?: string; // Timestamp of when the agreement was accepted
}

// Holds the pre-inspection agreement acceptance for this order
export let preInspectionAgreement: PreInspectionAgreement | null = null;

/**
 * Set acceptance of pre-inspection agreement
 * @param accepted True if agent agrees
 */
export function setPreInspectionAgreement(accepted: boolean): void {
  if (!accepted) {
    throw new Error(
      "You must accept the Pre-Inspection Agreement to proceed with the order."
    );
  }

  preInspectionAgreement = {
    accepted,
    acceptanceDateTime: new Date().toISOString(),
  };

  console.log(
    `Pre-Inspection Agreement accepted on ${preInspectionAgreement.acceptanceDateTime}`
  );
}

/**
 * Get current pre-inspection agreement acceptance
 */
export function getPreInspectionAgreement(): PreInspectionAgreement | null {
  return preInspectionAgreement;
}

// Example usage
/*
setPreInspectionAgreement(true);
console.log(getPreInspectionAgreement());
*/
