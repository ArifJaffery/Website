// property-access.ts

/**
 * Section 5 – Who will be providing access to the property
 * Notifications via email and text messages will be sent to them Pre and Post inspection
 */

// Access via Vendor
export interface VendorAccess {
  type: "Vendor";
  name: string;
  phone: string;
  email: string;
}

// Access via Agent
export interface AgentAccess {
  type: "Agent";
  name: string;
  mobilePhone: string;
  email: string;
}

// Access via Tenant
export interface TenantAccess {
  type: "Tenant";
  name: string;
  phone: string;
  email: string;
}

// Access via Lock Box
export interface LockBoxAccess {
  type: "LockBox";
  locationDescription: string;
  phone: string;
}

// Access via Key placed on site
export interface KeyOnSiteAccess {
  type: "KeyOnSite";
  locationDescription: string;
}

// Access via Pick up from Agent Office
export interface PickupFromAgentOfficeAccess {
  type: "PickupFromAgentOffice";
  pickupAddress: string;
  dropoffAddress: string;
  serviceCharge?: number; // defaults to $35 each way if applicable
}

// Discriminated union for property access
export type PropertyAccessOption =
  | VendorAccess
  | AgentAccess
  | TenantAccess
  | LockBoxAccess
  | KeyOnSiteAccess
  | PickupFromAgentOfficeAccess;

// Holds the selected access option for this order
export let propertyAccess: PropertyAccessOption | null = null;

// Set property access
export function setPropertyAccess(access: PropertyAccessOption): void {
  if (!access) throw new Error("Property access details are required.");

  propertyAccess = access;

  console.log(`Property access set: ${access.type}`);
}

// Get property access
export function getPropertyAccess(): PropertyAccessOption | null {
  return propertyAccess;
}

// Example usage
/*
setPropertyAccess({
  type: "Vendor",
  name: "John Smith",
  phone: "+61412345678",
  email: "john.smith@example.com"
});

setPropertyAccess({
  type: "LockBox",
  locationDescription: "Next to the garage door",
  phone: "+61487654321"
});

console.log(getPropertyAccess());
*/
