export interface PropertyAccessContact {
  name: string;
  phoneNumber: string;
  email: string;
  relationship: "Vendor" | "Agent" | "Other"; // optional categorization
}