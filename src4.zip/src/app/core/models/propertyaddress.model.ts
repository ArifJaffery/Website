// property-address.ts

/**
 * Section 3.1 – Property Address
 */

export interface PropertyAddress {
  houseNumber: string;
  streetName: string;
  suburb: string;
  postCode: string;
  state: string;
}

// Holds the property address for this order
export let propertyAddress: PropertyAddress | null = null;

// Save property address
export function setPropertyAddress(address: PropertyAddress): void {
  if (
    !address.houseNumber ||
    !address.streetName ||
    !address.suburb ||
    !address.postCode ||
    !address.state
  ) {
    throw new Error("All property address fields are required.");
  }

  propertyAddress = address;

  console.log(
    `Property address set: ${address.houseNumber} ${address.streetName}, ${address.suburb} ${address.state} ${address.postCode}`
  );
}

// Retrieve property address
export function getPropertyAddress(): PropertyAddress | null {
  return propertyAddress;
}

// Example usage
/*
setPropertyAddress({
  houseNumber: "25",
  streetName: "George Street",
  suburb: "Parramatta",
  postCode: "2150",
  state: "NSW"
});

console.log(getPropertyAddress());
*/
