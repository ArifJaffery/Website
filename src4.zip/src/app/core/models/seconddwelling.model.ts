// second-dwelling.ts

/**
 * Section 9 – Second Dwelling / Granny Flat / Additional Habitable Space
 */

// Option 1: Second dwelling exists and is to be inspected (extra $275)
export interface InspectSecondDwelling {
  type: "Inspect";
  extraCharge: number; // $275
}

// Option 2: Second dwelling exists but NOT inspected
export interface NotInspectSecondDwelling {
  type: "NotInspect";
}

// Option 3: No second dwelling exists
export interface NoSecondDwelling {
  type: "None";
}

// Union type for all options
export type SecondDwellingOption =
  | InspectSecondDwelling
  | NotInspectSecondDwelling
  | NoSecondDwelling;

// Holds the selected second dwelling option
export let secondDwellingSelection: SecondDwellingOption | null = null;

/**
 * Set the second dwelling option
 * @param option Option selected
 */
export function setSecondDwelling(option: SecondDwellingOption): void {
  secondDwellingSelection = option;

  switch (option.type) {
    case "Inspect":
      console.log(
        `Second dwelling on site will be inspected. Extra charge: $${option.extraCharge}`
      );
      break;
    case "NotInspect":
      console.log("Second dwelling exists but will NOT be inspected.");
      break;
    case "None":
      console.log("No second dwelling / granny flat / additional living area on site.");
      break;
  }
}

/**
 * Get the current second dwelling selection
 */
export function getSecondDwelling(): SecondDwellingOption | null {
  return secondDwellingSelection;
}

// Example usage
/*
setSecondDwelling({ type: "Inspect", extraCharge: 275 });
setSecondDwelling({ type: "NotInspect" });
setSecondDwelling({ type: "None" });

console.log(getSecondDwelling());
*/
