// terms-and-conditions.ts

/**
 * Section 13 – Terms and Conditions Acceptance
 * Must be approved by the listing agent processing the online order
 */

export interface TermsAndConditions {
  approvedByListingAgent: boolean; // True if listing agent has accepted
  approvalDateTime?: string; // Optional timestamp for reference
  referenceDocs?: string[]; // Optional list of referenced documents (Work order, TPI Terms, Responsibilities)
}

// Holds the terms and conditions acceptance for this order
export let termsAndConditions: TermsAndConditions | null = null;

/**
 * Set terms and conditions approval
 * @param approved True if listing agent approves
 * @param referenceDocs Optional list of referenced docs
 */
export function setTermsAndConditions(
  approved: boolean,
  referenceDocs?: string[]
): void {
  if (!approved) {
    throw new Error("Terms and Conditions must be approved to proceed.");
  }

  termsAndConditions = {
    approvedByListingAgent: approved,
    approvalDateTime: new Date().toISOString(),
    referenceDocs,
  };

  console.log(
    `Terms and Conditions approved by listing agent on ${termsAndConditions.approvalDateTime}`
  );
}

/**
 * Get current terms and conditions acceptance
 */
export function getTermsAndConditions(): TermsAndConditions | null {
  return termsAndConditions;
}

// Example usage
/*
setTermsAndConditions(true, [
  "Work Order / Terms and Conditions / Contract",
  "Responsibilities of Vendor / Agent / Buyer / Inspector",
  "TPI Standard Company Terms and Conditions"
]);

console.log(getTermsAndConditions());
*/
