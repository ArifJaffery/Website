export interface UserProfile {
  businessName: string;
  companyName: string;
  abnAcn: string;
  businessType: string;
  businessTypeOther: string;
  officeAddress: string;
  website: string;

  primaryFullName: string;
  primaryPosition: string;
  primaryMobile: string;
  primaryEmail: string;

  contactTextMessage: boolean;
  contactEmail: boolean;
  contactPhoneMobile: boolean;
  contactPhoneOffice: boolean;

  listingAgentName: string;
  listingAgentEmail: string;
  listingAgentPhoneLandline: string;
  listingAgentPhoneMobile: string;

  coListingAgentName: string;
  coListingAgentPhoneLandline: string;
  coListingAgentPhoneMobile: string;
  coListingAgentEmail: string;

  salesAdminName: string;
  salesAdminPhoneLandline: string;
  salesAdminPhoneMobile: string;
  salesAdminEmail: string;

  accountsName: string;
  accountsPhoneLandline: string;
  accountsPhoneMobile: string;
  accountsEmail: string;

  jobTypes: string[];
  areasOperated: string;
  jobsPerMonth: string;

  invoiceAddress: 'business' | 'personal';
  paymentMethod: 'bank' | 'card';

  term7DaysAgent: boolean;
  termAtOrderAgent: boolean;
  termAtOrderClient: boolean;

  username: string;
  password: string;        // ⚠️ consider hashing on backend
  authorised: boolean;

  agreeTc: boolean;
  agreePrivacy: boolean;
  consent: boolean;

  howHeard: string;
  notes: string;
  priorityBooking: 'Yes' | 'No';

  email: string;
}
