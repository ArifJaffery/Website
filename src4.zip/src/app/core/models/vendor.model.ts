// vendor-husband.ts

// Interface representing Vendor (Husband)
export interface Vendor {
  givenName: string;
  surname: string;
  email: string;
  mobilePhone: string;
  usedForDiscountVoucher: boolean; // Indicates usage for $200 discount voucher
}

// Storage for vendor husband details (one per order)
export let vendor: Vendor | null = null;

// Function to set vendor  details
export function setVendorHusband(details: Vendor): void {
  // Validation
  if (
    !details.givenName ||
    !details.surname ||
    !details.email ||
    !details.mobilePhone
  ) {
    throw new Error("All vendor (husband) fields are required.");
  }

  vendor = {
    ...details,
    usedForDiscountVoucher: true,
  };

  console.log(
    `Vendor (Husband) set: ${details.givenName} ${details.surname} – Discount voucher enabled`
  );
}

// Function to get vendor husband details
export function getVendorHusband(): Vendor | null {
  return vendor;
}

// Example usage
/*
setVendorHusband({
  givenName: "Michael",
  surname: "Johnson",
  email: "michael.johnson@example.com",
  mobilePhone: "+61412345678",
  usedForDiscountVoucher: true
});

console.log(getVendorHusband());
*/
