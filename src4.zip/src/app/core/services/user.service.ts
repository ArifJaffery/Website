import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user.model';

@Injectable({ providedIn: 'root' })
export class UserService {

  // Internal state holder
  private userSubject = new BehaviorSubject<User | null>(null);

  // Public observable (read-only)
  user$: Observable<User | null> = this.userSubject.asObservable();

  /** Set user (login success) */
  setUser(user: User): void {
    this.userSubject.next(user);
  }

  /** Get current user synchronously (rarely needed) */
  getUser(): User | null {
    return this.userSubject.value;
  }

  /** Clear user (logout) */
  clearUser(): void {
    this.userSubject.next(null);
  }
}
