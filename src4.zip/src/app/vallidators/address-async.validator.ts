import { Directive } from '@angular/core';
import { NG_ASYNC_VALIDATORS, AsyncValidator, AbstractControl, ValidationErrors } from '@angular/forms';
import { Observable, of, timer } from 'rxjs';
import { switchMap, map, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Directive({
  selector: '[addressAsyncValidator]',
  providers: [
    {
      provide: NG_ASYNC_VALIDATORS,
      useExisting: AddressAsyncValidatorDirective,
      multi: true
    }
  ]
})
export class AddressAsyncValidatorDirective implements AsyncValidator {

  constructor(private http: HttpClient) {}

  validate(control: AbstractControl): Observable<ValidationErrors | null> {
    const v = control.value;

    if (
      !v?.unitNumber ||
      !v?.streetNumber ||
      !v?.streetName ||
      !v?.suburb ||
      !v?.state
    ) {
      return of(null);
    }

    return timer(600).pipe(
      switchMap(() =>
        this.http.post<any>('/api/validate-address', {
          unitNumber: v.unitNumber,
          streetNumber: v.streetNumber,
          streetName: v.streetName,
          suburb: v.suburb,
          state: v.state
        }).pipe(
          map(res => res.valid ? null : { invalidAddress: true }),
          catchError(() => of({ invalidAddress: true }))
        )
      )
    );
  }
}
