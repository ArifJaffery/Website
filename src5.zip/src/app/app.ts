import { Component, signal } from '@angular/core';
import { HeroSectionComponent } from './components/hero-section.component/hero-section.component';
import { FeaturesGridComponent } from './components/features-grid.component/features-grid.component';
import { CtaSectionComponent } from './components/cta-section.component/cta-section.component';
import { NgIf } from '@angular/common';
import { RouterModule, RouterOutlet } from '@angular/router';
import { HeaderComponent } from './components/header.component/header.component';
import { ApplicationService } from './core/services/Application.service';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [HeroSectionComponent, FeaturesGridComponent, CtaSectionComponent, NgIf, RouterOutlet,HeaderComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  showRegister = false;

  protected readonly title = signal('vendor-booking-portal');

  constructor(private applicationService: ApplicationService) {
  }

  ngOnInit() {
    const current = this.applicationService.getUser();
    this.applicationService.updateState({
      ...current,
      enableBookingsDashboard: false,
      enablePropertyReportSelector: true,
      enableBookingRequest: false,
      enableLogin: false,
      enableRegistration: false
    });

  } 

}
