import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators , FormsModule, FormControl} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BookingInspectionRequest } from '../../core/models/bookingrequest.model';

// Child Components
import { ListingAgentComponent } from '../listing-agent.component/listing-agent.component';
import { CoListingAgentComponent } from '../co-listing-agent.component/co-listing-agent.component';
import { AdminTeamComponent } from '../admin-team.component/admin-team.component';
import { NotificationPartyComponent } from '../notification-party.component/notification-party.component';
import { VendorComponent } from '../vendor.component/vendor.component';
import { PropertyAddressComponent } from '../property-address.component/property-address.component';
import { InspectionScheduleComponent } from '../inspection-schedule.component/inspection-schedule.component';
import { PropertyAccessComponent } from '../property-access.component/property-access.component';
import { CostModelComponent } from '../cost-model.component/cost-model.component';
import { PaymentMethodComponent } from '../payment-method.component/payment-method.component';
import { PoolDetailsComponent } from '../pool-details.component/pool-details.component';
import { SecondDwellingComponent } from '../second-dwelling.component/second-dwelling.component';
import { SaleTypeComponent } from '../sale-type.component/sale-type.component';
import { OpenHouseAuctionComponent } from '../open-house-auction.component/open-house-auction.component';
import { SpecialInstructionsComponent } from '../special-instructions.component/special-instructions.component';
import { TermsAndConditionsComponent } from '../terms-and-conditions.component/terms-and-conditions.component';
import { PreInspectionAgreementComponent } from '../pre-inspection-agreement.component/pre-inspection-agreement.component';
import { ContractAcknowledgementComponent } from '../contract-acknowledgement.component/contract-acknowledgement.component';
import { ContactComponent } from '../contact-component/contact-component';
import { Contact, ContactType } from '../../core/models/contact.model';
import { PropertyAddress } from '../../core/models/propertyaddress.model';
import { InspectionSchedule } from '../../core/models/inspectionschedule.model';
import { CompleteOrderComponent} from '../../components/complete-order.component/complete-order.component';

import { BookingService} from '../../core/services/booking.service';
import { UserService } from '../../core/services/user.service';

import { createContactGroup, createPropertyAddressGroup, createCompleteOrderForm,createCostModelForm,createInspectionScheduleGroup,createOpenHouseAuctionDatesForm
, createPaymentMethodForm, createPoolDetailsForm, createSecondDwellingForm, createTypeOfSaleForm, createSpecialInstructionsForm, createTPITermsAndConditionsForm, createPropertyAccessGroup
 } from './create-form-group';

// Add these to existing imports
import { OnDestroy, Output, EventEmitter } from '@angular/core';


import {
  PropertyAccessOption,
  VendorAccess,
  AgentAccess,
  TenantAccess,
  LockBoxAccess,
  KeyOnSiteAccess,
  PickupFromAgentOfficeAccess
} from '../../core/models/propertyaccess.model';
import { CostModel, CostModelSelectionTypes } from '../../core/models/costmodal.model';
import { CostModelTitle, InspectionType } from '../../core/models/inspectioncost.model';
import { PaymentMethod, PaymentTypes } from '../../core/models/paymentmethod.model';
import { PoolDetails } from '../../core/models/pooldetails.model';
import { SecondDwelling } from '../../core/models/seconddwelling.model';
import { SaleType, TypeOfSale } from '../../core/models/saletype.model';
import { OpenHouseAuction, OpenHouseAuctionDates } from '../../core/models/openhouseauction.model';
import { SpecialInstructions } from '../../core/models/specialinstruction.model';
import { TPITermsAndConditions } from '../../core/models/termsandconditions.model';
import { CompleteOrderForm } from '../../core/models/completeorderform.model';
// import { CostModelOption } from '../../core/models/costmodal.model';
import { Router } from '@angular/router';
import { filter, Subject, takeUntil } from 'rxjs';
import { createBlankBooking, createBookingForm } from './blank-booking.factory';


@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    ContactComponent,
    ListingAgentComponent,
    CoListingAgentComponent,
    AdminTeamComponent,
    NotificationPartyComponent,
    VendorComponent,
    PropertyAddressComponent,
    InspectionScheduleComponent,
    PropertyAccessComponent,
    CostModelComponent,
    PaymentMethodComponent,
    PoolDetailsComponent,
    SecondDwellingComponent,
    SaleTypeComponent,
    OpenHouseAuctionComponent,
    SpecialInstructionsComponent,
    TermsAndConditionsComponent,
    PreInspectionAgreementComponent,
    ContractAcknowledgementComponent,    
    CompleteOrderComponent
  ],
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})

export class BookingComponent implements OnInit, OnDestroy {
  @Output() closeForm = new EventEmitter<void>();
  private destroy$ = new Subject<void>();

  bookingForm!: FormGroup;  
  currentStep = 1;
  //step: number = 1;
  totalSteps = 14;
  ContactType = ContactType;
  selectedContactType: ContactType = ContactType.ListingAgent; 
  selectedContactTypeControl!: FormControl;  

  stepTitles: string[] = [
    '', // index 0 unused
    'Business Contacts',
    'Vendor Details',
    'Property Address',
    'Inspection Schedule',
    'Property Access',
    'Cost Model',
    'Payment Method',
    'Pool Compliance',
    'Second Dwelling',
    "Open House / Auction",
    "Special Instructions",
    "T&C's Approval",
    "Complete Order"
  ];

   getStepTitle(step: number): string {
    return this.stepTitles[step] || '';
   }  

   onCompleteOrderClick(){

    this.router.navigate(['/']);
   }

  constructor(private fb: FormBuilder, private bookingService: BookingService, private router: Router, private userService: UserService,
     private cdr: ChangeDetectorRef
  ) {}
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  bookingBusinessObject = (bookingInspectionRequest?: BookingInspectionRequest): BookingInspectionRequest => {
    return bookingInspectionRequest ?? createBlankBooking();
  };  

  ngOnInit(): void {
    this.bookingForm = createBookingForm(this.fb, this.bookingBusinessObject());
    const payload: BookingInspectionRequest = this.bookingForm.value;

    this.bookingForm.valueChanges.subscribe(value => {
      //console.log('Form changed:', JSON.stringify(value, null, 2));
    });  

    this.selectedContactTypeControl = this.fb.control(ContactType.ListingAgent);

// ← ADD THIS — listen for row click from dashboard via service
    this.bookingService.currentBooking$.pipe(
      filter(booking => !!booking),
      takeUntil(this.destroy$)
    ).subscribe(booking => {
      this.patchFormFromBooking(booking!);
    });

  }

private patchFormFromBooking(booking: BookingInspectionRequest): void {
    Promise.resolve().then(() => {

      this.bookingForm.patchValue({
        bookingId:           booking.bookingId        ?? '',
        propertyAddress:     booking.propertyAddress,
        inspectionSchedule:  booking.inspectionSchedule,
        costModel:           booking.costModel,
        paymentMethod:       booking.paymentMethod,
        poolDetails:         booking.poolDetails,
        secondDwelling:      booking.secondDwelling,
        saleType:            booking.saleType,
        openHouseAuction:    booking.openHouseAuction,
        specialInstructions: booking.specialInstructions,
        termsAndConditions:  booking.termsAndConditions,
        orderCompleted:      booking.orderCompleted,
      }, { emitEvent: false });

      this.rebuildFormArray(
        this.bookingForm.get('contacts') as FormArray,
        booking.contacts
      );

      this.rebuildFormArray(
        this.bookingForm.get('vendor') as FormArray,
        booking.vendor
      );

      // Reset to step 1 when a new booking is loaded
      this.currentStep = 1;
      this.cdr.detectChanges();
    });
  }

  private rebuildFormArray(array: FormArray, items: any[] = []): void {
    array.clear({ emitEvent: false });
    items.forEach(item => {
      const group = createContactGroup(
        item.contactType,
        item.showNotificationParty,
        item.showRemoveButton,
        item.showVoucher
      );
      group.patchValue(item, { emitEvent: false });
      array.push(group, { emitEvent: false });
    });
  }

  onClose(): void {
    this.bookingService.clearCurrentBooking(); // clears service state + hides form
    this.closeForm.emit();                     // notifies parent if needed
  }  

  get orderCompleted() : FormGroup {
    return this.bookingForm.get('orderCompleted') as FormGroup;
  } 
  
  get termsAndConditions() : FormGroup {
    return this.bookingForm.get('termsAndConditions') as FormGroup;
  } 
  get specialInstructions() : FormGroup {
    return this.bookingForm.get('specialInstructions') as FormGroup;
  } 

  get openHouseAuction() : FormGroup {
    return this.bookingForm.get('openHouseAuction') as FormGroup;
  } 
  get typeofsale(): FormGroup {
    return this.bookingForm.get('saleType') as FormGroup;
  }

  get paymentMethod(): FormGroup {
    return this.bookingForm.get('paymentMethod') as FormGroup;
  }

  get secondDwelling(): FormGroup {
    return this.bookingForm.get('secondDwelling') as FormGroup;
  }

  get contacts(): FormArray {
    return this.bookingForm.get('contacts') as FormArray;
  }

  get contactsFormGroups(): FormGroup[] {
    return this.contacts.controls.map(c => c as FormGroup);
  }

  get vendor(): FormArray {
    return this.bookingForm.get('vendor') as FormArray;
  }

  get vendorFormGroups(): FormGroup[] {
    return this.vendor.controls.map(c => c as FormGroup);
  }

  get propertyAddress(): FormGroup {
    return this.bookingForm.get('propertyAddress') as FormGroup;
  }

  get inspectionSchedule(): FormGroup {
    return this.bookingForm.get('inspectionSchedule') as FormGroup;
  }

  get propertyAccess(): FormGroup {
    return this.bookingForm.get('propertyAccess') as FormGroup;
  } 

  get costModel(): FormGroup {
    return this.bookingForm.get('costModel') as FormGroup;
  } 

  get getBookingId(): string {
    const bookingIdControl = this.bookingForm.get('bookingId') as FormControl;
    return bookingIdControl ? bookingIdControl.value : '';
  }

  nextStep() {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
    }
    const user = this.userService.getUser()?.userId;
    const payLoad = {
      ...this.bookingForm.value,
      userId: user
    };

    this.bookingService.createBooking(payLoad).pipe(
      filter(res => res.success && !!res.bookingId),
      takeUntil(this.destroy$)
    ).subscribe({
      next: ({ bookingId }) => {
        Promise.resolve().then(() => {
          this.bookingForm.get('bookingId')?.setValue(bookingId, { emitEvent: false });
          this.cdr.detectChanges();
        });
      },
      error: (err) => console.error('Create booking error:', err)
    });
    

    // const user = this.userService.getUser()?.userId;
    // const payLoad = {
    //   ...this.bookingForm.value,
    //   userId: user
    // };

    // console.log('Submitting Booking Payload:',payLoad);

    // this.bookingService.createBooking(payLoad).pipe(
    //   filter(res => res.success && !!res.bookingId),
    //   takeUntil(this.destroy$)
    // ).subscribe({
    //   next: ({ bookingId }) => {
    //     console.log('Booking created successfully with ID:', bookingId);
    //     Promise.resolve().then(() => {
    //       this.bookingForm.get('bookingId')?.setValue(bookingId, { emitEvent: false });
    //       this.cdr.detectChanges();
    //     });
    //   },
    //   error: (err) => {
    //     console.error('Create booking error:', err);
    //   }
    // });
  }

  prevStep() {
    //console.log(`Step =>${this.currentStep}`)
    
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  submitBooking() {
    if (this.bookingForm.valid) {
      const payload: BookingInspectionRequest = this.bookingForm.value;            
    } else {
      console.warn('Form is invalid');
    }
  }

  get poolCompliance(): FormGroup {
    return this.bookingForm.get('poolDetails') as FormGroup;
  }
  
  get listingAgentForm(): FormGroup {
  return this.bookingForm.get('listingAgent') as FormGroup;
  }

  get vendorHusbandForm(): FormGroup {
  return this.bookingForm.get('vendorHusband') as FormGroup;
  }

  get coListingAgentForm(): FormGroup {
  return this.bookingForm.get('coListingAgent') as FormGroup;
  }

  get adminTeamForm(): FormGroup {
  return this.bookingForm.get('adminTeam') as FormGroup;
  }

  get NotificationPartyForm(): FormGroup {
  return this.bookingForm.get('notificationParty') as FormGroup;
  }

  addContact(contactType:any ) {      
    this.contacts.push(createContactGroup(contactType,true,true,false));
  }

  // Remove contact by index
  removeContact(index: number) {
      this.contacts.removeAt(index);
  }

}
