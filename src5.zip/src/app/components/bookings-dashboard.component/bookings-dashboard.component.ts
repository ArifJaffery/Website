import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { BookingService } from '../../core/services/booking.service';
import { BookingInspectionRequest } from '../../core/models/bookingrequest.model';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatCardModule } from '@angular/material/card';
import { CostModelSelectionTypes } from '../../core/models/costmodal.model';
import { CostModelTitle, InspectionType } from '../../core/models/inspectioncost.model';
import { ContactType } from '../../core/models/contact.model';
import { PaymentTypes } from '../../core/models/paymentmethod.model';
import { SaleType } from '../../core/models/saletype.model';
import { Roles } from '../../core/models/completeorderform.model';
import { ApplicationService } from '../../core/services/Application.service';

@Component({
  selector: 'app-bookings-dashboard',
  standalone: true,
  imports: [
    MatCardModule,
    MatProgressSpinnerModule,
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatChipsModule,    
  ],
  templateUrl: './bookings-dashboard.component.html',
  styleUrls: ['./bookings-dashboard.component.scss']
})
export class BookingsDashboardComponent implements OnInit, AfterViewInit {

  displayedColumns: string[] = [
    'address',
    'inspectionType',
    'costModel',
    'date',
    'time',
    'vendor'
  ];

  dataSource = new MatTableDataSource<BookingInspectionRequest>();
  loading = true;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private bookingService: BookingService,private applicationService: ApplicationService) {}
  
  ngOnInit(): void {
    this.bookingService.bookings$.subscribe(bookings => {
      console.log('Received bookings:', bookings); // Debug log 
        if (bookings) {
            this.dataSource.data = bookings;
      }       
    });
    this.loading = false;
}

onRowClick(row: any) {
  // console.log('Row clicked:', row);  
  const current = this.applicationService.getUser();
  this.applicationService.updateState({
    ...current,
    enableBookingsDashboard: false,
    enablePropertyReportSelector: false,
    enableBookingRequest: true,
    enableLogin: false,
    enableRegistration: false
  });

  //this.selectedRow = row;
  this.bookingService.selectBooking(row);  // ← pushes to service, shows form
}

setPayLoad(){
      this.dataSource.data = [
        {
          contacts: [
            {
              givenName : '', surname: '', email : '', mobilePhone: '', contactType : ContactType.ListingAgent, notifyParty : true, showNotificationParty : false,
              showRemoveButton : false, showVoucher : false
            },
            {
              givenName : '', surname: '', email : '', mobilePhone: '', contactType : ContactType.CoListingAgent, notifyParty : true, showNotificationParty : false,
              showRemoveButton : false, showVoucher : false
            },
            {
              givenName : '', surname: '', email : '', mobilePhone: '', contactType : ContactType.AdministrationTeam, notifyParty : true, showNotificationParty : false,
              showRemoveButton : false, showVoucher : false
            }
          ],
          vendor: [
            {
              givenName : 'Craig', surname: 'Bolton', email : '', mobilePhone: '', contactType : ContactType.Husband, notifyParty : true, showNotificationParty : false,
              showRemoveButton : false, showVoucher : false
            },
            {
              givenName : 'Harvey', surname: 'Greg', email : '', mobilePhone: '', contactType : ContactType.Wife, notifyParty : true, showNotificationParty : false,
              showRemoveButton : false, showVoucher : false
            }
          ],
          propertyAddress: {
            houseNumber: '12',
            streetName: 'George Street',
            suburb: 'Parramatta',
            state: 'NSW',
            postCode: '2150'
          },
          inspectionSchedule: {
            inspectionDate : '2026-02-12T10:30:00',
            inspectionTime : '2026-02-12T11:30:00'
          },
          propertyAccess: {
            type : 'Vendor',
            name : '',
            phone : '',
            email: ''
          },
          costModel: {
            type: CostModelSelectionTypes.DirectSelection,
            inspectionCost : {
              id : '1',
              title : CostModelTitle.CostModel01,
              type: InspectionType.BuildingPest,   // enum value
              vendor: 1,         // vendor cost
              buyer: 1,         // buyer cost
              finalBuyer: 1     // final buyer cost
            },
            CostModelQualifyingQuestions: {
              vendorOrAgentWantCopy: true,
              freeReportAgentVendor: true,
              vendorPaysOneOff: true,
              buyerVendorSmallUpfront: true,
              vendorBuyerFreeFinalBuyerPays: true,
              vendorPaysReducedBuyerPaysReduced: true
            }
          }, 
          paymentMethod : {
            type: PaymentTypes.PayNow,
            vendor: {
              givenName: '',
              surname: '',
              email: '',
              mobilePhone: '',
              usedForDiscountVoucher: false
            }
          },
          poolDetails : {
            hasPool: false,
            requestComplianceCertificate: false
          },
          secondDwelling : {
            InspectSecondDwelling : false,
            NotInspectSecondDwelling : false,
            NoSecondDwelling : false
          },
          saleType : {
            saleType : SaleType.AuctionSale,
            auctionDate : undefined,
            agencyAgreementExpiry : undefined,            
            offMarket : false,
            eoiAgreementExpiryDate : undefined
          },
          openHouseAuction : {
            firstOpenHouseDateTime : '',
            auctionDateTime : new Date().toString(),
          },
          specialInstructions : {
            instructions : ''
          },
          termsAndConditions : {
            readWorkOrder : true,
            readResponsibility : true,
            readCompanyTermsAndConditions : true,
            readPreInspectionAgreement : true,
            ProceedingByAgreementTermsAndConditions : false,
            completeOrderNow : false,
            approvedByListingAgentEmail :'',
            approvalDateTime : new Date()
          },
          orderCompleted : {
            role:Roles.ListingAgent,
            approvedByEmail : '',
            approvalDateTime : new Date(),
            completeOrderNow : false
          }
        },
      ];

}


  ngAfterViewInit(): void {
    // Connect paginator and sort after view initialization
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  // Helper to format property address
  getAddress(b: BookingInspectionRequest): string {
    const a = b.propertyAddress;
    return `${a.houseNumber} ${a.streetName}, ${a.suburb} ${a.state} ${a.postCode}`;
  }

  // Helper to get vendor names
  getVendorName(b: BookingInspectionRequest): string {
    return b.vendor?.map(v => `${v.givenName} ${v.surname}`).join(', ') || '-';
  }
}
