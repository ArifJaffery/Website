import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-complete-order',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './complete-order.component.html',
  styleUrls: ['./complete-order.component.css']
})
export class CompleteOrderComponent implements OnInit {
@Input() completeOrderForm!: FormGroup;
  
  roleOptions = ['Listing Agent', 'Account Manager', 'Principal'];

  constructor(private fb: FormBuilder, private router: Router) {}

  ngOnInit(): void {
  }

  onSubmit(): void {
    // if (this.completeOrderForm.valid) {
      // Here you could call API to submit order data
    //   console.log('Order completed:', this.completeOrderForm.value);
      // Redirect to Payments page
    //   this.router.navigate(['/payments']);
    // } else {
    //   this.completeOrderForm.markAllAsTouched();
    // }
  }
}
