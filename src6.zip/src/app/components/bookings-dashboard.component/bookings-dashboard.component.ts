import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { BookingService } from '../../core/services/booking.service';
import { BookingInspectionRequest } from '../../core/models/bookingrequest.model';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatCardModule } from '@angular/material/card';
import { CostModelSelectionTypes } from '../../core/models/costmodal.model';
import { CostModelTitle, InspectionType } from '../../core/models/inspectioncost.model';
import { ContactType } from '../../core/models/contact.model';
import { PaymentTypes } from '../../core/models/paymentmethod.model';
import { SaleType } from '../../core/models/saletype.model';
import { Roles } from '../../core/models/completeorderform.model';
import { ApplicationService } from '../../core/services/Application.service';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-bookings-dashboard',
  standalone: true,
  imports: [
    MatCardModule,
    MatProgressSpinnerModule,
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatChipsModule,    
  MatCardModule,
  MatProgressSpinnerModule,
  CommonModule,
  MatTableModule,
  MatPaginatorModule,
  MatSortModule,
  MatChipsModule,
  MatButtonModule   
  ],
  templateUrl: './bookings-dashboard.component.html',
  styleUrls: ['./bookings-dashboard.component.scss']
})
export class BookingsDashboardComponent implements OnInit, AfterViewInit {

  displayedColumns: string[] = [
    'address',
    'inspectionType',
    'costModel',
    'date',
    'time',
    'vendor'
  ];

  dataSource = new MatTableDataSource<BookingInspectionRequest>();
  loading = true;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private bookingService: BookingService,private applicationService: ApplicationService) {}
  
  ngOnInit(): void {
    this.bookingService.bookings$.subscribe(bookings => {      
        if (bookings) {
            this.dataSource.data = bookings;
      }       
    });
    this.loading = false;
}

onRowClick(row: any) {
  // console.log('Row clicked:', row);  
  const current = this.applicationService.getUser();
  this.applicationService.updateState({
    ...current,
    enableBookingsDashboard: false,
    enablePropertyReportSelector: false,
    enableBookingRequest: true,
    enableLogin: false,
    enableRegistration: false
  });

  //this.selectedRow = row;
  this.bookingService.selectBooking(row);  // ← pushes to service, shows form
}


  ngAfterViewInit(): void {
    // Connect paginator and sort after view initialization
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  // Helper to format property address
  getAddress(b: BookingInspectionRequest): string {
    const a = b.propertyAddress;
    return `${a.houseNumber} ${a.streetName}, ${a.suburb} ${a.state} ${a.postCode}`;
  }

  // Helper to get vendor names
  getVendorName(b: BookingInspectionRequest): string {
    return b.vendor?.map(v => `${v.givenName} ${v.surname}`).join(', ') || '-';
  }

  createBooking() {
    const current = this.applicationService.getUser();
    if (!current) return; // or set default
    this.applicationService.updateState({
        ...current,
        enableBookingsDashboard: false,
        enablePropertyReportSelector: false,
        enableBookingRequest: true,
        enableLogin: false,
        enableRegistration: false
    });
  }

}
