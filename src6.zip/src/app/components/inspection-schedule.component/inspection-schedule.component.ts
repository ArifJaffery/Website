// import { Component, Input, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-inspection-schedule',
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './inspection-schedule.component.html',
//   styleUrls: ['./inspection-schedule.component.css']
// })
// export class InspectionScheduleComponent implements OnInit {
//   @Input() formGroup!: FormGroup;

//   constructor(private fb: FormBuilder) {}

//   ngOnInit(): void {
//     // Add form controls for inspection date and time
//     this.formGroup.addControl('inspectionDate', this.fb.control(''));
//     this.formGroup.addControl('inspectionTime', this.fb.control(''));
//   }
// }
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-inspection-schedule',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './inspection-schedule.component.html',
  styleUrls: ['./inspection-schedule.component.css']
})
export class InspectionScheduleComponent implements OnInit {
  /** Parent form passed from BookingComponent */
  @Input() parentForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  // ngOnInit(): void { 
  //   if (!this.parentForm) {
  //     console.warn('InspectionScheduleComponent: parentForm is not provided!');
  //     return;
  //   }
  //   const iso = this.parentForm.get('inspectionDate')?.value  ;
  //   const dt = new Date(iso); 
    
  //   const formattedDate = dt.toISOString().split('T')[0];
  //   this.parentForm.patchValue({
  //     inspectionDate: formattedDate
  //   });

  //   const time = new Date(this.parentForm.get('inspectionTime')?.value);
  //   this.parentForm.patchValue({
  //     inspectionTime: time && !isNaN(time.getTime())
  //       ? `${String(time.getHours()).padStart(2,'0')}:${String(time.getMinutes()).padStart(2,'0')}`
  //         : null
  //   });    
  // }


ngOnInit(): void { 
  if (!this.parentForm) {
    console.warn('InspectionScheduleComponent: parentForm is not provided!');
    return;
  }

  // === Date ===
  const iso = this.parentForm.get('inspectionDate')?.value;
  if (iso) {
    const dt = new Date(iso);
    if (!isNaN(dt.getTime())) {
      const formattedDate = dt.toISOString().split('T')[0];
      this.parentForm.patchValue({ inspectionDate: formattedDate });
    } else {
      console.warn('InspectionScheduleComponent: Invalid inspectionDate value', iso);
    }
  }

  // === Time ===
  const timeStr = this.parentForm.get('inspectionTime')?.value;
  if (timeStr) {
    const [hours, minutes] = timeStr.split(':').map(Number);
    if (!isNaN(hours) && !isNaN(minutes)) {
      const formattedTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
      this.parentForm.patchValue({ inspectionTime: formattedTime });
    } else {
      console.warn('InspectionScheduleComponent: Invalid inspectionTime value', timeStr);
      this.parentForm.patchValue({ inspectionTime: null });
    }
  } else {
    this.parentForm.patchValue({ inspectionTime: null });
  }
}
}
