import { Routes } from '@angular/router';
import { LoginComponent} from './components/login.component/login.component';
import { HeroSectionComponent } from './components/hero-section.component/hero-section.component';
import { BookingComponent } from './components/booking.component/booking.component';
import { authGuard } from './core/services/auth.guard';


export const routes: Routes = [
  { path : 'login', component: LoginComponent },
   { path : '', component: HeroSectionComponent },
   { path : 'booking', component: BookingComponent,  canActivate: [authGuard]}
//   { path: 'about', component: AboutComponent },
//   { path: '', redirectTo: '/home', pathMatch: 'full' }
];
