// blank-booking.factory.ts

import { BookingInspectionRequest } from '../../core/models/bookingrequest.model';
import { ContactType } from '../../core/models/contact.model';
import { CostModelSelectionTypes } from '../../core/models/costmodal.model';
import { CostModelTitle, InspectionType } from '../../core/models/inspectioncost.model';
import { PaymentTypes } from '../../core/models/paymentmethod.model';
import { SaleType } from '../../core/models/saletype.model';
import { Roles } from '../../core/models/completeorderform.model';



// booking-form.factory.ts

import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { createCompleteOrderForm, createContactGroup, createCostModelForm, createInspectionScheduleGroup, createOpenHouseAuctionDatesForm, 
    createPaymentMethodForm, createPoolDetailsForm, createPropertyAccessGroup, createPropertyAddressGroup, createSecondDwellingForm, 
    createSpecialInstructionsForm, createTPITermsAndConditionsForm, createTypeOfSaleForm } from './create-form-group';
// import {
//   createPropertyAddressGroup,
//   createInspectionScheduleGroup,
//   createPropertyAccessGroup,
//   createCostModelForm,
//   createPaymentMethodForm,
//   createPoolDetailsForm,
//   createSecondDwellingForm,
//   createTypeOfSaleForm,
//   createOpenHouseAuctionDatesForm,
//   createSpecialInstructionsForm,
//   createTPITermsAndConditionsForm,
//   createCompleteOrderForm
// } from '../other-form-helpers'; 

// you can create similar helper functions

export function createBookingForm(fb: FormBuilder, booking?: BookingInspectionRequest): FormGroup {
  const b = booking ?? createBlankBooking(); // Use provided booking or blank

  return fb.group({
    bookingId: new FormControl(b.bookingId),
    contacts: fb.array(
      b.contacts.map(c =>
        createContactGroup(
          c.contactType,
          c.showNotificationParty,
          c.showRemoveButton,
          c.showVoucher
        )
      )
    ),
    vendor: fb.array(
      b.vendor.map(c =>
        createContactGroup(
          c.contactType,
          c.showNotificationParty,
          c.showRemoveButton,
          c.showVoucher
        )
      )
    ),
    propertyAddress: createPropertyAddressGroup(b.propertyAddress),
    inspectionSchedule: createInspectionScheduleGroup(b.inspectionSchedule),
    propertyAccess: createPropertyAccessGroup(b.propertyAccess),
    costModel: createCostModelForm(fb, b.costModel),
    paymentMethod: createPaymentMethodForm(fb, b.paymentMethod),
    poolDetails: createPoolDetailsForm(fb, b.poolDetails),
    secondDwelling: createSecondDwellingForm(fb, b.secondDwelling),
    saleType: createTypeOfSaleForm(fb, b.saleType),
    openHouseAuction: createOpenHouseAuctionDatesForm(fb, b.openHouseAuction),
    specialInstructions: createSpecialInstructionsForm(fb, b.specialInstructions),
    termsAndConditions: createTPITermsAndConditionsForm(fb, b.termsAndConditions),
    orderCompleted: createCompleteOrderForm(fb, b.orderCompleted)
  });
}



export function createBlankBooking(): BookingInspectionRequest {
  return {

    bookingId: '',

    // ── Section 1: Contacts ──────────────────────────────
    contacts: [
      {
        givenName:             '',
        surname:               '',
        email:                 '',
        mobilePhone:           '',
        contactType:           ContactType.ListingAgent,
        notifyParty:           false,
        showNotificationParty: false,
        showRemoveButton:      false,
        showVoucher:           false,
      },
      {
        givenName:             '',
        surname:               '',
        email:                 '',
        mobilePhone:           '',
        contactType:           ContactType.CoListingAgent,
        notifyParty:           false,
        showNotificationParty: false,
        showRemoveButton:      false,
        showVoucher:           false,
      },
      {
        givenName:             '',
        surname:               '',
        email:                 '',
        mobilePhone:           '',
        contactType:           ContactType.AdministrationTeam,
        notifyParty:           false,
        showNotificationParty: false,
        showRemoveButton:      false,
        showVoucher:           false,
      },
    ],

    // ── Section 2: Vendor ────────────────────────────────
    vendor: [
      {
        givenName:             '',
        surname:               '',
        email:                 '',
        mobilePhone:           '',
        contactType:           ContactType.Husband,
        notifyParty:           false,
        showNotificationParty: false,
        showRemoveButton:      false,
        showVoucher:           false,
      },
      {
        givenName:             '',
        surname:               '',
        email:                 '',
        mobilePhone:           '',
        contactType:           ContactType.Wife,
        notifyParty:           false,
        showNotificationParty: false,
        showRemoveButton:      false,
        showVoucher:           false,
      },
    ],

    // ── Section 3: Property Address ──────────────────────
    propertyAddress: {
      houseNumber: '',
      streetName:  '',
      suburb:      '',
      state:       '',
      postCode:    '',
    },

    // ── Section 4: Inspection Schedule ──────────────────
    inspectionSchedule: {
      inspectionDate: '',
      inspectionTime: '',
    },

    // ── Section 5: Property Access ───────────────────────
    propertyAccess: {
      type:  'Vendor',
      name:  '',
      phone: '',
      email: '',
    },

    // ── Section 6: Cost Model ────────────────────────────
    costModel: {
      type: CostModelSelectionTypes.DirectSelection,
      inspectionCost: {
        id:         '',
        title:      CostModelTitle.CostModel01,
        type:       InspectionType.BuildingPest,
        vendor:     0,
        buyer:      0,
        finalBuyer: 0,
      },
      CostModelQualifyingQuestions: {
        vendorOrAgentWantCopy:            false,
        freeReportAgentVendor:            false,
        vendorPaysOneOff:                 false,
        buyerVendorSmallUpfront:          false,
        vendorBuyerFreeFinalBuyerPays:    false,
        vendorPaysReducedBuyerPaysReduced:false,
      },
    },

    // ── Section 7: Payment Method ────────────────────────
    paymentMethod: {
      type: PaymentTypes.PayNow,
      vendor: {
        givenName:            '',
        surname:              '',
        email:                '',
        mobilePhone:          '',
        usedForDiscountVoucher: false,
      },
    },

    // ── Section 8: Pool Details ──────────────────────────
    poolDetails: {
      hasPool:                      false,
      requestComplianceCertificate: false,
    },

    // ── Section 9: Second Dwelling ───────────────────────
    secondDwelling: {
      InspectSecondDwelling:    false,
      NotInspectSecondDwelling: false,
      NoSecondDwelling:         false,
    },

    // ── Section 10: Sale Type ────────────────────────────
    saleType: {
      saleType:                SaleType.OffMarket,
      auctionDate:             undefined,
      agencyAgreementExpiry:   undefined,
      eoiAgreementExpiryDate:  undefined,
      offMarket:               false,
    },

    // ── Section 11: Open House / Auction ─────────────────
    openHouseAuction: {
      firstOpenHouseDateTime: undefined,
      auctionDateTime:        undefined,
    },

    // ── Section 12: Special Instructions ─────────────────
    specialInstructions: {
      instructions: '',
    },

    // ── Section 13: Terms and Conditions ─────────────────
    termsAndConditions: {
      readWorkOrder:                          false,
      readResponsibility:                     false,
      readCompanyTermsAndConditions:          false,
      readPreInspectionAgreement:             false,
      ProceedingByAgreementTermsAndConditions:false,
      completeOrderNow:                       false,
      approvedByListingAgentEmail:            '',
      approvalDateTime:                       new Date(),
    },

    // ── Section 16: Order Completed ──────────────────────
    orderCompleted: {
      role:             Roles.ListingAgent,
      approvedByEmail:  '',
      approvalDateTime: new Date(),
      completeOrderNow: false,
    },

  };
}