import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Contact, ContactType } from '../../core/models/contact.model'; // adjust path
import { PropertyAddress } from '../../core/models/propertyaddress.model';
import { InspectionSchedule } from '../../core/models/inspectionschedule.model';
import { getPropertyAccess, PropertyAccessOption } from '../../core/models/propertyaccess.model';
import { CostModel, CostModelSelectionTypes } from '../../core/models/costmodal.model';
import { PaymentMethod } from '../../core/models/paymentmethod.model';
import { PoolDetails } from '../../core/models/pooldetails.model';
import { SecondDwelling } from '../../core/models/seconddwelling.model';
import { TypeOfSale } from '../../core/models/saletype.model';
import { OpenHouseAuction } from '../../core/models/openhouseauction.model';
import { SpecialInstructions } from '../../core/models/specialinstruction.model';
import { TPITermsAndConditions } from '../../core/models/termsandconditions.model';
import { CompleteOrderForm } from '../../core/models/completeorderform.model';

export const createContactGroup = (
  contactType: ContactType,
  showNotificationParty: boolean,
  showRemoveButton: boolean,
  showVoucher: boolean
): FormGroup<{
  givenName: FormControl<Contact['givenName']>;
  surname: FormControl<Contact['surname']>;
  email: FormControl<Contact['email']>;
  mobilePhone: FormControl<Contact['mobilePhone']>;
  contactType: FormControl<Contact['contactType']>;
  notifyParty: FormControl<Contact['notifyParty']>;
  showNotificationParty: FormControl<Contact['showNotificationParty']>;
  showRemoveButton: FormControl<Contact['showRemoveButton']>;
  showVoucher: FormControl<Contact['showVoucher']>;
}> => {

  return new FormGroup({
    givenName: new FormControl('', { nonNullable: true, validators: Validators.required }),
    surname: new FormControl('', { nonNullable: true, validators: Validators.required }),
    email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email] }),
    mobilePhone: new FormControl('', { nonNullable: true, validators: Validators.required }),
    contactType: new FormControl(contactType, { nonNullable: true }),
    notifyParty: new FormControl(true, { nonNullable: true }),
    showNotificationParty: new FormControl(showNotificationParty, { nonNullable: true }),
    showRemoveButton: new FormControl(showRemoveButton, { nonNullable: true }),
    showVoucher: new FormControl(showVoucher, { nonNullable: true })
  });
};

// export interface PropertyAddress {
//   houseNumber: string;
//   streetName: string;
//   suburb: string;
//   postCode: string;
//   state: string;
// }

export const createPropertyAddressGroup = (propertyAddress: PropertyAddress): FormGroup<{
    houseNumber: FormControl<PropertyAddress['houseNumber']>;
    streetName: FormControl<PropertyAddress['streetName']>;
    suburb: FormControl<PropertyAddress['suburb']>;
    postCode: FormControl<PropertyAddress['postCode']>;
    state: FormControl<PropertyAddress['state']>;
  }> => {
    return new FormGroup({
      houseNumber: new FormControl(propertyAddress.houseNumber ?? '', {
        nonNullable: true,
        validators: Validators.required
      }),
      streetName: new FormControl(propertyAddress.streetName ?? '', {
        nonNullable: true,
        validators: Validators.required
      }),
      suburb: new FormControl(propertyAddress.suburb ??     '', {
        nonNullable: true,
        validators: Validators.required
      }),
      postCode: new FormControl(propertyAddress.postCode ?? '', {
        nonNullable: true,
        validators: [Validators.required, Validators.pattern('^[0-9]{4}$')]
      }),
      state: new FormControl(propertyAddress.state ?? '', {
        nonNullable: true,
        validators: Validators.required
      })
    });
  }

function safeFormatDate(value: any): string | null {
  if (!value) return null;

  const d = new Date(value);

  if (isNaN(d.getTime())) {
    console.warn('Invalid date:', value);
    return null;
  }

  return d.toISOString().split('T')[0];
}  

export const createInspectionScheduleGroup = (inspectionSchedule: InspectionSchedule): FormGroup<{
    inspectionDate: FormControl<InspectionSchedule['inspectionDate']>;
    inspectionTime: FormControl<InspectionSchedule['inspectionTime']>;
  }> => {

        const date = new Date(inspectionSchedule.inspectionDate ?? '');
        const time = new Date(inspectionSchedule.inspectionTime ?? '');        

        // ✅ format for <input type="date">
        console.log(`Formatted inspection date: ${safeFormatDate(inspectionSchedule.inspectionDate)}`);

        // ✅ format for <input type="time">
        //const formattedTime = time.toTimeString().slice(0, 5);

    return new FormGroup({
      inspectionDate: new FormControl(inspectionSchedule.inspectionDate ?? '', {
        nonNullable: true,
        validators: Validators.required
      }),
      inspectionTime: new FormControl(inspectionSchedule.inspectionTime ??  '', {
        nonNullable: true,
        validators: [
          Validators.required,
          Validators.pattern('^([01]\\d|2[0-3]):([0-5]\\d)$') // HH:MM 24-hour format
        ]
      })
    });
  }
  
export const createPropertyAccessGroup = (
    data: any
  ): FormGroup => {

    console.log('Creating Property Access FormGroup with data:', data);
    
    if (!data || !data.type) {
      throw new Error("Invalid property access data");
    }

    switch (data.type) {
      case 'Vendor':
        return new FormGroup({
          type: new FormControl('Vendor' as const, { nonNullable: true }),
          name: new FormControl(data.name ?? '', { nonNullable: true, validators: Validators.required }),
          phone: new FormControl(data.phone ?? '', { nonNullable: true, validators: Validators.required }),
          email: new FormControl(data.email ?? '', { nonNullable: true, validators: [Validators.required, Validators.email] })
        });

      case 'Agent':
        return new FormGroup({
          type: new FormControl('Agent' as const, { nonNullable: true }),
          name: new FormControl(data.name ?? '', { nonNullable: true, validators: Validators.required }),
          mobilePhone: new FormControl(data.mobilePhone ?? '', { nonNullable: true, validators: Validators.required }),
          email: new FormControl(data.email ?? '', { nonNullable: true, validators: [Validators.required, Validators.email] })
        });

      case 'Tenant':
        return new FormGroup({
          type: new FormControl('Tenant' as const, { nonNullable: true }),
          name: new FormControl(data.name ?? '', { nonNullable: true, validators: Validators.required }),
          phone: new FormControl(data.phone ?? '', { nonNullable: true, validators: Validators.required }),
          email: new FormControl(data.email ?? '', { nonNullable: true, validators: [Validators.required, Validators.email] })
        });

      case 'LockBox':
        return new FormGroup({
          type: new FormControl('LockBox' as const, { nonNullable: true }),
          locationDescription: new FormControl(data.locationDescription ?? '', { nonNullable: true, validators: Validators.required }),
          phone: new FormControl('', { nonNullable: true, validators: Validators.required })
        });

      case 'KeyOnSite':
        return new FormGroup({
          type: new FormControl('KeyOnSite' as const, { nonNullable: true }),
          locationDescription: new FormControl(data.locationDescription ?? '', { nonNullable: true, validators: Validators.required })
        });

      case 'PickupFromAgentOffice':
        return new FormGroup({
          type: new FormControl('PickupFromAgentOffice' as const, { nonNullable: true }),
          pickupAddress: new FormControl(data.pickupAddress ?? '', { nonNullable: true, validators: Validators.required }),
          dropoffAddress: new FormControl(data.dropoffAddress ?? '', { nonNullable: true, validators: Validators.required }),
          serviceCharge: new FormControl(35) // default $35 if not provided
        });

      default:
        throw new Error('Unknown access type');
    }
  }

export const createCostModelForm = (fb: FormBuilder, costModel?: CostModel): FormGroup => {
  return fb.group({
    type: new FormControl(costModel?.type || CostModelSelectionTypes.DirectSelection),

    inspectionCost: fb.group({
      id: new FormControl(costModel?.inspectionCost?.id || ''),
      type: new FormControl(costModel?.inspectionCost?.type || null),
      vendor: new FormControl(costModel?.inspectionCost?.vendor || 0),
      buyer: new FormControl(costModel?.inspectionCost?.buyer || 0),
      finalBuyer: new FormControl(costModel?.inspectionCost?.finalBuyer || 0),
      title: new FormControl(costModel?.inspectionCost?.title || '')
    }),

    // Optional Qualifying Questions
    CostModelQualifyingQuestions: fb.group({      
      vendorOrAgentWantCopy: new FormControl(costModel?.CostModelQualifyingQuestions?.vendorOrAgentWantCopy || false),
      freeReportAgentVendor: new FormControl(costModel?.CostModelQualifyingQuestions?.freeReportAgentVendor || false),
      vendorPaysOneOff: new FormControl(costModel?.CostModelQualifyingQuestions?.vendorPaysOneOff || false),
      buyerVendorSmallUpfront: new FormControl(costModel?.CostModelQualifyingQuestions?.buyerVendorSmallUpfront || false),
      vendorBuyerFreeFinalBuyerPays: new FormControl(costModel?.CostModelQualifyingQuestions?.vendorBuyerFreeFinalBuyerPays || false),
      vendorPaysReducedBuyerPaysReduced: new FormControl(costModel?.CostModelQualifyingQuestions?.vendorPaysReducedBuyerPaysReduced || false),
    })
  });
}


export const createPaymentMethodForm = (fb: FormBuilder, payment?: PaymentMethod): FormGroup =>     {
    const type = payment?.type ?? null;

    // Vendor form group (only relevant for VendorDirect)
    const vendorGroup = fb.group({
      givenName: [payment?.vendor?.givenName ?? ''],
      surname: [payment?.vendor?.surname ?? ''],
      email: [payment?.vendor?.email ?? ''],
      mobilePhone: [payment?.vendor?.mobilePhone ?? ''],
      usedForDiscountVoucher: [payment?.vendor?.usedForDiscountVoucher ?? false]
    });

    return fb.group({
      type: [type],
      vendor:  vendorGroup 
    });
  }

 export const createPoolDetailsForm = (fb: FormBuilder, poolDetails?: PoolDetails ): FormGroup => {
      return fb.group({
        hasPool: [poolDetails?.hasPool ?? false],

        requestComplianceCertificate: [
          poolDetails?.requestComplianceCertificate ?? false
        ]
      });
  }

 export const createSecondDwellingForm = (fb: FormBuilder, data?: SecondDwelling): FormGroup =>  {

    const form = fb.group({
      InspectSecondDwelling: [data?.InspectSecondDwelling ?? false],
      NotInspectSecondDwelling: [data?.NotInspectSecondDwelling ?? false],
      NoSecondDwelling: [data?.NoSecondDwelling ?? false],
    });

    Object.keys(form.controls).forEach(key => {
      form.get(key)?.valueChanges.subscribe(value => {
        if (value) {
          Object.keys(form.controls).forEach(otherKey => {
            if (otherKey !== key) {
              form.get(otherKey)?.setValue(false, { emitEvent: false });
            }
          });
        }
      });
    });
    return form;
  }


  export const createTypeOfSaleForm = (fb: FormBuilder, data?: TypeOfSale): FormGroup => {
    return fb.group({
      saleType: [data?.saleType ?? null],                  // required
      auctionDate: [data?.auctionDate ?? null],           // optional
      agencyAgreementExpiry: [data?.agencyAgreementExpiry ?? null], // optional
      eoiAgreementExpiryDate: [data?.eoiAgreementExpiryDate ?? null], // optional
      offMarket: [data?.offMarket ?? false]               // optional boolean, default false
    });
  }

  export const createOpenHouseAuctionDatesForm = (fb: FormBuilder, data?: OpenHouseAuction): FormGroup =>    {
    return fb.group({
      firstOpenHouseDateTime: [data?.firstOpenHouseDateTime ?? null],
      auctionDateTime: [data?.auctionDateTime ?? null]
    });
  }

export const createSpecialInstructionsForm = (fb: FormBuilder, data?: SpecialInstructions): FormGroup =>     {
    return fb.group({
      instructions: [data?.instructions ?? '', Validators.required]
    });
  }

export const createTPITermsAndConditionsForm = (fb: FormBuilder, data?: TPITermsAndConditions): FormGroup => {
    return fb.group({
      readWorkOrder: [data?.readWorkOrder ?? false],
      readResponsibility: [data?.readResponsibility ?? false],
      readCompanyTermsAndConditions: [data?.readCompanyTermsAndConditions ?? false],
      readPreInspectionAgreement: [data?.readPreInspectionAgreement ?? false],
      ProceedingByAgreementTermsAndConditions: [
        data?.ProceedingByAgreementTermsAndConditions ?? false
      ],
      completeOrderNow: [data?.completeOrderNow ?? false],

      approvedByListingAgentEmail: [
        data?.approvedByListingAgentEmail ?? '',
        [Validators.email]
      ],

      approvalDateTime: [data?.approvalDateTime ?? null]
    });
  }

export const createCompleteOrderForm = (fb: FormBuilder, data?: Partial<CompleteOrderForm>   // optional initial values
  ): FormGroup =>   {
    return fb.group({
      role: [data?.role ?? '', Validators.required],
      approvedByEmail: [data?.approvedByEmail ?? '', [Validators.required, Validators.email]],
      approvalDateTime: [data?.approvalDateTime ?? new Date(), Validators.required],
      completeOrderNow: [data?.completeOrderNow ?? false, Validators.requiredTrue]
    });
  }
