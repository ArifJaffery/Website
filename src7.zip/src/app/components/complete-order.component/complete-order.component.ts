import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-complete-order',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './complete-order.component.html',
  styleUrls: ['./complete-order.component.css']
})
export class CompleteOrderComponent implements OnInit {
@Input() completeOrderForm!: FormGroup;
@Output() submitOrder = new EventEmitter<void>();
  
  roleOptions = ['Listing Agent', 'Account Manager', 'Principal'];

  constructor(private fb: FormBuilder, private router: Router) {}

  ngOnInit(): void {
  }

  onSubmit(): void {
    console.log('CompleteOrderComponent: onSubmit called with form value:\n'); 
    this.submitOrder.emit();
  }
}
