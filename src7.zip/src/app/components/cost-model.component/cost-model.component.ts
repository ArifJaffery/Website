import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { PriceListComponent } from '../../components/price-list.component/price-list.component';

@Component({
  selector: 'app-cost-model',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule,PriceListComponent],
  templateUrl: './cost-model.component.html',
  styleUrls: ['./cost-model.component.css']
})
export class CostModelComponent implements OnInit {
  @Input() parentForm!: FormGroup; // ✅ updated to parentForm   
   
  checkedQuestions: string[] = [];

  constructor(private fb: FormBuilder) {}

  get qualifyingQuestionsForm(): FormGroup {
    const group = this.parentForm.get('CostModelQualifyingQuestions');
    if (!group) {
      // Optional: throw error if group is missing, for debugging
      throw new Error('CostModelQualifyingQuestions FormGroup is missing!');
    }
    return group as FormGroup;
  }

 get getFormGroupCostModel(): FormGroup {
    const group = this.parentForm.get('inspectionCost');    
    if (!group) {      
      throw new Error('inspectionCost FormGroup is missing!');
    }
    return group as FormGroup;
  }

  get getFormGroup(): FormGroup {
    const group = this.parentForm;    
    if (!group) {      
      throw new Error('inspectionCost FormGroup is missing!');
    }
    return group as FormGroup;
  }

  modelNumberOptions = [
    { value: 1, label: '1 - Vendor & Buyers Pays (One-off Payment)' },
    { value: 2, label: '2 - Vendor & Buyers Pays (Vendor Full Freight)' },
    { value: 3, label: '3 - Vendor & Buyers Pays ($50)' },
    { value: 4, label: '4 - Vendor & Buyers Pays ($30)' },
    { value: 5, label: '5 - Vendor & Buyers Pays ($100)' },
    { value: 6, label: '6 - Vendor & Buyers Pays ($150 / $80)' },
    { value: 7, label: '7 - Vendor Only (Option For Buyers To Purchase)' },
    { value: 8, label: '8 - Vendor Only (Vendor & Buyer Reliant)' },
    { value: 9, label: '9 - Vendor Only Pays (Large Estate or Outer Sydney orders)' },
    { value: 10, label: '10 - Buyers Only Pay ($49)' },
    { value: 11, label: '11 - Buyers Only Pay ($99)' },
    { value: 12, label: '12 - Buyers Only Pay ($149)' },
    { value: 13, label: '13 - Buyers Only Pay ($299 / $199)' },
    { value: 14, label: '14 - TPI Special' },
  ]; 

  ngOnInit(): void {
    // console.log('Booking Form Value:\n', JSON.stringify(this.parentForm.value, null, 2));
    if (!this.parentForm) {
      console.warn('CostModelComponent: parentForm is not provided!');      
      return;
    }
  } 
}
