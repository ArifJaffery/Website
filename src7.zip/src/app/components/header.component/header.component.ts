import { Component, EventEmitter, Output } from '@angular/core';
import { UserService } from '../../core/services/user.service';
import { Observable } from 'rxjs';
import { User } from '../../core/models/user.model';
import { CommonModule } from '@angular/common'; // <-- required for async pipe
import { RouterModule } from '@angular/router';  
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  // @Output() registerClicked = new EventEmitter<void>();
  // @Output() loginClicked = new EventEmitter<void>();  

  
 user$: Observable<User | null>;

 constructor(private userService: UserService,private router: Router) {
   this.user$ = this.userService.user$;
 }


  onRegisterClick() {
    // this.registerClicked.emit();
  }

  onLoginClick (){
    // this.loginClicked.emit();
  }

  onLogoutClick(){
    this.userService.clearUser();
    this.router.navigate(['/']);
  }

}
