import { Component} from '@angular/core';
import { NgIf } from '@angular/common'; 
import { CtaSectionComponent } from '../cta-section.component/cta-section.component';
import { HeaderComponent } from '../header.component/header.component';
import { LoginComponent} from '../login.component/login.component';
import { PropertyReportSelectorComponent } from '../../components/property-report-selector.component/property-report-selector.component';
import { BookingComponent } from '../../components/booking.component/booking.component';
import { BookingsDashboardComponent } from '../bookings-dashboard.component/bookings-dashboard.component';
import { ApplicationService } from '../../core/services/application.service';

@Component({
  selector: 'app-hero-section',
  standalone: true,
  templateUrl: './hero-section.component.html',
  styleUrls: ['./hero-section.component.css'],
  imports: [NgIf, CtaSectionComponent, HeaderComponent, LoginComponent, PropertyReportSelectorComponent, BookingComponent,BookingsDashboardComponent]
})
export class HeroSectionComponent {  

  // showRegistration = false;
  // showLogin = false;
  // showBookingRequest = false;
  // showBookingsDashboard = false;

  selectedReportType: string = '';

  constructor(public applicationService: ApplicationService ) {

  }

  toggleReportType(type: string) {
    //console.log('Selected report type:', type);
    this.selectedReportType = type;
    // highlight active button
    document.querySelectorAll('.togglebtn').forEach(btn => btn.classList.remove('active'));
    const activeBtn = Array.from(document.querySelectorAll('.togglebtn'))
                          .find(btn => btn.textContent?.includes(type));
    activeBtn?.classList.add('active');    
  }

  update() {
    //console.log('Address input updated');
  }


  // enableBookingsDashboard: true,
  // enablePropertyReportSelector: true,
  // enableBookingRequest: true,
  // enableLogin: true,
  // enableRegistration: true


  createBooking() {
    const current = this.applicationService.getUser();
    if (!current) return; // or set default
    this.applicationService.updateState({
        ...current,
        enableBookingsDashboard: false,
        enablePropertyReportSelector: false,
        enableBookingRequest: true,
        enableLogin: false,
        enableRegistration: false
    });
  }
  
  onRegisterClick() {
    console.log('Register button clicked');    
    //this.showRegistration = !this.showRegistration;
  } 
  onLoginClick() 
  {
    console.log('Login button clicked');
    const current = this.applicationService.getUser();
//    this.showLogin = !this.showLogin;
    this.applicationService.updateState({
        ...current,
        enableBookingsDashboard: false,
        enablePropertyReportSelector: true,
        enableBookingRequest: false,
        enableLogin: false,
        enableRegistration: false
    });
  }

  onCodeSent(email: string) {
    console.log('Code sent from CTA section:', email);    
  }

  onVerified() {
    console.log('Verification completed!');    
  }

  loginSuccess(emailL:any) {
    console.log('Login successful from Login Component!');
    const current = this.applicationService.getUser();

    this.applicationService.updateState({
        ...current,
        enableBookingsDashboard: true,
    });


  }

  onPropertyReportSelected(event: { propertyType: string; reportType: string }) {
    console.log('Selected:', event.propertyType, event.reportType);
  }

}
