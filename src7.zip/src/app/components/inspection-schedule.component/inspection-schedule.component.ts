import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TimeGridComponent } from '../time-grid.component/time-grid.component';
import { AvailabilityService } from '../../core/services/availability.service';
import { Observable } from 'rxjs';
import { InspectorSchedule, DailySlot, AvailabilityResponse } from '../../core/models/appointment.model';

@Component({
  selector: 'app-inspection-schedule',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, TimeGridComponent],
  templateUrl: './inspection-schedule.component.html',
  styleUrls: ['./inspection-schedule.component.css']
})
export class InspectionScheduleComponent implements OnInit {
  @Input() parentForm!: FormGroup;

  availableSchedules$!: Observable<InspectorSchedule[]>;  // <-- Updated type
  loading$!: Observable<boolean>;
  selectedDate$!: Observable<string | null>;
  inspectorsSchedule: AvailabilityResponse | undefined = undefined;
  dates: string[] = [];

  existingInspectionDate: string | null = null;
  existingInspectionTime: string | null = null;
  currentWeekMonday!: Date;

  getWeekDates(inputDate: Date): string[] {
    const date = new Date(inputDate);
    
    const day = date.getDay();
    
    const diffToMonday = day === 0 ? -6 : 1 - day;

    const monday = new Date(date);
    monday.setDate(date.getDate() + diffToMonday);
    
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      return d.toISOString().split('T')[0]; 
    });
  }

  constructor(
    private fb: FormBuilder,
    private availabilityService: AvailabilityService
  ) {}


  getNextWeekDates(): string[] {
    const today = new Date();

    // Find this week's Monday
    const day = today.getDay(); // 0 = Sunday
    const diffToMonday = day === 0 ? -6 : 1 - day; 
    const thisMonday = new Date(today);
    thisMonday.setDate(today.getDate() + diffToMonday);

    // Add 7 days to get next week's Monday
    const nextMonday = new Date(thisMonday);
    nextMonday.setDate(thisMonday.getDate() + 7);

    // Generate 7-day range (Monday → Sunday)
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(nextMonday);
      d.setDate(nextMonday.getDate() + i);
      return d.toISOString().split('T')[0]; // YYYY-MM-DD format
    });
  }

updateWeek(monday: Date): void {
  this.currentWeekMonday = new Date(monday);   // store current week
  this.dates = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    return d.toISOString().split('T')[0];
  });

  // Fetch availability for the first day of the week
  this.availabilityService.fetchAvailableDates(this.dates[0]).subscribe({
    next: (response) => {
      this.inspectorsSchedule = response;
      console.log('Availability response:', response);
    },
    error: (err) => console.error('Error fetching availability:', err)
  });
}

goToNextWeek(): void {
  const nextMonday = new Date(this.currentWeekMonday);
  nextMonday.setDate(this.currentWeekMonday.getDate() + 7);
  this.updateWeek(nextMonday);
}

goToPreviousWeek(): void {
  const prevMonday = new Date(this.currentWeekMonday);
  prevMonday.setDate(this.currentWeekMonday.getDate() - 7);
  this.updateWeek(prevMonday);
}

ngOnInit(): void { 
  const iso = this.parentForm.get('inspectionDate')?.value;
  let initialDate = new Date();

  if (iso) {
    const dt = new Date(iso);
    if (!isNaN(dt.getTime())) {
      const formattedDate = dt.toISOString().split('T')[0];
      this.parentForm.patchValue({ inspectionDate: formattedDate });
      this.existingInspectionDate = formattedDate;
      initialDate = dt; // use this date to compute week
      console.log('Parsed inspectionDate', formattedDate);
    } else {
      console.warn('Invalid inspectionDate value', iso);
    }
  }

  // Initialize currentWeekMonday to **next week**
  const day = initialDate.getDay();
  const diffToMonday = day === 0 ? -6 : 1 - day;
  const thisMonday = new Date(initialDate);
  thisMonday.setDate(initialDate.getDate() + diffToMonday);

  const nextWeekMonday = new Date(thisMonday);
  nextWeekMonday.setDate(thisMonday.getDate() + 7);

  this.updateWeek(nextWeekMonday);

  // --- Existing inspectionTime parsing ---
  const timeStr = this.parentForm.get('inspectionTime')?.value;
  if (timeStr) {
    const [hours, minutes] = timeStr.split(':').map(Number);
    if (!isNaN(hours) && !isNaN(minutes)) {
      const formattedTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
      this.parentForm.patchValue({ inspectionTime: formattedTime });
      this.existingInspectionTime = formattedTime;
      console.log('Parsed inspectionTime', formattedTime);
    } else {
      console.warn('Invalid inspectionTime value', timeStr);
      this.parentForm.patchValue({ inspectionTime: null });
    }
  } else {
    this.parentForm.patchValue({ inspectionTime: null });
  }

  // Bind observables
  this.availableSchedules$ = this.availabilityService.availableDates$;
  this.loading$ = this.availabilityService.loading$;
  this.selectedDate$ = this.availabilityService.selectedDate$;
};

// ngOnInit(): void { 
  //   const iso = this.parentForm.get('inspectionDate')?.value;
  //   if (iso) {
  //     const dt = new Date(iso);
  //     if (!isNaN(dt.getTime())) {
  //       const formattedDate = dt.toISOString().split('T')[0];
  //       this.parentForm.patchValue({ inspectionDate: formattedDate });
  //       console.log('InspectionScheduleComponent: Parsed inspectionDate', formattedDate);
  //       this.dates = this.getWeekDates(dt);
  //       console.log('InspectionScheduleComponent: Computed week dates', this.dates);
  //       this.existingInspectionDate = formattedDate; // Store for later use
  //     } else {
  //       console.warn('InspectionScheduleComponent: Invalid inspectionDate value', iso);
  //     }
  //   }

  //   const timeStr = this.parentForm.get('inspectionTime')?.value;
  //   if (timeStr) {
  //     const [hours, minutes] = timeStr.split(':').map(Number);
  //     if (!isNaN(hours) && !isNaN(minutes)) {
  //       const formattedTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
  //       this.parentForm.patchValue({ inspectionTime: formattedTime });
  //       console.log('InspectionScheduleComponent: Parsed inspectionTime', formattedTime);
  //       this.existingInspectionTime = formattedTime; // Store for later use
  //     } else {
  //       console.warn('InspectionScheduleComponent: Invalid inspectionTime value', timeStr);
  //       this.parentForm.patchValue({ inspectionTime: null });
  //     }
  //   } else {
  //     this.parentForm.patchValue({ inspectionTime: null });
  //   }


  //   if (!this.parentForm) {
  //     console.warn('InspectionScheduleComponent: parentForm is not provided!');
  //     return;
  //   }

  //   // Bind observables
  //   this.availableSchedules$ = this.availabilityService.availableDates$;
  //   this.loading$ = this.availabilityService.loading$;
  //   this.selectedDate$ = this.availabilityService.selectedDate$;

  //   // Trigger API call (use inspectionDate from parentForm if exists)    
  //   const dateStr = iso ? new Date(iso).toISOString().split('T')[0] : new Date().toISOString().split('T')[0];

  //   this.availabilityService.fetchAvailableDates(dateStr).subscribe({
  //     next: (response) => {
  //       console.log('Response:', response);
  //       this.inspectorsSchedule = response; // Store the response for template use
  //     },
  //     error: (err) => {
  //       console.error('Error fetching availability:', err);
  //     }
  //   });
  // }

  onSelectDate(date: string): void {
    this.availabilityService.selectDate(date);
    this.parentForm.patchValue({ inspectionDate: date });
  }

  onRefresh(): void {
    const iso = this.parentForm.get('inspectionDate')?.value;
    const dateStr = iso ? new Date(iso).toISOString().split('T')[0] : new Date().toISOString().split('T')[0];   

    this.availabilityService.fetchAvailableDates(dateStr).subscribe({
      next: (response) => {
        console.log('Response:', response);
      },
      error: (err) => {
        console.error('Error fetching availability:', err);
      }
    });
  }

  // Optional helper to extract slots for a given inspector and day
  getSlotsForDay(inspector: InspectorSchedule, day: string): string[] {
    const daily = inspector.schedule.find(d => d.day === day);
    return daily ? daily.slots : [];
  }
}

