import { Component, Input } from '@angular/core';
import { BusinessCostModel, businessCostModels } from '../../core/models/business-cost-model.model';
import { CommonModule } from '@angular/common';
import { FormGroup } from '@angular/forms';
import { CostModelQualifyingQuestions } from '../../core/models/costmodal.model';
import { InspectionCost } from '../../core/models/inspectioncost.model';

@Component({
  selector: 'app-price-list',  
   imports: [CommonModule],
  templateUrl: './price-list.component.html',
  styleUrls: ['./price-list.component.css']
})
export class PriceListComponent {
  @Input() costModelForm!: FormGroup; 
  @Input() qualifyingQuestionsFormGroup!: FormGroup;
  @Input() costModelOption!: string ;


  // Component class
  selectedRow: any;

  ngOnInit(): void {

    console.log('PriceListComponent initialized with costModelForm:', this.costModelForm?.get('inspectionCost')?.value );
    this.selectedRow = this.costModelForm?.get('inspectionCost')?.value ;
  }

  // ── Single access point for the nested group ──────────
  private get ic(): FormGroup {
    return this.costModelForm?.get('inspectionCost') as FormGroup;
  }

  // ── Getters all read from ic (inspectionCost) ─────────
  get selectedId(): string {
    return this.ic?.get('id')?.value ?? '';
  }

  get selectedTitle(): string {
    return this.ic?.get('title')?.value ?? '';
  }

  get selectedType(): string {
    return this.ic?.get('type')?.value ?? '';
  }

  get selectedVendorCost(): number | null {
    return this.ic?.get('vendor')?.value ?? null;
  }

  get selectedBuyerCost(): number | null {
    return this.ic?.get('buyer')?.value ?? null;
  }

  get selectedFinalBuyerCost(): number | null {
    return this.ic?.get('finalBuyer')?.value ?? null;
  }

  get hasSelection(): boolean {
    return !!this.selectedId;
  }

  
  // selectRow(row: any) {
  //   console.log(`row =>${JSON.stringify(row)}`);
  //   if (this.selectedRow === row) {
  //     this.selectedRow = null; 
  //   } else {
  //     this.selectedRow = row; 
  //   }
  //   this.patchFormFromPriceList(row);
  // }

  selectRow(row: InspectionCost): void {
    this.selectedRow = this.selectedRow === row ? null : row;
    console.log(`Selected row: ${JSON.stringify(this.selectedRow)}`);

    if (this.selectedRow) {
      this.patchFormFromPriceList(this.selectedRow);
    }
  }
  


  // private patchFormFromPriceList(inspectionCost: InspectionCost): void {
  //   console.log('Patching form with Business Cost Model:', inspectionCost); 
  //   Promise.resolve().then(() => {
  //     this.costModelForm.patchValue(
  //       {
  //         buyer : inspectionCost.buyer,
  //         vendor : inspectionCost.vendor,
  //         inspectionCost : inspectionCost.id,
  //         costModelId : inspectionCost.id,
  //         costModelTitle : inspectionCost.title,
  //         type : inspectionCost.type            
  //       },
  //       { emitEvent: false });
  //     console.log('Form patched with Business Cost Model:', this.costModelForm.value);
  //   });
  // }

    private patchFormFromPriceList(inspectionCost: InspectionCost): void {
      console.log('Patching form with Business Cost Model:', inspectionCost); 

      const formGroup = this.costModelForm?.get('inspectionCost') as FormGroup; 
      formGroup.patchValue({
        buyer: inspectionCost?.buyer ?? null,
        vendor: inspectionCost?.vendor ?? null,
        inspectionCost: inspectionCost?.id ?? null,        
        id: inspectionCost?.id ?? null,
        costModelTitle: inspectionCost?.title ?? null,
        type: inspectionCost?.type ?? null
      });

      console.log('Form patched with Business Cost Model:', this.costModelForm.value);
    }



  priceList : BusinessCostModel[] = businessCostModels;  

  vendorAndBuyersOneOff: BusinessCostModel = businessCostModels[0];
  vendorAndBuyersOneOffBuildingPest = this.vendorAndBuyersOneOff.inspectionCost[0];
  vendorAndBuyersOneOffStrata = this.vendorAndBuyersOneOff.inspectionCost[1];

  vendorAndBuyersFullFreight: BusinessCostModel = businessCostModels[1];
  vendorAndBuyersFullFreightBuildingPest = this.vendorAndBuyersFullFreight.inspectionCost[0];
  vendorAndBuyersFullFreightStrata = this.vendorAndBuyersFullFreight.inspectionCost[1];

  
  // Vendor & Buyers Pays ($50)
  vendorAndBuyers50: BusinessCostModel = businessCostModels[2];
  vendorAndBuyers50BuildingPest = this.vendorAndBuyers50.inspectionCost[0];
  vendorAndBuyers50Strata = this.vendorAndBuyers50.inspectionCost[1];

  // Vendor & Buyers Pays ($30)
  vendorAndBuyers30: BusinessCostModel = businessCostModels[3];
  vendorAndBuyers30BuildingPest = this.vendorAndBuyers30.inspectionCost[0];
  vendorAndBuyers30Strata = this.vendorAndBuyers30.inspectionCost[1];

  // Vendor & Buyers Pays ($100)
  vendorAndBuyers100: BusinessCostModel = businessCostModels[4];
  vendorAndBuyers100BuildingPest = this.vendorAndBuyers100.inspectionCost[0];
  vendorAndBuyers100Strata = this.vendorAndBuyers100.inspectionCost[1];

  // Vendor & Buyers Pays ($150 / $80)
  vendorAndBuyers150_80: BusinessCostModel = businessCostModels[5];
  vendorAndBuyers150_80BuildingPest = this.vendorAndBuyers150_80.inspectionCost[0];
  vendorAndBuyers150_80Strata = this.vendorAndBuyers150_80.inspectionCost[1];

  // Vendor Only (Option For Buyers To Purchase)
  vendorOnlyOptionForBuyers: BusinessCostModel = businessCostModels[6];
  vendorOnlyOptionForBuyersBuildingPest = this.vendorOnlyOptionForBuyers.inspectionCost[0];
  vendorOnlyOptionForBuyersStrata = this.vendorOnlyOptionForBuyers.inspectionCost[1];

  // Vendor Only (Vendor & Buyer Reliant)
  vendorOnlyVendorBuyerReliant: BusinessCostModel = businessCostModels[7];
  vendorOnlyVendorBuyerReliantBuildingPest = this.vendorOnlyVendorBuyerReliant.inspectionCost[0];
  vendorOnlyVendorBuyerReliantStrata = this.vendorOnlyVendorBuyerReliant.inspectionCost[1];

  // Vendor Only Pays (Large Estate or Outer Sydney orders)
  vendorOnlyLargeEstate: BusinessCostModel = businessCostModels[8];
  vendorOnlyLargeEstateBuildingPest = this.vendorOnlyLargeEstate.inspectionCost[0];
  vendorOnlyLargeEstateStrata = this.vendorOnlyLargeEstate.inspectionCost[1];

  // Buyers Only Pay ($49)
  buyersOnly49: BusinessCostModel = businessCostModels[9];
  buyersOnly49BuildingPest = this.buyersOnly49.inspectionCost[0];
  buyersOnly49Strata = this.buyersOnly49.inspectionCost[1];

  // Buyers Only Pay ($99)
  buyersOnly99: BusinessCostModel = businessCostModels[10];
  buyersOnly99BuildingPest = this.buyersOnly99.inspectionCost[0];
  buyersOnly99Strata = this.buyersOnly99.inspectionCost[1];

  // Buyers Only Pay ($149)
  buyersOnly149: BusinessCostModel = businessCostModels[11];
  buyersOnly149BuildingPest = this.buyersOnly149.inspectionCost[0];
  buyersOnly149Strata = this.buyersOnly149.inspectionCost[1];

  // Buyers Only Pay ($299 / $199)
  buyersOnly299_199: BusinessCostModel = businessCostModels[12];
  buyersOnly299_199BuildingPest = this.buyersOnly299_199.inspectionCost[0];
  buyersOnly299_199Strata = this.buyersOnly299_199.inspectionCost[1];

  // TPI Special
  tPISpecial: BusinessCostModel = businessCostModels[13];
  tPISpecialBuildingPest = this.tPISpecial.inspectionCost[0];
  tPISpecialStrata = this.tPISpecial.inspectionCost[1];

  


  showCostModel (costModelId: any) {
    if (this.costModelOption === 'QualifyingQuestions' ){
        const { vendorOrAgentWantCopy,freeReportAgentVendor,vendorPaysOneOff, buyerVendorSmallUpfront,vendorBuyerFreeFinalBuyerPays,
          vendorPaysReducedBuyerPaysReduced } = this.qualifyingQuestionsFormGroup.value;

        if ( vendorOrAgentWantCopy && vendorOrAgentWantCopy === true && [1,2,3,7,8,9].includes(costModelId)){
          return true;
        } else if ( vendorOrAgentWantCopy && vendorOrAgentWantCopy === false && [4,5,6,10,11,12,13,14].includes(costModelId)){
          return false;
        } else if ( freeReportAgentVendor && freeReportAgentVendor === true && [10,11,12,13].includes(costModelId)){
          return true;
        } else if ( freeReportAgentVendor && freeReportAgentVendor === false && [1,2,3,4,5,6,8,9,14].includes(costModelId)){
          return false;          
        } else if (vendorPaysOneOff && vendorPaysOneOff === true &&  [7,8,9].includes(costModelId)){
          return true;
        } else if (vendorPaysOneOff && vendorPaysOneOff === false &&  [1,2,3,4,5,6,10,11,12,13].includes(costModelId)){          
            return false;
        } else if ( buyerVendorSmallUpfront && buyerVendorSmallUpfront === true && [3,4].includes(costModelId)){
          return true;
        } else if ( buyerVendorSmallUpfront && buyerVendorSmallUpfront === false && [1,2,5,6,7,8,9,10,11,12,13,14].includes(costModelId)){
          return false;          
        } else if ( vendorBuyerFreeFinalBuyerPays && vendorBuyerFreeFinalBuyerPays === true &&  [14].includes(costModelId)){
          return true;
        } else if ( vendorBuyerFreeFinalBuyerPays && vendorBuyerFreeFinalBuyerPays === false &&  [1,2,3,4,5,6,7,8,9,10,11,12,13].includes(costModelId)){
          return false;          
        } else if (vendorPaysReducedBuyerPaysReduced && vendorPaysReducedBuyerPaysReduced === true && [1,2,4,5,6].includes(costModelId)){
          return true;
        } else if (vendorPaysReducedBuyerPaysReduced && vendorPaysReducedBuyerPaysReduced === false && [3,7,8,9,10,11,12,13,14].includes(costModelId)){          
          return false;
        }
        return false;
    }
    return true;
  }

  showBlock(costModelId:any){

  }





  
}
