import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-time-box-header',
  templateUrl: './time-box-header.component.html',
  styleUrls: ['./time-box-header.component.scss'],
  imports : [DatePipe]
})
export class TimeBoxHeaderComponent implements OnInit, OnDestroy {
 @Input() date!: string | Date;
  
  private timerId!: number;

  ngOnInit(): void {    
    
  }

  ngOnDestroy(): void {    
  }

  private updateTime(): void {
    // const now = new Date();
    // this.time = now.toLocaleTimeString('en-US', {
    //   hour: '2-digit',
    //   minute: '2-digit',
    //   hour12: true
    // });
  }
}
