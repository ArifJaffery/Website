import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { InspectorSchedule } from '../../core/models/appointment.model';
import { CommonModule } from '@angular/common';  // ✅ import this

@Component({
  selector: 'app-time-box',
  imports: [CommonModule],  // ✅ add this
  templateUrl: './time-box.component.html',
  styleUrls: ['./time-box.component.scss']
})
export class TimeBoxComponent implements OnInit {

  @Input() schedule:{ date: string; slots: string[] } | undefined = undefined;
  
  isAvailable: boolean = false;

  convertTo24Hour(time: string): string {    
    const [hourStr, period] = time.split(' ');
    let hour = parseInt(hourStr, 10);

    if (period.toLowerCase() === 'pm' && hour !== 12) {
      hour += 12;
    }
    if (period.toLowerCase() === 'am' && hour === 12) {
      hour = 0;
    }
    return `${hour.toString().padStart(2, '0')}:00`;
  }

  // isAnyInspectorAvailable( timeRange: string, date: string,inspectors: { inspectorId: string; slots: string[] }[] ): boolean {
  //   const formattedTime = this.convertTo24Hour(timeRange.split(' - ')[0]);

  //   return inspectors.some(inspector => {
  //     const daily = inspector.slots.find(d => d === date);
  //     return daily?.includes(formattedTime);
  //   });    
  // }

  extractStartTime(time?: string): string {
    if (!time || !time.includes('-')) return '';
      return time.split('-')[0].trim();
  }

  isAnyInspectorAvailable( timeRange: string,  inspectors: { inspectorId: string; slots: string[] }[]): boolean {   
    const formattedTime = this.convertTo24Hour(timeRange.split(' - ')[0]);
    return inspectors.some(inspector =>
      inspector.slots.includes(formattedTime)
    );
  }

    // ✅ Highlight takes precedence
  // get isHighlighted(): boolean {
    
  //   if (this.date === this.existingInspectionDate && this.time === this.existingInspectionTime) {
  //     return true;
  //   }
  //   return this.isAvailable;
  // }

  getSlots = () => {
    return this.schedule?.slots;
  }

  ngOnInit(): void {    
  }
}
  // private updateTime(): void {
  //   const now = new Date();
  //   this.time = now.toLocaleTimeString('en-US', {
  //     hour: '2-digit',
  //     minute: '2-digit',
  //     hour12: true
  //   });
  // }
