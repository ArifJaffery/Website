import { Component , Input, OnInit} from '@angular/core';
import { TimeBoxComponent } from '../time-box.component/time-box.component';
import { TimeBoxHeaderComponent} from '../time-box-header.component/time-box-header.component';

import { CommonModule } from '@angular/common';
import { AvailabilityResponse } from '../../core/models/appointment.model';
import { CdkNoDataRow } from "@angular/cdk/table";

@Component({
  selector: 'app-time-grid',
  templateUrl: './time-grid.component.html',
  styleUrls: ['./time-grid.component.scss'],
  imports: [TimeBoxComponent, CommonModule, TimeBoxHeaderComponent, CdkNoDataRow]
})
export class TimeGridComponent implements OnInit {
 @Input() dates: string[] = [];
 @Input() inspectorsSchedule: AvailabilityResponse = [];
 @Input() existingInspectionDate: string | null = null;
 @Input() existingInspectionTime: string | null = null;

schedule:{ date: string; slots: string[] }[] = [];
NoOfTimeSlots = 10;
//rows = Array.from({ length: this.NoOfTimeSlots });  
cols = this.dates.length;
//NoOfTimeSlots = 10;
startHour = 9; // 9 AM

rows: string[] = Array.from({ length: this.NoOfTimeSlots }, (_, i) => {
  const start = this.startHour + i;
  const end = start + 1;

  const formatHour = (h: number) => {
    const hour12 = h % 12 === 0 ? 12 : h % 12;
    const period = h < 12 || h === 24 ? 'am' : 'pm';
    return `${hour12} ${period}`;
  };
  return `${formatHour(start)} - ${formatHour(end)}`;
} );


getAllTimeSlotsByDate(): { date: string; slots: string[] }[] {
  try {
    // Fetch schedules for all dates
    const results: { date: string; inspectorId: string; slots: string[] }[][] = 
      this.dates.map(date => this.getScheduleForDate(date))
    ;

    if (!results || results.length === 0) return [];

    // Map each date’s schedules into a { date, slots[] } object
    const slotsByDate = results.map(inspectorSchedulesForDate => {
      const date = inspectorSchedulesForDate[0]?.date;

      // Flatten all slots for this date across inspectors
      const slots = inspectorSchedulesForDate.flatMap(s => s.slots || []);

      // Remove duplicates and sort ascending
      const uniqueSortedSlots = Array.from(new Set(slots)).sort((a, b) => a.localeCompare(b));

      return { date, slots: uniqueSortedSlots };
    });

    return slotsByDate;

  } catch (err) {
    console.error('Error loading schedules:', err);
    return [];
  }
}

  getSchedule = (index: number) => {    
    return this.schedule[index];
  }

  ngOnInit() {

    try {
      this.schedule = this.getAllTimeSlotsByDate();            
    } catch (err) {
      console.error('Failed to load time slots:', err);
    }
  }
  
  getScheduleForDate = (date: string): { date: string;inspectorId: string; slots: string[] }[] => {  
    return this.inspectorsSchedule?.map(inspector => {
      const dailySlot = inspector.schedule?.find(slot => slot.date === date);
      return {
        date: date,
        inspectorId: inspector.inspectorId,
        slots: dailySlot ? dailySlot.slots : []
      };
    }) || [];
  }

}
