export interface ApplicationFeatures {
  enableBookingsDashboard: boolean;
  enablePropertyReportSelector: boolean;
  enableBookingRequest: boolean;
  enableLogin: boolean;
  enableRegistration: boolean;
}

export const defaultApplicationFeatures: ApplicationFeatures = {
  enableBookingsDashboard: false,
  enablePropertyReportSelector: true,
  enableBookingRequest: false,
  enableLogin: false,
  enableRegistration: false
};
