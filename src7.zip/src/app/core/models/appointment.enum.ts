

export enum AppointmentStatus {
  PROPOSED = 'PROPOSED',
  PENDING = 'PENDING',
  CONFIRMED = 'CONFIRMED',
  RESCHEDULED = 'RESCHEDULED',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED'
}

export enum AppointmentActionType {
  CREATED = 'CREATED',
  UPDATED = 'UPDATED',
  CONFIRMED = 'CONFIRMED',
  RESCHEDULED = 'RESCHEDULED',
  CANCELLED = 'CANCELLED',
  COMPLETED = 'COMPLETED'
}

export enum AppointmentActor {
  AGENT = 'AGENT',
  ADMIN = 'ADMIN',
  INSPECTOR = 'INSPECTOR',
  SYSTEM = 'SYSTEM'
}