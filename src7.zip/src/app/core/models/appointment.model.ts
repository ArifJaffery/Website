import { AppointmentActionType, AppointmentActor, AppointmentStatus } from './appointment.enum';

export type ISODateString = string;   // "2026-03-16"
export type ISODateTimeString = string; // "2026-03-16T10:00:00Z"

export interface TimeSlot {
  date: ISODateString;
  time: string; // "10:00"
}

export interface ConfirmedSlot extends TimeSlot {
  confirmedAt: ISODateTimeString;
}

export interface AppointmentHistory {
  action: AppointmentActionType;
  actor: AppointmentActor;
  actorId?: string;
  timestamp: ISODateTimeString;
  notes?: string;
}

export interface InspectorAssignment {
  inspectorId: string;
  inspectorName?: string;
  assignedAt: ISODateTimeString;
}

export interface AppointmentCancellation {
  reason?: string;
  cancelledBy: AppointmentActor;
  cancelledAt: ISODateTimeString;
}

export interface AppointmentReschedule {
  previousSlot: ConfirmedSlot;
  newProposedSlots: TimeSlot[];
  reason?: string;
  requestedBy: AppointmentActor;
  requestedAt: ISODateTimeString;
}

export interface Appointment {
  appointmentId: string;
  bookingId: string;

  createdBy: string; // userId
  createdAt: ISODateTimeString;

  status: AppointmentStatus;

  // 🔹 Scheduling
  proposedSlots: TimeSlot[];
  confirmedSlot?: ConfirmedSlot;

  // 🔹 Assignment
  inspector?: InspectorAssignment;

  // 🔹 State Transitions
  cancellation?: AppointmentCancellation;
  reschedule?: AppointmentReschedule;

  // 🔹 Communication
  notes?: string;

  // 🔹 Audit
  history: AppointmentHistory[];
}

export interface CreateAppointmentRequest {
  bookingId: string;
  proposedSlots: TimeSlot[];
  notes?: string;
}

export interface ConfirmAppointmentRequest {
  appointmentId: string;
  confirmedSlot: TimeSlot;
  inspectorId: string;
}

export interface RescheduleAppointmentRequest {
  appointmentId: string;
  newProposedSlots: TimeSlot[];
  reason?: string;
}

export interface CancelAppointmentRequest {
  appointmentId: string;
  reason?: string;
}

export interface DailySlot {
  date: ISODateString;   // e.g., "2026-03-23"
  day: string;           // e.g., "Monday"
  slots: string[];       // e.g., ["09:00", "10:00"], can be empty
}

export interface InspectorSchedule {
  inspectorId: string;   // matches InspectorAssignment.inspectorId type
  name: string;          // inspector’s name
  schedule: DailySlot[]; // 7-day schedule
}

export type AvailabilityResponse = InspectorSchedule[];

const appointment: Appointment = {
  appointmentId: 'APT-12345',
  bookingId: 'TPI-616LUWBT',

  createdBy: '641f9d2b4a6b8.12345678',
  createdAt: '2026-03-10T10:00:00Z',

  status: AppointmentStatus.CONFIRMED,

  proposedSlots: [
    { date: '2026-03-16', time: '10:00' },
    { date: '2026-03-16', time: '14:00' }
  ],

  confirmedSlot: {
    date: '2026-03-16',
    time: '10:00',
    confirmedAt: '2026-03-10T11:00:00Z'
  },

  inspector: {
    inspectorId: 'INS-001',
    inspectorName: 'David Inspector',
    assignedAt: '2026-03-10T11:00:00Z'
  },

  history: [
    {
      action: AppointmentActionType.CREATED,
      actor: AppointmentActor.AGENT,
      timestamp: '2026-03-10T10:00:00Z'
    },
    {
      action: AppointmentActionType.CONFIRMED,
      actor: AppointmentActor.ADMIN,
      timestamp: '2026-03-10T11:00:00Z'
    }
  ]
};