// api-payload.ts

import { ListingAgent } from "./listingagent.model";
import { CoListingAgent} from "./colistingagent.model";
import { AdministrationTeamMember } from "./adminteammember.model";
import { NotificationParty } from "./notificationparty.model";
import { Vendor } from "./vendor.model";
import { PropertyAddress } from "./propertyaddress.model";
import { InspectionSchedule } from "./inspectionschedule.model";
import { PropertyAccessOption } from "./propertyaccess.model";

import { PaymentMethod } from "./paymentmethod.model";
import { PoolDetails } from "./pooldetails.model";
// import { SecondDwellingOption } from "./seconddwelling.model";
import { SaleTypeOption, TypeOfSale } from "./saletype.model";
import { OpenHouseAuction } from "./openhouseauction.model";
import { SpecialInstructions } from "./specialinstruction.model";
import { TermsAndConditions, TPITermsAndConditions } from "./termsandconditions.model";
import { PreInspectionAgreement } from "./preinspectionagreement.model";
import { ContractAcknowledgement } from "./contractacknowledgment.model";
import { Contact, ContactType } from "./contact.model";
import { CostModel } from "./costmodal.model";
import { SecondDwelling } from "./seconddwelling.model";
import { CompleteOrderStatus } from "./completeorder.model";
import { CompleteOrderForm } from "./completeorderform.model";

/**
 * Full Booking Inspection Request Payload
 */
export interface BookingInspectionRequest {

  bookingId?: string; // Optional until assigned by backend
  // Section 1: Agents & Notifications
  contacts : Contact[];
  
  // Section 2: Vendor Details
  vendor : Contact[];

  // Section 3: Property Address
  propertyAddress: PropertyAddress;

  // Section 4: Inspection Schedule
  inspectionSchedule: InspectionSchedule;

  // Section 5: Property Access
  propertyAccess: PropertyAccessOption;

  // Section 6: Cost Model / Qualifying Questions
  costModel: CostModel;

  // Section 7: Payment Method
  paymentMethod: PaymentMethod;

  // Section 8: Pool Details
  poolDetails?: PoolDetails;

  // Section 9: Second Dwelling / Granny Flat
  secondDwelling?: SecondDwelling;

  // Section 10: Type of Sale
  saleType: TypeOfSale;

  // Section 11: Open House / Auction Date & Time
  openHouseAuction?: OpenHouseAuction;

  // Section 12: Special Instructions
  specialInstructions?: SpecialInstructions;

  // Section 13: Terms and Conditions Acceptance
  termsAndConditions: TPITermsAndConditions;


  // Section 16: Order Completion
  orderCompleted: CompleteOrderForm;

}

