import { CostModelTitle, InspectionCost, InspectionType } from './inspectioncost.model';

export interface BusinessCostModel {
    costmodelname: string;
    inspectionCost: InspectionCost[];
}

// Define an array of BusinessCostModel objects
export const businessCostModels: BusinessCostModel[] = [
  {
    costmodelname: '1-Vendor & Buyers Pays (One-off Payment)',
    inspectionCost: [
      {  title : CostModelTitle.CostModel01,id: '0101',type: InspectionType.BuildingPest, vendor: 400, buyer: 100, finalBuyer: 0 },
      { title : CostModelTitle.CostModel01, id: '0102',type: InspectionType.Strata, vendor: 220, buyer: 100, finalBuyer: 0 }
    ]
  },
  {
    costmodelname: '2-Vendor & Buyers Pays (Vendor Full Freight)',
    inspectionCost: [
      {  title : CostModelTitle.CostModel02, id: '0201',type: InspectionType.BuildingPest, vendor: 420, buyer: 120, finalBuyer: 0 },
      {  title : CostModelTitle.CostModel02, id: '0202',type: InspectionType.Strata, vendor: 230, buyer: 110, finalBuyer: 0 }
    ]
  },
  {
    costmodelname: '3-Vendor & Buyers Pays ($50)',
    inspectionCost: [
      {  title : CostModelTitle.CostModel03, id: '0301',type: InspectionType.BuildingPest, vendor: 450, buyer: 50, finalBuyer: 0 },
      {  title : CostModelTitle.CostModel03, id: '0302',type: InspectionType.Strata, vendor: 250, buyer: 50, finalBuyer: 0 }
    ]
  },
  {
    costmodelname: '4-Vendor & Buyers Pays ($30)',
    inspectionCost: [
      {  title : CostModelTitle.CostModel04, id: '0401',type: InspectionType.BuildingPest, vendor: 430, buyer: 30, finalBuyer: 0 },
      {  title : CostModelTitle.CostModel04, id: '0402',type: InspectionType.Strata, vendor: 240, buyer: 30, finalBuyer: 0 }
    ]
  },
  {
    costmodelname: '5-Vendor & Buyers Pays ($100)',
    inspectionCost: [
      {  title : CostModelTitle.CostModel05, id: '0501',type: InspectionType.BuildingPest, vendor: 500, buyer: 100, finalBuyer: 0 },
      {  title : CostModelTitle.CostModel05, id: '0502',type: InspectionType.Strata, vendor: 260, buyer: 100, finalBuyer: 0 }
    ]
  },
  {
    costmodelname: '6-Vendor & Buyers Pays ($150 / $80)',
    inspectionCost: [
      {  title : CostModelTitle.CostModel06, id: '0601',type: InspectionType.BuildingPest, vendor: 550, buyer: 150, finalBuyer: 80 },
      {  title : CostModelTitle.CostModel06, id: '0602',type: InspectionType.Strata, vendor: 280, buyer: 150, finalBuyer: 80 }
    ]
  },
  {
    costmodelname: '7-Vendor Only (Option For Buyers To Purchase)',
    inspectionCost: [
      {  title : CostModelTitle.CostModel07, id: '0701',type: InspectionType.BuildingPest, vendor: 400, buyer: 0, finalBuyer: 0 },
      {  title : CostModelTitle.CostModel07, id: '0702',type: InspectionType.Strata, vendor: 220, buyer: 0, finalBuyer: 0 }
    ]
  },
  {
    costmodelname: '8-Vendor Only (Vendor & Buyer Reliant)',
    inspectionCost: [
      {  title : CostModelTitle.CostModel08, id: '0801',type: InspectionType.BuildingPest, vendor: 420, buyer: 0, finalBuyer: 0 },
      {  title : CostModelTitle.CostModel08, id: '0802',type: InspectionType.Strata, vendor: 230, buyer: 0, finalBuyer: 0 }
    ]
  },
  {
    costmodelname: '9-Vendor Only Pays(Large Estate or Outer Sydney orders)',
    inspectionCost: [
      { title : CostModelTitle.CostModel09, id: '0901',type: InspectionType.BuildingPest, vendor: 600, buyer: 0, finalBuyer: 0 },
      { title : CostModelTitle.CostModel09, id: '0902',type: InspectionType.Strata, vendor: 300, buyer: 0, finalBuyer: 0 }
    ]
  },
  {
    costmodelname: '10-Buyers Only Pay ($49)',
    inspectionCost: [
      { title : CostModelTitle.CostModel10, id: '1001',type: InspectionType.BuildingPest, vendor: 0, buyer: 49, finalBuyer: 0 },
      { title : CostModelTitle.CostModel10, id: '1002',type: InspectionType.Strata, vendor: 0, buyer: 49, finalBuyer: 0 }
    ]
  },
  {
    costmodelname: '11-Buyers Only Pay ($99)',
    inspectionCost: [
      { title : CostModelTitle.CostModel11,id: '1101',type: InspectionType.BuildingPest, vendor: 0, buyer: 99, finalBuyer: 0 },
      { title : CostModelTitle.CostModel11,id: '1102',type: InspectionType.Strata, vendor: 0, buyer: 99, finalBuyer: 0 }
    ]
  },
  {
    costmodelname: '12-Buyers Only Pay ($149)',
    inspectionCost: [
      { title : CostModelTitle.CostModel12,id: '1201',type: InspectionType.BuildingPest, vendor: 0, buyer: 149, finalBuyer: 0 },
      { title : CostModelTitle.CostModel12,id: '1202',type: InspectionType.Strata, vendor: 0, buyer: 149, finalBuyer: 0 }
    ]
  },
  {
    costmodelname: '13-Buyers Only Pay ($299 / $199)',
    inspectionCost: [
      { title : CostModelTitle.CostModel13,id: '1301',type: InspectionType.BuildingPest, vendor: 0, buyer: 299, finalBuyer: 199 },
      { title : CostModelTitle.CostModel13,id: '1302',type: InspectionType.Strata, vendor: 0, buyer: 299, finalBuyer: 199 }
    ]
  },
  {
    costmodelname: '14- TPI Special',
    inspectionCost: [
      { title : CostModelTitle.CostModel14,id: '1401',type: InspectionType.BuildingPest, vendor: 500, buyer: 200, finalBuyer: 100 },
      { title : CostModelTitle.CostModel14,id: '1402',type: InspectionType.Strata, vendor: 250, buyer: 200, finalBuyer: 100 }
    ]
  }
];
