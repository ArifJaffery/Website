export enum Roles {
    ListingAgent = 'Listing Agent',
    AccountManager = 'Account Manager',
    Principal = 'Principal'
}

export interface CompleteOrderForm {
  role?: Roles;                 // e.g., 'Listing Agent', 'Account Manager', 'Principal'
  approvedByEmail: string;      // must be a valid email
  approvalDateTime: Date;       // timestamp of approval
  completeOrderNow: boolean;    // true when checkbox is checked
}
