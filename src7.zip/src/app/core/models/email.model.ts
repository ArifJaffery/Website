export interface Email {
    messasgeid: string;
    subject: string;
    senderEmail: string;
    Receipients: string[];
    messageBody: string;
}

export const defaultEmail : Email = {
    messasgeid: '',
    subject: '',
    senderEmail: '',
    Receipients: [],
    messageBody: ''
};