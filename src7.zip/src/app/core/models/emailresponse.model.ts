export interface EmailResponse {
    code: string;
    message: string;   
};

export const defaultEmailResponse : EmailResponse  =  {
    code: '',
    message : ''
};

