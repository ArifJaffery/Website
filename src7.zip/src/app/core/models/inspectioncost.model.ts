export enum InspectionType {
  BuildingPest = 'Building & Pest',
  Strata = 'Strata'
}

export enum CostModelTitle {
  CostModel01 = '1-Vendor & Buyers Pays (One-off Payment)',
  CostModel02 = '2-Vendor & Buyers Pays (Vendor Full Freight)',
  CostModel03 = '3-Vendor & Buyers Pays ($50)',
  CostModel04 = '4-Vendor & Buyers Pays ($30)', 
  CostModel05 = '5-Vendor & Buyers Pays ($100)',
  CostModel06 = '6-Vendor & Buyers Pays ($150 / $80)',
  CostModel07 = '7-Vendor Only (Option For Buyers To Purchase)',
  CostModel08 = '8-Vendor Only (Vendor & Buyer Reliant)',
  CostModel09 = '9-Vendor Only Pays(Large Estate or Outer Sydnet orders)',
  CostModel10 = '10-Buyers Only Pay ($49)',
  CostModel11 = '11-Buyers Only Pay ($99)',
  CostModel12 = '12-Buyers Only Pay ($149)',
  CostModel13 = '13-Buyers Only Pay ($299 / $199)',
  CostModel14 = '14- TPI Special'
}

export interface InspectionCost {
  id : string;
  title : CostModelTitle,
  type?: InspectionType;   // enum value
  vendor: number;         // vendor cost
  buyer: number;          // buyer cost
  finalBuyer: number;     // final buyer cost
}
