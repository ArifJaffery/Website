// listing-agent.ts

// Interface for Listing Agent
export interface ListingAgent {
  givenName: string;
  surname: string;
  email: string;
  mobilePhone: string;
}

// Array to store listing agents (in case multiple listings)
export const listingAgents: ListingAgent[] = [];

// Function to add a listing agent
export function addListingAgent(agent: ListingAgent): void {
  // Basic validation
  if (!agent.givenName || !agent.surname || !agent.email || !agent.mobilePhone) {
    throw new Error("All fields are required for the listing agent.");
  }

  listingAgents.push(agent);
  console.log(`Listing agent added: ${agent.givenName} ${agent.surname}`);
}

// Function to list all listing agents
export function listListingAgents(): void {
  if (listingAgents.length === 0) {
    console.log("No listing agents added yet.");
    return;
  }

  console.log("Listing Agents:");
  listingAgents.forEach((agent, index) => {
    console.log(
      `${index + 1}. ${agent.givenName} ${agent.surname} | Email: ${agent.email} | Mobile: ${agent.mobilePhone}`
    );
  });
}

// Example usage
/*
addListingAgent({
  givenName: "John",
  surname: "Doe",
  email: "john.doe@example.com",
  mobilePhone: "+61412345678"
});

listListingAgents();
*/
