import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ApplicationFeatures, defaultApplicationFeatures } from '../models/application.featues.model';


@Injectable({ providedIn: 'root' })
export class ApplicationService {

  // Internal state holder
  private applicationSubject = new BehaviorSubject<ApplicationFeatures>(this.loadInitialState());

  // Public observable (read-only)
  user$: Observable<ApplicationFeatures | null> = this.applicationSubject.asObservable();

  /** Set user (login success) */
  setUser(user: ApplicationFeatures): void {
    this.applicationSubject.next(user);
  }

  /** Get current user synchronously (rarely needed) */
  getUser(): ApplicationFeatures | null {
    return this.applicationSubject.value;
  }

  /** Clear user (logout) */
  clearUser(): void {
    // this.applicationSubject.next(null);
  }


 /** Load initial state from localStorage or default */
  private loadInitialState(): ApplicationFeatures {
    const saved = localStorage.getItem('appFeatures');
    return saved ? JSON.parse(saved) : defaultApplicationFeatures;
  }

  updateState(partial: Partial<ApplicationFeatures>): void {
    const current = this.applicationSubject.value;
    const updated = { ...current, ...partial };

    this.applicationSubject.next(updated);
    localStorage.setItem('appFeatures', JSON.stringify(updated));
  }  

}
