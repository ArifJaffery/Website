import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { UserService } from './user.service';

export const authGuard: CanActivateFn = () => {

  const userService = inject(UserService);
  const router = inject(Router);

  const user = userService.getUser();

  if (user) {
    return true; // ✅ logged in
  }

  // ❌ not logged in → redirect
  router.navigate(['/login']);
  return false;

};
