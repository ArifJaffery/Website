// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';

// @Injectable({ providedIn: 'root' })
// export class AuthService {
//   private api = '/api';


//   constructor(private http: HttpClient) {}

//   sendVerificationCode(email: string) {
//     return this.http.post(`${this.api}/send-code`, { email });
//   }

//   verifyCode(email: string, code: string) {
//     return this.http.post(`${this.api}/verify-code`, { email, code });
//   }
// }
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = '/api';

  constructor(private http: HttpClient) {}

  // Accept full registration data now
  // sendVerificationCode(registrationData: {
  //   email: string;
  //   firstName?: string;
  //   lastName?: string;
  //   homePhone?: string;
  //   mobile?: string;
  //   unitNumber?: string;
  //   streetNumber?: string;
  //   streetName?: string;
  //   suburb?: string;
  //   city?: string;
  //   state?: string;
  // }) {
  //   return this.http.post(`${this.api}/send-code`, registrationData);
  // }

  sendVerificationCode(registrationData: any) {
    //console.log('Sending verification code with data:', registrationData);
    return this.http.post(`${this.api}/send-code`, registrationData);
  }

  verifyCode(email: string, code: string) {
    return this.http.post(`${this.api}/verify-code`, { email, code });
  }

  // Optional: create profile separately if needed
  createProfile(profileData: any) {
    return this.http.post(`${this.api}/create-profile`, profileData);
  }

  loginRequest(email: string) {
    return this.http.post(`${this.api}/login-request`, { email });
  }

  /** Step 2: Verify login passcode */
  verifyLoginCode(email: string, code: string) {
    return this.http.post(`${this.api}/login-verify`, { email, code });
  }
  // Step 2b: Login with password (backend expects email + password)
  loginWithPassword(email: string, password: string) {
    console.log('Logging in with password for:', email);
    console.log('Password:', password);
    return this.http.post(`${this.api}/login-password`, { email, password });
  }


}
