import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, tap } from 'rxjs'; 
import { HttpClient } from '@angular/common/http';
import { InspectorSchedule, AvailabilityResponse } from '../models/appointment.model'; // <- new types

@Injectable({
  providedIn: 'root'
})
export class AvailabilityService {

  // ---------─ Private State ────────────────────────────────────
  private availableDatesSubject = new BehaviorSubject<InspectorSchedule[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  private selectedDateSubject = new BehaviorSubject<string | null>(null);
  private api = '/api';

  // ---------─ Public Observables (read-only) ───────────────────
  availableDates$ = this.availableDatesSubject.asObservable();
  loading$ = this.loadingSubject.asObservable();
  selectedDate$ = this.selectedDateSubject.asObservable();

  constructor(private http: HttpClient) {}

  clearavailableDates(): void {
    this.availableDatesSubject.next([]);
  }

  // --------- Updated method ---------
  fetchAvailableDates(date: string): Observable<AvailabilityResponse> {
    this.loadingSubject.next(true);
    return this.http.post<AvailabilityResponse>(`${this.api}/GetTimeSlotsForAWeek`, { date }).pipe(
      tap({
        next: schedules => {
          console.log('Fetched schedules:', schedules);
          this.availableDatesSubject.next(schedules);
          this.loadingSubject.next(false);
        },
        error: err => {
          console.error('Failed to fetch schedules:', err);
          this.availableDatesSubject.next([]);
          this.loadingSubject.next(false);
        }
      })
    );
  }

  selectDate(date: string): void {
    this.selectedDateSubject.next(date);
  }

  clearSelectedDate(): void {
    this.selectedDateSubject.next(null);
  }
}