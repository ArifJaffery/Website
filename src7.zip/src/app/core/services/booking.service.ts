import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user.model';
import { HttpClient } from '@angular/common/http';
import { BookingInspectionRequest } from '../models/bookingrequest.model';
import { tap } from 'rxjs/operators';
import { createBlankBooking } from '../../components/booking.component/blank-booking.factory';

@Injectable({ providedIn: 'root' })
export class BookingService {
  // Internal state holder
  // private bookingsSubject = new BehaviorSubject<BookingInspectionRequest[] | null>(null);
  // private bookingSubject = new BehaviorSubject<BookingInspectionRequest | null>(null);  

// ── Private State ────────────────────────────────────
  private bookingsSubject        = new BehaviorSubject<BookingInspectionRequest[]>([]);
  private bookingSubject         = new BehaviorSubject<BookingInspectionRequest | null>(null);
  private currentBookingSubject  = new BehaviorSubject<BookingInspectionRequest | null>(null);
  private showBookingFormSubject = new BehaviorSubject<boolean>(false);


  // Public observable (read-only)
  // bookings$: Observable<BookingInspectionRequest[] | null> = this.bookingsSubject.asObservable();
  // booking$: Observable<BookingInspectionRequest | null> = this.bookingSubject.asObservable();

// ── Public Observables (read-only) ───────────────────
  bookings$         = this.bookingsSubject.asObservable();
  booking$          = this.bookingSubject.asObservable();
  currentBooking$   = this.currentBookingSubject.asObservable();
  showBookingForm$  = this.showBookingFormSubject.asObservable();

  private api = '/api';

  constructor(private http: HttpClient) {}
  
  setBookings(bookingInspectionRequest : BookingInspectionRequest[]): void {
    this.bookingsSubject.next(bookingInspectionRequest);
  }

  /** Clear user (logout) */
  clearUser(): void {
    this.bookingsSubject.next([]);
  }
 
// ── Current Booking (row click) ──────────────────────

  /** Called when a row is clicked in the dashboard grid */
  selectBooking(booking: BookingInspectionRequest): void {
    this.currentBookingSubject.next(booking);
    this.showBookingFormSubject.next(true);   // show the BookingComponent
  }
/** Called when BookingComponent is closed / cancelled */
  clearCurrentBooking(): void {
    this.currentBookingSubject.next(null);
    this.showBookingFormSubject.next(false);  // hide the BookingComponent
  }

  /** Called when a new blank booking is started */
  newBooking(): void {
    this.currentBookingSubject.next(createBlankBooking());
    this.showBookingFormSubject.next(true);
  }

  createBooking(bookingData: BookingInspectionRequest) {
    return this.http.post<any>(`${this.api}/create-booking`, bookingData)
      .pipe(
        tap(response => {
          const { bookingId, data } = response;

          if (bookingId) {
            // Create new booking object with bookingId
            const newBooking: BookingInspectionRequest = { ...bookingData, bookingId };

            // Update current bookings array immutably
            const currentBookings = this.bookingsSubject.value || [];
            const updatedBookings = [
              ...currentBookings.filter(b => b.bookingId !== bookingId),
              newBooking
            ];

            // Update subjects
            this.bookingsSubject.next(updatedBookings);
            this.bookingSubject.next(newBooking);
          }

          // console.log('Response from create-booking booking id:', bookingId);
          // if (response && response.bookingId) {

            // Update booking object
            // bookingData.bookingId = bookingId;

            // Get current bookings
            // let bookings = this.bookingsSubject.value || [];

            // Add booking if not already present
            // const existingIndex = bookings.findIndex(b => b.bookingId === bookingId);

            // if (existingIndex === -1) {
            //   bookings.push(bookingData);
            // } else {
            //   bookings[existingIndex] = bookingData;
            // }
            // Update state
            // this.bookingsSubject.next(bookings);
            // this.bookingSubject.next(data); 
          // }
        })
      );
  }

  getBookings(userid : string){
    console.log(`Userid=>${userid}`)
    return this.http.post(`${this.api}/retreive-bookings`, {"userid" : userid});
  }
}
