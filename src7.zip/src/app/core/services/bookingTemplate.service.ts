import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { defaultEmail, Email } from '../models/email.model';
import { defaultEmailResponse, EmailResponse } from '../models/emailresponse.model';
import { BookingInspectionRequest } from '../models/bookingrequest.model';


@Injectable({ providedIn: 'root' })

export class BookingTemplateService {
    private emailSubject = new BehaviorSubject<Email>(defaultEmail);
    newBooking$ : Observable<Email> = this.emailSubject.asObservable();

    sendBooking(bookingInspectionRequest: BookingInspectionRequest){

        
        // this.emailSubject.next([]);
    }




}
