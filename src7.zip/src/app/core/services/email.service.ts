import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { defaultEmail, Email } from '../models/email.model';
import { defaultEmailResponse, EmailResponse } from '../models/emailresponse.model';


@Injectable({ providedIn: 'root' })

export class EmailService {
    private emailSubject = new BehaviorSubject<EmailResponse>(defaultEmailResponse);
    newEmail$ : Observable<EmailResponse> = this.emailSubject.asObservable();

    sendEmail(email: Email){
        // Step 1: Send Email using Email End Point

        // Step 2: Response
        const response : EmailResponse = defaultEmailResponse;

        this.emailSubject.next(response);
    }




}
